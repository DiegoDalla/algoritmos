#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int res;
    int n , r;
    int fatn , fatr , fats;
    int num; //Numero de entradas a serem processadas
    
    printf("Informe quantas entradas devem ser lidas: ");
    scanf("%d", &num);
    
    for(int i = 0 ; i < num ; i++)
    {
        printf("Entre com os valores: \n");
        scanf("%d", &n);
        scanf("%d", &r);
        
        fatn = fatorial(n);
        fatr = fatorial(r);
        fats = fatorial(n-r);
        
        if(n < r)
            printf("Entrada Invalida.\n\n");
        else
        {
            res = ((fatn) / (fatr * fats));
            
            printf("C(%d,%d) = %d\n\n", n , r , res);
        }
    }
    
    return 0;
}

int fatorial (int x)
{
    int aux;
    
    for(aux = 1 ; x > 1 ; x = x - 1)
        aux = aux * x;
    
    return aux;
}
