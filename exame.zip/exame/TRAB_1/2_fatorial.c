#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int x;
    int aux;
    
    while(1)
    {
        scanf("%d", &x);
        
        if(x < 0)
            return 0;
        else
        {
            aux = fatorial(x);
            
            printf("%d! = %d\n\n", x, aux);
        }
    }
    
    return 0;
}

int fatorial (int x)
{
    int aux;
    
    for(aux = 1 ; x > 1 ; x = x - 1)
        aux = aux * x;
    
    return aux;
}
