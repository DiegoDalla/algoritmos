
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct caminhao
{
	//Informação
	char Placa[9];
	char NomeMotorista[40];
	
	//Entrada
	int PesoIn;
	int HoraIn;
	int MinIn;
    
	//Saída
	int PesoOut;
	int HoraOut;
    int MinOut;
	
	//Classificação
	int umidade;
	int impureza;//Declarando função
	int teste;
}caminhao;

//---------------------------------------------------------------//

//Declarando função
caminhao entrada(caminhao cam);
caminhao saida(caminhao cam);
caminhao classifica(caminhao cam);
void ExportIn(caminhao cam , char nome[], int num);
void ExportOut(caminhao cam , char nome[], int num);
void ExportClass(caminhao cam , char nome[], int num);

//---------------------------------------------------------------//

int main(void)
{
    //Declaração de variaveis
	int op1;
	int cont1 = 0, cont2 = 0, cont3 = 0;
	caminhao camIn[1000];
    caminhao camOut[1000];
    caminhao camClass[1000];
    char nome1[50];
    char nome2[50];
    char nome3[50];
    char txt[] = ".txt";
	
    printf("Forneca o nome ou endereco do arquivo de entrada.\nNÃO É NECESSÁRIO EXTENSÃO.\n--> ");
    setbuf(stdin , NULL);
    fgets(nome1 , 50 , stdin);
    //Tira o \n do final
    nome1[strlen(nome1) - 1] = '\0';
    setbuf(stdin , NULL); 
    //Coloca a extensão
    strcat(nome3 , txt);
    system("clear");
    
    printf("Forneca o nome ou endereco do arquivo de saida.\nNÃO É NECESSÁRIO EXTENSÃO.\n--> ");
    setbuf(stdin , NULL);
    fgets(nome2 , 50 , stdin);
    //Tira o \n do final
    nome2[strlen(nome2) - 1] = '\0';
    setbuf(stdin , NULL); 
    //Coloca a extensão
    strcat(nome2 , txt);
    system("clear");
    
    printf("Forneca o nome ou endereco do arquivo da classificação.\nNÃO É NECESSÁRIO EXTENSÃO.\n--> ");
    setbuf(stdin , NULL);
    fgets(nome3 , 50 , stdin);
    //Tira o \n do final
    nome3[strlen(nome3) - 1] = '\0';
    setbuf(stdin , NULL); 
    //Coloca a extensão
    strcat(nome3 , txt);
    system("clear");
    
	while(1)
	{
		printf("-----------------------------------------\n");
		printf("1 - Entrada de caminhão\n");
		printf("2 - Saída de caminhao\n");
        printf("3 - Classificar caminhão\n");
		printf("4 - Gerar o arquivos e encerrar o app\n");
		printf("-----------------------------------------\n");
		printf("--> ");
		scanf("%d", &op1);
		
		system("clear"); //Apaga o display
		
		switch(op1)
		{
			case 1: //Entrada do caminhão
			{
				camIn[cont1] = entrada(camIn[cont1]); 
                
                ExportIn(camIn[cont1] , nome1 , cont1);
                
                cont1++;
                
                break;
			}
			case 2: //Saída do caminhão
			{
				camOut[cont2] = saida(camOut[cont2]); 
		
				ExportOut(camOut[cont2] , nome2, cont2);
				
                cont2++;
                
                break;
			}
            case 3: //Classificação
            {
                camClass[cont3] = classifica(camClass[cont3]); 
                
                ExportClass(camClass[cont3] , nome3 , cont3);
                
                cont3++;
                
                break;
            }
            case 4:
            {
                return 0;
                
                break;
            }
            default:
			{
				printf("Entrada Invalida.\n");
                printf("PRESS ENTER..\n");
                while(getchar()!='\n');
                
                break;
			}
			
		}
	}
	
	return 0;
}

caminhao entrada(caminhao cam)
{
	printf("Informe a placa do veículo(AAA0000): ");
    setbuf(stdin , NULL);
	fgets(cam.Placa , 8 , stdin);
	system("clear");
	
	printf("Informe o nome do motorista: ");
    setbuf(stdin , NULL);
	fgets(cam.NomeMotorista , 39 , stdin);
    fgets(cam.NomeMotorista , 39 , stdin);
	system("clear");
    
    printf("Informe o peso do veiculo: ");
    scanf("%d", &cam.PesoIn);
    system("clear");
    
    printf("Informe a hora (HH MM): ");
    scanf("%d %d", &cam.HoraIn , &cam.MinIn);
    system("clear");
    
    return cam;
}

caminhao saida(caminhao cam)
{
	printf("Informe a placa do veículo(AAA0000): ");
    setbuf(stdin , NULL);
	fgets(cam.Placa , 8 , stdin);
	system("clear");
	
	printf("Informe o nome do motorista: ");
    setbuf(stdin , NULL);
	fgets(cam.NomeMotorista , 40 , stdin);
    fgets(cam.NomeMotorista , 39 , stdin);
	system("clear");
    
    printf("Informe o peso do veiculo: ");
    scanf("%d", &cam.PesoOut);
    system("clear");
    
    printf("Informe a hora (HH MM): ");
    scanf("%d %d", &cam.HoraOut , &cam.MinOut);
    system("clear");
    
    return cam;
}    

caminhao classifica(caminhao cam)
{
	printf("Informe a placa do veículo(AAA0000): ");
    setbuf(stdin , NULL);
	fgets(cam.Placa , 8 , stdin);
	system("clear");
	
	printf("Informe o nome do motorista: ");
    setbuf(stdin , NULL);
	fgets(cam.NomeMotorista , 40 , stdin);
    fgets(cam.NomeMotorista , 39 , stdin);
	system("clear");
    
    printf("Informe o %% de umidade: ");
    scanf("%d", &cam.umidade);
    system("clear");
    
    printf("Informe a %% de impureza: ");
    scanf("%d", &cam.impureza);
    system("clear");
    
    printf("Informe a qualidade da semente...\n");
    printf("1 - Convencional\t2 - Intacta\n");
    scanf("%d", &cam.teste);
    system("clear");
    
    return cam;
}

void ExportIn(caminhao cam , char nome[], int num)
{
    FILE *arq_entrada;
    
    //abrindo o arquivo com tipo de abertura 'a'
    arq_entrada = fopen(nome , "a");
    
    //testando se o arquivo foi realmente criado
    if(arq_entrada == NULL)
    {
        printf("Erro na abertura do arquivo!");
        return;
    }
    
    //Cabeçalho do arquivo
    if(num == 0)
    {
        fprintf(arq_entrada, "--------------------------------------------------------\n  \t\tRELATÓRIO DE ENTRADA\n--------------------------------------------------------\n\n");
    }
    
    fprintf(arq_entrada, "\n--\n");
    fprintf(arq_entrada, "\nPLACA -> %s\n", cam.Placa);
    fprintf(arq_entrada, "\nNOME -> %s\n", cam.NomeMotorista);
    fprintf(arq_entrada, "HORA -> %d:%d\n", cam.HoraIn , cam.MinIn);
    fprintf(arq_entrada, "\nPESO -> %dKg\n", cam.PesoIn);
    fprintf(arq_entrada, "\n--\n");
    
    //usando fclose para fechar o arquivo
    fclose(arq_entrada);
}

void ExportOut(caminhao cam , char nome[], int num)
{
    FILE *arq_saida;
    
    //abrindo o arquivo com tipo de abertura 'a'
    arq_saida = fopen(nome , "a");
    
    //testando se o arquivo foi realmente criado
    if(arq_saida == NULL)
    {
        printf("Erro na abertura do arquivo!");
        return;
    }
    
    
    //Cabeçalho do arquivo
    if(num == 0)
    {
        fprintf(arq_saida, "--------------------------------------------------------\n  \t\tRELATÓRIO DE SAIDA\n--------------------------------------------------------\n\n");
    }
    
    fprintf(arq_saida, "\n--\n");
    fprintf(arq_saida, "\nPLACA -> %s\n", cam.Placa);
    fprintf(arq_saida, "\nNOME -> %s\n", cam.NomeMotorista);
    fprintf(arq_saida, "HORA -> %d:%d\n", cam.HoraOut , cam.MinOut);
    fprintf(arq_saida, "\nPESO -> %dKg\n", cam.PesoOut);
    fprintf(arq_saida, "\n--\n");
    
    //usando fclose para fechar o arquivo
    fclose(arq_saida);
}

void ExportClass(caminhao cam , char nome[], int num)
{
    FILE *arq_classificar;
    
    //abrindo o arquivo com tipo de abertura 'a'
    arq_classificar = fopen(nome , "a");
    
    //testa se o arquivo foi realmente criado
    if(arq_classificar == NULL)
    {
        printf("Erro na abertura do arquivo!");
        return;
    }
    
    //Cabeçalho do arquivo
    if(num == 0)
    {
        fprintf(arq_classificar, "--------------------------------------------------------\n  \t\tRELATÓRIO DE CLASSIFICAÇÃO\n--------------------------------------------------------\n\n");
    }
    
    fprintf(arq_classificar, "\n--\n\n");
    fprintf(arq_classificar, "\nPLACA -> %s\n", cam.Placa);
    fprintf(arq_classificar, "\nNOME -> %s\n", cam.NomeMotorista);
    fprintf(arq_classificar, "UMIDADE -> %d %%\n", cam.umidade);
    fprintf(arq_classificar, "\nIMPUREZA -> %d %%\n", cam.impureza);
    
    if(cam.teste == 2)
        fprintf(arq_classificar, "\nQUALIDADE -> Intacta\n");
    else
        fprintf(arq_classificar, "\nQUALIDADE -> Convencional\n");
    
    fprintf(arq_classificar, "\n\n--\n");
}
