#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nome[25];
    int nota;
}dado;

void verifica(dado info[] , int num)
{
    //Média
    int soma = 0;
    for(int i = 0 ; i < num ; i++)
    {
        soma += info[i].nota;
    }
    printf("Média da turma = %d\n\n", soma/num);
    
    //Abaixo da média
    printf("Alunos abaixo da média:\n");
    for(int i = 0 ; i < num ; i++)
    {
        if(info[i].nota < 60)
            printf("%s\n", info[i].nome);
    }
    
    printf("\n");
    
    //Acima da média
    printf("Alunos acima ou igual a média:\n");
    for(int i = 0 ; i < num ; i++)
    {
        if(info[i].nota >= 60)
            printf("%s\n", info[i].nome);
    }
}

int main(void)
{
    int num;
    
    printf("Informe o número de alunos da turma: ");
    scanf("%d", &num);
    
    dado info[num];
    
    //Leitura dos dados
    for(int i = 0 ; i < num ; i++)
    {
        scanf("%s", info[i].nome);
        scanf("%d", &info[i].nota);
    }
    
    printf("\n\n");
    
    verifica(info , num);
    
    return 0;
}
