#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int diml , dimc; //Dimensão da matriz
    int l , c; //Indice para o for
    int cont1 = 0 , cont2 = 0;
    
    printf("Informe as dimensões da matriz: ");
    scanf("%d %d", &diml , &dimc);
    
    int mat[diml][dimc];
    
    for(l = 0 ; l < diml ; l++)
    {
        for(c = 0 ; c < dimc ; c++)
        {
            scanf("%d", &mat[l][c]);
        }
    }
    
    //Soma Total
    int somaT = 0;
    for(l = 0 ; l < diml ; l++)
    {
        for(c = 0 ; c < dimc ; c++)
        {
            somaT += mat[l][c];
        }
    }
    
    //Soma Linhas
    int somaL[diml] = {0};
    for(l = 0 ; l < diml ; l++)
    {
        for(c = 0 ; c < dimc ; c++)
        {
            somaL[l] += mat[l][c];
        }
    }
    
    
    //Soma Coluna
    int somaC[dimc] = {0};
    for(l = 0 ; l < diml ; l++)
    {
        for(c = 0 ; c < dimc ; c++)
        {
            somaC[c] += mat[l][c];
        }
    }
    
    
    //Imprime soma Linhas
    for(l = 0 ; l < diml ; l++)
    {
        printf("Soma da linha %d --> %d", cont1, somaL);
        cont1++;
    }
    
    
    //Imprime soma Colunas
    for(c = 0 ; c < dimc ; c++)
    {
        printf("Soma da Coluna %d --> %d", cont2, somaL);
        cont2++;
    }   
    
    
    //Imprime soma total
    printf("Soma de todos os elementos --> %d", somaT);
    return 0;
}
