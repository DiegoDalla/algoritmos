#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nome[25];
    int idade;
}pessoa;

int main(void)
{
    int qnt;
    
    scanf("%d", &qnt);
    
    pessoa vet[qnt];
    
    for(int i = 0 ; i < qnt ; i++)
    {
        scanf("%s", vet[i].nome);
        scanf("%d", &vet[i].idade);
    }
    
    printf("\n\n--------------------------------------\n\n");
    
    printf("Menores de 18 anos:\n");
    for(int i = 0 ; i < qnt ; i++)
    {
        if(vet[i].idade < 18)
            printf("%s\n", vet[i].nome);
    }
    
    printf("\n");
    
    printf("Maiores de 18 anos:\n");
    for(int i = 0 ; i < qnt ; i++)
    {
        if(vet[i].idade >= 18)
            printf("%s\n", vet[i].nome);
    }
    
    printf("\n\n--------------------------------------\n\n");
    
    return 0;
}
