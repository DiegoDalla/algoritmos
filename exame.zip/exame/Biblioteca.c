// Sistema bibliotecário com arquivos binários
// Diego Dalla Bernardina & Guilherme Suttani
// Questão 2
// O programa importa os dados armazenados nos arquivos de registro de usuários, obras e empréstimos e manipula os dados até que seja encerrado, atualizando as informações conforme a manipulação realizada pelo usuário nos dados.


/*************AVISO*************/
//O programa possui um ERRO que infelizmente surgiu de última hora quando estavamos corrigindo alguns bugs, ele não lê o caso 4 do menu (RELATÓRIOS), apesar do mesmo estar formatado, ele não consegue criar o arquivo .txt pois o switch não consegue entrar no caso 4, acreditamos que isso seja causado por alguma "{" que não foi fechada corretamente, buscamos por bastante tempo e não conseguimos encontrar em qual parte do código está a escrita incorreta, apesar de termos conhecimento que o mesmo se encontra entre as linhas 655 e 1210 não conseguimos acha-lo, pedimos desculpas por apresentar o código desta maneira desde já.



#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct
{
	char cpf[13];
	char bairro[30];
	char ender[70];
	long int tel;
	long int cel;
	long int adesao;
	long int nascimento;
	char sexo;
	int status;
	long int suspensao;
	int volumes;
	char nome[50];
	int matricula;
	long int id;
	
}registro;

typedef struct
{
	int codigo;
	char isbn[12];
	char titulo[80];
	char autores[100];
	char assunto[80];
	char editora[50];
	int ano;
	int ed;
	int status;
}obras;

typedef struct
{
	long int dev;
	long int empres;
	int matricula;
	int codigo;
	char titulo[80];
}emprestimo;

int main (int argc, char *argv[])
{

	FILE *fp;
	FILE *fp2;
	FILE *fp3;
	FILE *fpt;
	size_t tam=0;
	size_t tam2=0;
	size_t tam3=0;

	registro reg[10000];
	obras ob[10000];
	emprestimo emp[10000];

    	time_t mytime;
    	mytime = time(NULL);
    	struct tm tm = *localtime(&mytime);

	// VARIÁVEIS
	int inicial_m, i, j, inicial_id, op, ops1, ops2; 
	int key_atualizar, u_cadastrados = 0, o_cadastradas = 0, e_totais = 0, key_consultar, key_apagar, key_status, n=0, no=0, ne=0;
	int diadI, mesdI, anodI;

// INICIALIZAÇÃO DO PRIMEIRA STRUCT, CARREGANDO AS STRUCTS DO ARQUIVO PARA O PROGRAMA //
	if(!(fp = fopen("pessoas.bin", "rb+")))
		if(!(fp = fopen("pessoas.bin", "wb+")))
			return 1;

	fseek(fp, 0, SEEK_END);
	tam = ftell(fp)/sizeof(registro);

	if(tam)
	{
		u_cadastrados = tam;
		fseek(fp, 0, SEEK_SET);
		for(i=0; i<tam; i++)
			fread(&reg[i], sizeof(registro), 1, fp);
	}

 // INICIALIZAÇÃO DA SEGUNDA STRUCT, CARREGANDO AS STRUCTS DO ARQUIVO PARA O PROGRAMA //
	if(!(fp2 = fopen("obras.bin", "rb+")))
		if(!(fp2 = fopen("obras.bin", "wb+")))
			return 1;

	fseek(fp2, 0, SEEK_END);
	tam2 = ftell(fp2)/sizeof(obras);

	if(tam2)
	{
		o_cadastradas = tam2;
		fseek(fp2, 0, SEEK_SET);
		for(i=0; i<tam2; i++)
			fread(&ob[i], sizeof(obras), 1, fp2);
	}

// INICIALIZAÇÃO DA TERCEIRA STRUCT, CARREGANDO AS STRUCTS DO ARQUIVO PARA O PROGRAMA //
	if(!(fp3 = fopen("emprestimos.bin", "rb+")))
		if(!(fp3 = fopen("emprestimos.bin", "wb+")))
			return 1;

	fseek(fp3, 0, SEEK_END);
	tam3 = ftell(fp3)/sizeof(emprestimo);

	if(tam3)
	{
		e_totais = tam3;
		fseek(fp3, 0, SEEK_SET);
		for(i=0; i<tam3; i++)
			fread(&emp[i], sizeof(emprestimo), 1, fp3);
	}


	while(i!=2)
	{
		printf("SISTEMA BIBLIOTECÁRIO\n\nLista de ações que podem ser realizadas:\n[1] Cadastro de Usuários\n[2] Cadastro de Obras\n[3] Empréstimos e Devoluções\n[4] Relatórios\nQual operação deseja realizar? "); // MENU PRINCIPAL
		scanf("%d", &op);
		switch(op)
		{
			case 1:                            // CORRESPONDE A OPÇÃO DO MENU PRINCIPAL
				system("clear");			// MENU DE CADASTRO DE USUÁRIO
				printf("CADASTRO DE USUÁRIOS\n\nLista de ações que podem ser realizadas:\n[1] Cadastrar novo usuário\n[2] Atualizar cadastro\n[3] Consultar usuário (por matrícula)\n[4] Apagar usuário (fisicamente)\n\nQual operação deseja realizar? ");
				scanf("%d", &ops1);
				switch(ops1)
				{
					case 1:				// CADASTRA NOVO USUÁRIO
						system("clear");
						printf("CADASTRAR NOVO USUÁRIO\n\n");	
						printf("Nome: ");
						setbuf(stdin, NULL);
						fgets(reg[n].nome, 50, stdin);
						j = 0; // LAÇO  DE CONSULTA DE DADO DUPLICADO
						while(j != u_cadastrados || strcmp(reg[j].nome, reg[n].nome) != 0 && n != 0)
						{
							if (strcmp(reg[j].nome, reg[n].nome) == 0 && n!=0)
							{
									printf("Este nome já existe no sistema.\n");
									while(strcmp(reg[j].nome, reg[n].nome) == 0)
									{
										printf("Nome: ");
										setbuf(stdin, NULL);
										fgets(reg[n].nome, 50, stdin);
									}
								
							}
							j++;
						}
						printf("Endereço: ");
						setbuf(stdin, NULL);
						fgets(reg[n].ender, 70, stdin);
						printf("CPF: ");
						setbuf(stdin, NULL);
						fgets(reg[n].cpf, 13, stdin);
						j = 0; // LAÇO DE CONSULTA DE DADO DUPLICADO
						while(j != u_cadastrados || strcmp(reg[j].cpf, reg[n].cpf) != 0 && n != 0)
						{
							if (strcmp(reg[j].cpf, reg[n].cpf) == 0 && n!=0)
							{
								printf("Este CPF já existe no sistema.\n");
								while(strcmp(reg[j].cpf, reg[n].cpf) == 0)
								{
									printf("CPF: ");
									setbuf(stdin, NULL);
									fgets(reg[n].cpf, 13, stdin);
								}
							
							}
							j++;
						}
						printf("RG: ");
						setbuf(stdin, NULL);
						scanf("%li", &reg[n].id);
						j=0;
						while(j != u_cadastrados || reg[j].id != reg[n].id && n != 0)
						{
							if (reg[j].id == reg[n].id && n!=0)
							{
									printf("Este RG já existe no sistema.\n");
									while(reg[j].id == reg[n].id)
									{
										printf("RG: ");
										scanf("%li", &reg[n].id);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Bairro: ");
						setbuf(stdin, NULL);
						fgets(reg[n].bairro, 30, stdin);						
						printf("Sexo - (M) Masculino, (F) Feminino: ");
						setbuf(stdin, NULL);
						scanf("%c", &reg[n].sexo);
						printf("Data de nascimento: ");
						scanf("%li", &reg[n].nascimento);
						printf("Data da adesão: ");
						scanf("%li", &reg[n].adesao);
						printf("Status - (0) Normal, (1) Suspenso: ");
						scanf("%d", &reg[n].status);
						if(reg[n].status == 1)
						{
							printf("Término da suspensão: ");
							scanf("%li", &reg[n].suspensao);
						}
						printf("Volumes emprestados [0,4]: ");
						scanf("%d", &reg[n].volumes);
						if(reg[n].volumes > 4 || reg[n].volumes < 0)
							while(reg[n].volumes > 4 || reg[n].volumes < 0) // VERIFICA SE O USUÁRIO DIGITOU O VALOR CORRETO
							{
								printf("Valor inválido, o intervalo de valores disponíveis é de 0 à 4.\n");
								printf("Volumes emprestados [0,4]: ");
								scanf("%d", &reg[n].volumes);
							}
						printf("Telefone celular: ");
						scanf("%li", &reg[n].cel);
						setbuf(stdin, NULL);
						j=0;
						while(j != u_cadastrados || reg[j].cel != reg[n].cel && n!= 0)
						{
							if (reg[j].cel == reg[n].cel)
							{
									printf("Este telefone celular já existe no sistema.\n");
									while(reg[j].cel == reg[n].cel)
									{
										printf("Telefone celular: ");
										scanf("%li", &reg[n].cel);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Telefone residencial: ");
						scanf("%li", &reg[n].tel);
						j=0;
						while(j != u_cadastrados || reg[j].tel != reg[n].tel && n!=0)
						{
							if (reg[j].tel == reg[n].tel)
							{
									printf("Este telefone residencial já existe no sistema.\n");
									while(reg[j].tel == reg[n].tel)
									{
										printf("Telefone residencial: ");
										scanf("%li", &reg[n].tel);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Matrícula (até 4 dígitos): ");
						scanf("%d", &reg[n].matricula);
						j=0;
						while(j != u_cadastrados || reg[j].matricula != reg[n].matricula && n!=0)
						{
							if (reg[j].matricula == reg[n].matricula)
							{
									printf("Esta matrícula nº %d já existe no sistema.\n", reg[n].matricula);
									while(reg[j].matricula == reg[n].matricula)
									{
										printf("Matrícula (até 4 dígitos): ");
										scanf("%d", &reg[n].matricula);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Matrícula de usuário nº %d realizada com sucesso.\n", reg[n].matricula);
						n++; // PULA PRA PRÓXIMA POSIÇÃO DO VETOR
						u_cadastrados++; // VARIÁVEL QUE ARMAZENA A QUANTIDADE DE USUÁRIOS CADASTRADOS
						break;
					case 2:
						system("clear");
						key_atualizar = 0;
						printf("ATUALIZAR CADASTRO\n\n");
						printf("Digite o número de matrícula do usuário: ");
						scanf("%d", &key_atualizar); // CHAVE DE BUSCA
						i = 0;
						while(reg[i].matricula != key_atualizar && u_cadastrados != 0 && i != u_cadastrados) // LAÇO DE CONSULTA
						{
							i++;
						}
						if (i == u_cadastrados)
						{
							printf("Usuário não cadastrado.\n");
							break;
						}
						system("clear"); // CASO O USUÁRIO SEJA ENCONTRADO ATUALIZA AS INFORMAÇÕES DELE
						printf("ATUALIZAR USUÁRIO COM MATRÍCULA Nº %d\n\n",reg[i].matricula);	
						printf("Nome: ");
						setbuf(stdin, NULL);
						fgets(reg[i].nome, 50, stdin);
						while(j != u_cadastrados || strcmp(reg[j].nome, reg[i].nome) != 0 && i != 0)
						{
							if (strcmp(reg[j].nome, reg[i].nome) == 0 && n!=0 && u_cadastrados != 1)
							{
									printf("Este nome já existe no sistema.\n");
									while(strcmp(reg[j].nome, reg[i].nome) == 0)
									{
										printf("Nome: ");
										setbuf(stdin, NULL);
										fgets(reg[i].nome, 50, stdin);
									}
								
							}
							j++;
						}
						printf("Endereço: ");
						setbuf(stdin, NULL);
						fgets(reg[i].ender, 70, stdin);
						printf("CPF: ");
						setbuf(stdin, NULL);
						fgets(reg[i].cpf, 13, stdin);
						j = 0;
						while(j != u_cadastrados || strcmp(reg[j].cpf, reg[i].cpf) != 0 && i != 0)
						{
							if (strcmp(reg[j].cpf, reg[i].cpf) == 0 && n!=0 && u_cadastrados !=1)
							{
								printf("Este CPF já existe no sistema.\n");
								while(strcmp(reg[j].cpf, reg[i].cpf) == 0)
								{
									printf("CPF: ");
									setbuf(stdin, NULL);
									fgets(reg[i].cpf, 13, stdin);
								}
							
							}
							j++;
						}
						printf("RG: ");
						setbuf(stdin, NULL);
						scanf("%li", &reg[i].id);
						j=0;
						while(j != u_cadastrados || reg[j].id != reg[i].id && i!= 0)
						{
							if (reg[j].id == reg[i].id && n!=0 && u_cadastrados !=1)
							{
									printf("Este RG já existe no sistema.\n");
									while(reg[j].id == reg[i].id)
									{
										printf("RG: ");
										setbuf(stdin, NULL);
										scanf("%li", &reg[i].id);
									}
								
							}
							j++;
						}
						printf("Bairro: ");
						setbuf(stdin, NULL);
						fgets(reg[i].bairro, 30, stdin);						
						printf("Sexo - (M) Masculino, (F) Feminino: ");
						setbuf(stdin, NULL);
						scanf("%c", &reg[i].sexo);
						printf("Data de nascimento: ");
						scanf("%li", &reg[i].nascimento);
						printf("Data da adesão: ");
						scanf("%li", &reg[i].adesao);
						printf("Status - (0) Normal, (1) Suspenso: ");
						scanf("%d", &reg[i].status);
						if(reg[i].status == 1)
						{
							printf("Término da suspensão: ");
							scanf("%li", &reg[i].suspensao);
						}
						printf("Volumes emprestados [0,4]: ");
						scanf("%d", &reg[i].volumes);
						printf("Telefone celular: ");
						scanf("%li", &reg[i].cel);
						j=0;
						while(j != u_cadastrados || reg[j].cel != reg[i].cel && i!= 0)
						{
							if (reg[j].cel == reg[i].cel && n!=0 && u_cadastrados !=1)
							{
									printf("Este telefone celular já existe no sistema.\n");
									while(reg[j].cel == reg[i].cel)
									{
										printf("Telefone celular: ");
										scanf("%li", &reg[i].cel);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Telefone residencial: ");
						scanf("%li", &reg[i].tel);
						j=0;
						while(j != u_cadastrados || reg[j].tel != reg[i].tel && i!=0)
						{
							if (reg[j].tel == reg[i].tel && n!=0 && u_cadastrados !=1)
							{
									printf("Este telefone residencial já existe no sistema.\n");
									while(reg[j].tel == reg[i].tel)
									{
										printf("Telefone residencial: ");
										scanf("%li", &reg[i].tel);
										setbuf(stdin, NULL);
									}
								
							}
							j++;
						}
						printf("Cadastro atualizado com sucesso!\n");
						break;
					case 3:
						system("clear");
						key_consultar = 0;
						printf("CONSULTAR USUÁRIO\n\n");
						printf("Digite o número de matrícula do usuário: ");
						scanf("%d", &key_consultar);    // CHAVE DE BUSCA
						i = 0;
						while(reg[i].matricula != key_consultar && u_cadastrados != 0 && i != u_cadastrados)
						{
							i++;
						}
						if (i == u_cadastrados)
						{
							printf("Usuário não cadastrado.\n");
							break;
						}
						if (reg[i].matricula == key_consultar) // CASO ENCONTRE O USUÁRIO EXIBE AS INFORMAÇÕES NA TELA
							printf("INFORMAÇÕES DO USUÁRIO\n\nNOME: %sENDEREÇO: %sCPF: %sBAIRRO: %sSEXO: %c\nNASCIMENTO: %li\nMATRÍCULA: %d\nIDENTIDADE: %d\nDATA DE ADESÃO: %li\nTELEFONE RESIDENCIAL: %li\nTELEFONE CELULAR: %li\nSTATUS: %d\nTÉRMINO DA SUSPENSÃO: %li\nVOLUMES EMPRESTADOS: %d LIVRO(S)\n", reg[i].nome, reg[i].ender, reg[i].cpf, reg[i].bairro, reg[i].sexo, reg[i].nascimento, reg[i].matricula, reg[i].id, reg[i].adesao, reg[i].tel, reg[i].cel, reg[i].status, reg[i].suspensao, reg[i].volumes);
						break;
					case 4:
						system("clear");
						key_apagar = 0;
						printf("APAGAR USUÁRIO(físicamente)\n\n");
						printf("Digite o número de matrícula do usuário: ");
						scanf("%d", &key_apagar); // CHAVE DE BUSCA
						i = 0;
						while(reg[i].matricula != key_apagar && u_cadastrados != 0 && i != u_cadastrados)
						{
							i++;
						}
						if (i == u_cadastrados)
						{
							printf("Usuário não cadastrado.\n");
							break;
						}

						// REPOSICIONA O VETOR E APAGA O CONTEÚDO QUE EXISTE NELE
						if (reg[i].matricula == key_apagar)
						{
							reg[i] = reg[u_cadastrados-1];
							strcpy(reg[u_cadastrados-1].nome, "");
							strcpy(reg[u_cadastrados-1].ender, "");
							strcpy(reg[u_cadastrados-1].cpf, "");
							strcpy(reg[u_cadastrados-1].bairro, "");
							reg[u_cadastrados-1].sexo = '0';
							reg[u_cadastrados-1].nascimento = 0;
							reg[u_cadastrados-1].matricula = 0;
							reg[u_cadastrados-1].id = 0;
							reg[u_cadastrados-1].adesao = 0;
							reg[u_cadastrados-1].tel = 0;
							reg[u_cadastrados-1].cel = 0;
							reg[u_cadastrados-1].status = 0;
							reg[u_cadastrados-1].suspensao = 0;
							reg[u_cadastrados-1].volumes = 0;
							n--;
							u_cadastrados--;
							printf("Usuário apagado do sistema com sucesso!\n");
						}
						break;			
					default:
						printf("Operação inválida.\n\n");
						break;
				}
					break;
				case 2:
					system("clear"); // MENU DE CADASTRO DE OBRAS
					printf("CADASTRO DE OBRAS\n\nLista de ações que podem ser realizadas:\n[1] Cadastrar nova obra\n[2] Alterar status\n[3] Consultar obra (por título)\n[4] Apagar obra (fisicamente)\n\nQual operação deseja realizar? ");
					scanf("%d", &ops2);
					switch(ops2)
					{
						case 1:
							system("clear");
							printf("CADASTRAR NOVA OBRA\n\n"); // CADASTRAR NOVA OBRA
							printf("Código: ");
							setbuf(stdin, NULL);
							scanf("%d", &ob[no].codigo); // CONSULTA SE HÁ CÓDIGO REPETIDO
							j=0;
							while(j != o_cadastradas || ob[j].codigo != ob[no].codigo && no!= 0)
							{
								if (ob[j].codigo == ob[no].codigo)
								{
										printf("Este código já existe no sistema.\n");
										while(ob[j].codigo == ob[no].codigo)
										{
											printf("Código: ");
											scanf("%d", &ob[no].codigo);
											setbuf(stdin, NULL);
										}
									
								}
								j++;
							}
							printf("Título: ");
							setbuf(stdin, NULL);
							fgets(ob[no].titulo, 80, stdin);
							j=0; 
							while(j != o_cadastradas || strcmp(ob[j].titulo, ob[no].titulo) != 0 && no!=0) // CONSULTA SE EXISTE TÍTULO IGUAL, CASO EXISTA COPIA O CÓDIGO ISBN DE UM QUE JÁ FOI CADASTRADO PARA O CORRENTE
							{
								if (strcmp(ob[j].titulo, ob[no].titulo) == 0)
								{
									strcpy(ob[no].isbn,ob[j].isbn);
								}
								j++;
							}
							if (strcmp(ob[j].titulo, ob[no].titulo) != 0 || no==0) // SE NÃO EXISTIR TÍTULO IGUAL APENAS SOLICITA O CÓDIGO ISBN PARA O USUÁRIO
							{
								printf("ISBN: ");
								setbuf(stdin, NULL);
								fgets(ob[no].isbn, 12, stdin);	
							}
							printf("Autores: ");
							setbuf(stdin, NULL);
							fgets(ob[no].autores, 100, stdin);
							printf("Assunto: ");
							setbuf(stdin, NULL);
							fgets(ob[no].assunto, 80, stdin);
							printf("Editora: ");
							setbuf(stdin, NULL);
							fgets(ob[no].editora, 50, stdin);
							printf("Ano da publicação: ");
							setbuf(stdin, NULL);
							scanf("%d", &ob[no].ano);
							printf("Edição: ");
							setbuf(stdin, NULL);
							scanf("%d", &ob[no].ed);
							printf("Status - (0) Disponível (1) Emprestado (2) Manutenção: ");
							setbuf(stdin, NULL);
							scanf("%d", &ob[no].status);
							no++;
							o_cadastradas++;
							break;
						case 2:
							system("clear");
							key_status = 0;
							printf("ALTERAR STATUS\n\n");
							printf("Digite o código da obra: ");
							scanf("%d", &key_status);
							i = 0;
							while(ob[i].codigo != key_status && o_cadastradas != 0 && i != o_cadastradas)
							{
								i++;
							}
							if (i == o_cadastradas)
							{
								printf("Nenhuma obra vinculada à este código.\n");
								break;
							}
							if (ob[i].status == 1)
							{
								printf("Este livro foi emprestado à algum usuário.\n");
								break; 
							}
							printf("Digite o novo status: ");
							scanf("%d", &ob[i].status);
							if(ob[i].status == 1)
							{
								printf("Essa opção de status, só pode ser alterada na sessão de Empréstimos.\n");
								while(ob[i].status == 1)
								{
									printf("Digite o novo status: ");
									scanf("%d", &ob[i].status);
								}
							}
							printf("Status atualizado com sucesso!\n");
							break;
						case 3:
							system("clear");
							key_consultar = 0;
							printf("CONSULTAR OBRA\n\n");
							printf("Digite o código da obra: ");
							scanf("%d", &key_consultar); // CHAVE DE BUSCA
							i = 0;
							while(ob[i].codigo != key_consultar && o_cadastradas != 0 && i != o_cadastradas) // CONSULTA E EXIBE AS INFORMAÇÕES NA TELA SE ENCONTRAR O CÓDIGO DA OBRA
							{
								i++;
							}
							if (i == o_cadastradas)
							{
								printf("Nenhuma obra vinculada à este código.\n");
								break;
							}
							if (ob[i].codigo == key_consultar)
								printf("INFORMAÇÕES DA OBRA\n\nCÓDIGO: %d\nISBN: %sTÍTULO: %sAUTORES: %sASSUNTO: %sEDITORA: %sANO DA PUBLICAÇÃO: %d\nEDIÇÃO: %d\nSTATUS: ", ob[i].codigo, ob[i].isbn, ob[i].titulo, ob[i].autores, ob[i].assunto, ob[i].editora, ob[i].ano, ob[i].ed);
							if(ob[i].status == 0)
								printf("Disponível\n");
							if(ob[i].status == 1)
								printf("Emprestado\n");
							if(ob[i].status == 2)
								printf("Em manutenção\n");
							break;
						case 4:
							system("clear");
							key_apagar = 0;
							printf("APAGAR OBRA\n\n");
							printf("Digite o código da obra: ");
							scanf("%d", &key_apagar);   // CHAVE DE BUSCA
							i = 0;
							while(ob[i].codigo != key_apagar && o_cadastradas != 0 && i != o_cadastradas)
							{
								i++;
							}
							if (i == o_cadastradas)
							{
								printf("Nenhuma obra vinculada à este código.\n");
								break;
							}
							if (ob[i].codigo == key_consultar)
							{
								if(ob[i].status != 0 && ob[i].status != 2) // VERIFICA SE NÃO ESTÁ VINCULADA À NENHUM USUÁRIO
								{
									printf("A obra não pode ser apagada, pois está emprestada para algum usuário!\n");
									break;
								} // O PROCESSO DE EXCLUSÃO DE DADOS É O MESMO DOS USUÁRIOS
									ob[i] = ob[o_cadastradas-1];
									strcpy(ob[o_cadastradas-1].isbn, "");
									strcpy(ob[o_cadastradas-1].titulo, "");
									strcpy(ob[o_cadastradas-1].autores, "");
									strcpy(ob[o_cadastradas-1].assunto, "");
									strcpy(ob[o_cadastradas-1].editora, "");
									ob[o_cadastradas-1].status = 0;
									ob[o_cadastradas-1].codigo = 0;
									ob[o_cadastradas-1].ed = 0;
									ob[o_cadastradas-1].ano = 0;
									no--;
									o_cadastradas--;
									printf("Obra apagada do sistema com sucesso!\n");
							}
							break;
						default:
							printf("Operação inválida.\n");
							break;
					}
						break;
				case 3:
					system("clear");
					printf("EMPRÉSTIMOS E DEVOLUÇÕES\n\nLista de ações que podem ser realizadas:\n[1] Emprestar\n[2] Devolver\n\nQual operação deseja realizar? ");
					int ops3;
					scanf("%d", &ops3);
					switch(ops3)
					{
						case 1:
						system("clear");
						key_consultar = 0;
						printf("EMPRESTAR\n\n");
						printf("Digite o número de matrícula do usuário: ");
						scanf("%d", &key_consultar);
						i = 0;
						while(reg[i].matricula != key_consultar && u_cadastrados != 0 && i != u_cadastrados)
						{
							i++;
						}
						if (i == u_cadastrados)
						{
							printf("Usuário não cadastrado.\n");
							break;
						}
						if (reg[i].matricula == key_consultar)
						{
							if(reg[i].status == 1)
							{
								char data[8], dia[3], mes[3], ano[5]; // ESTE PROCESSO É PARA DIVISÃO DO NÚMERO NO FORMATO DD/MM/AAAA
								sprintf(data, "%li", reg[i].suspensao);
								dia[0] = data[0];
								dia[1] = data[1];
								dia[2] = '\0';
								mes[0] = data[2];
								mes[1] = data[3];
								mes[2] = '\0';
								ano[0] = data[4];
								ano[1] = data[5];
								ano[2] = data[6];
								ano[3] = data[7];
								ano[4] = '\0';
								int diaI = atoi(dia), mesI = atoi(mes), anoI = atoi(ano);
									if(anoI <= tm.tm_year + 1900) // ESTE PROCESSEO VERIFICA A DATA DADA COM A DATA ATUAL PARA VERIFICAR SE A SUSPENSÃO ACABOU OU NÃO
									{
										if(mesI <= tm.tm_mon + 1)
										{
											if(diaI <= tm.tm_mday)
											{
												break;
											}else
												{
													printf("Empréstimo não pode ser realizado. Usuário encontra-se suspenso até %d/%d/%d.\n", diaI, mesI, anoI);
													break;
												}
										}else
											{
												printf("Empréstimo não pode ser realizado. Usuário encontra-se suspenso até %d/%d/%d.\n", diaI, mesI, anoI); 
												break;												
											}
									}else
										{
											printf("Empréstimo não pode ser realizado. Usuário encontra-se suspenso até %d/%d/%d.\n", diaI, mesI, anoI);
											break;
										}
								break;	
							}
							else
								{
									if(reg[i].volumes == 4) // VERIFICA SE O USUÁRIO JÁ TEM A QUANTIDADE MÁXIMA DE VOLUMES
									{
										printf("Usuário já possui 4 livros em seu poder.\n");
										break;
									}		
								}
						}
							int suspendeu = 0;
 							if(reg[i].status == 0)  // CASO O USUÁRIO NÃO TENHA SIDO SUSPENSO, MAS TENHA ALGUM LIVRO EM ATRASO ESTE PROCESSO IDENTIFICA ESSE ATRASO COMPARANDO A DATA DE DEVOLUÇÃO COM A DATA ATUAL DOS LIVROS QUE TEM COMO EMPRÉSTIMO E SUSPENDE O USUÁRIO
							{
								j = 0;
								while(j != e_totais && e_totais != 0)
								{
									while(reg[i].matricula != emp[j].matricula && u_cadastrados != 0 && j != e_totais)
									{
										j++;
									}
									j++;
									if(reg[i].matricula == emp[j].matricula && e_totais != 0)
									{
										char dev[8], diad[3], mesd[3],anod[3];
										sprintf(dev, "%li",emp[ne].dev);
										diad[0] = dev[0];
										diad[1] = dev[1];
										diad[2] = '\0';
										mesd[0] = dev[2];
										mesd[1] = dev[3];
										mesd[2] = '\0';
										anod[0] = dev[4];
										anod[1] = dev[5];
										anod[2] = dev[6];
										anod[4] = dev[7];
										anod[5] = '\0';
										diadI = atoi(diad);
										mesdI = atoi(mesd);
										anodI = atoi(anod);
										if(anodI <= tm.tm_year + 1900)
										{
											if(mesdI <= tm.tm_mon + 1)
											{
												if(diadI <= tm.tm_mday)
												{
													break;
												}else
													{
														suspendeu = 1;
														reg[i].status = 1;
														break;
													}
											}else
												{
													suspendeu = 1;
													reg[i].status = 1; 
													break;												
												}
										}else
											{
												suspendeu = 1;
												reg[i].status = 1;
												break;
											}
								}

							}

 						// ACRESCENTA-SE 30 DIAS NA DATA (TEMPO DA SUSPENSÃO)
						if(suspendeu == 1)
						{
							diadI + 30;
							switch(mesdI)
							{
								case 1:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 2:
								     if(diadI > 28)
									{
										diadI = diadI-28;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 3:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 4:
									if(diadI > 30)
									{
										diadI = diadI-30;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 5:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 6:
									if(diadI > 30)
									{
										diadI = diadI-30;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}
								case 7:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}		
								case 8:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}		
								case 9:
									if(diadI > 30)
									{
										diadI = diadI-30;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}		
								case 10:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}		
								case 11:
									if(diadI > 30)
									{
										diadI = diadI-30;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}		
								case 12:
									if(diadI > 31)
									{
										diadI = diadI-31;
										mesdI++;
											if(mesdI > 12)
											{
												anodI++;
												mesdI = 0;
											}
										break;
									}				
							}
							char datasus[8];
							printf("Empréstimo não pode ser realizado. Usuário encontra-se suspenso até %d/%d/%d.\n", diadI, mesdI, anodI);
							sprintf(datasus, "%d%d%d", diadI, mesdI, anodI);
							reg[i].suspensao = 0;
							reg[i].suspensao = atol(datasus); // ATUALIZA A DATA DE SUSPENSÃO DO USUÁRIO
							
						}
			}	
						// CASO O USUÁRIO NÃO TENHA NENHUMA SUSPENSÃO VERIFICA-SE SE A OBRA ESTÁ DISPONÍVEL
						if(suspendeu == 0)
						{
							printf("Digite o código da obra: ");
							scanf("%d", &key_consultar);
							int k = 0;
							while(ob[k].codigo != key_consultar && o_cadastradas != 0 && k != o_cadastradas)
							{
								k++;
							}
							if (k == o_cadastradas)
							{
								printf("Empréstimo não pode ser realizado. Volume inexistente.\n");
								break;
							}
							if (ob[k].codigo == key_consultar)
							{
								if(ob[k].status != 0)
									printf("Empréstimo não pode ser realizado. Volume indisponível no momento.\n");
								else
								{
									printf("Usuário sem suspensão e livro disponível, digite a data de devolução: ");
									scanf("%li", &emp[ne].dev);
									emp[ne].codigo = ob[k].codigo;
									strcpy(emp[ne].titulo, ob[k].titulo);
									ob[k].status = 1;
									char data_e[8];
									sprintf(data_e, "%d%d%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
									emp[ne].empres = atol(data_e);
									emp[ne].matricula = reg[i].matricula;
									reg[i].volumes++;
									ne++;
									e_totais++;
									break;
									// SE TODAS AS VERIFICAÇÕES FOREM VÁLIDADAS AS INFORMAÇÕES DA OBRA E DO USUÁRIO SÃO CADASTRADAS NA STRUCT DE EMPRÉSTIMOS
								}
							}
						}
						case 2:
							system("clear");
							printf("DEVOLVER\n\n");
							printf("Digite o código da obra: ");
							scanf("%d", &key_consultar); // CHAVE DE BUSCA
							i = 0;
							while(ob[i].codigo != key_consultar && o_cadastradas != 0 && i != o_cadastradas)
							{
								i++;
							}
							if (i == o_cadastradas)
							{
								printf("Erro: Código inválido.\n");
								break;
							}
							i = 0; // VERIFICA SE O LIVRO ESTÁ EMPRESTADO À ALGUÉM
							while(emp[i].codigo != key_consultar && e_totais != 0 && i != e_totais)
							{
								i++;
							}
							if(i == e_totais)
							{
								printf("Não tem nenhum usuário em posse deste livro.\n");
							}
							if(emp[i].codigo == key_consultar)
							{
								j=0;
								while(emp[i].matricula != reg[j].matricula && e_totais != 0)
								{
									j++;
								}
								if(emp[i].matricula == reg[j].matricula) // ENCONTRA O USUÁRIO NO QUAL A OBRA ESTÁ EMPRESTADA E TIRA UM VOLUME DELE, POIS ESTÁ DEVOLVENDO O MESMO
								{
									reg[j].volumes--;
								} // PROCESSO QUE VERIFICA SE A DEVOLUÇÃO FOI EM ATRASO, SEMELHANTE AO USADO NA CATEGORIA DE EMPRÉSTIMO
								char data_Dev[8], dia_Dev[3], mes_Dev[3], ano_Dev[5];
								sprintf(data_Dev, "%li", emp[i].dev);
								dia_Dev[0] = data_Dev[0];
								dia_Dev[1] = data_Dev[1];
								dia_Dev[2] = '\0';
								mes_Dev[0] = data_Dev[2];
								mes_Dev[1] = data_Dev[3];
								mes_Dev[2] = '\0';
								ano_Dev[0] = data_Dev[4];
								ano_Dev[1] = data_Dev[5];
								ano_Dev[2] = data_Dev[6];
								ano_Dev[3] = data_Dev[7];
								ano_Dev[4] = '\0';
								int diaDev_I = atoi(dia_Dev), mesDev_I = atoi(mes_Dev), anoDev_I = atoi(ano_Dev);
								suspendeu = 0;
								if(anoDev_I <= tm.tm_year + 1900)
								{
									if(mesDev_I <= tm.tm_mon + 1)
									{
										if(diaDev_I <= tm.tm_mday)
										{
											break;
										}else
											{
												suspendeu = 1;
												reg[j].status = 1;
											}
									}else
										{
											suspendeu = 1;
											reg[j].status = 1; 										
										}
								}else
									{
										suspendeu = 1;
										reg[j].status = 1;
									}
						
						if(suspendeu == 1)
						{
							diaDev_I + 30;
							switch(mesDev_I)
							{
								case 1:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 2:
									if(diaDev_I > 28)
									{
										diaDev_I = diaDev_I-28;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 3:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 4:
									if(diaDev_I > 30)
									{
										diaDev_I = diaDev_I-30;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 5:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 6:
									if(diaDev_I > 30)
									{
										diaDev_I = diaDev_I-30;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 7:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 8:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}	
								case 9:
									if(diaDev_I > 30)
									{
										diaDev_I = diaDev_I-30;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 10:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}
								case 11:
									if(diaDev_I > 30)
									{
										diaDev_I = diaDev_I-30;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}		
								case 12:
									if(diaDev_I > 31)
									{
										diaDev_I = diaDev_I-31;
										mesDev_I++;
											if(mesDev_I > 12)
											{
												anoDev_I++;
												mesDev_I = 0;
											}
										break;
									}				
							}
								sprintf(data_Dev, "%d%d%d", diaDev_I, mesDev_I, anoDev_I);
								reg[j].suspensao = atol(data_Dev);
								break;							
				case 4:
					printf("RELATÓRIOS\n\n");
					char dataReal[] = "Data";
					char cabec[] = "Relatórios de livros emprestados";
					char titulo[] = "Título";
					char codigo[] = "Código";
					char usuario[] = "Usuário";
					char devolucao[] = "Devolução";
					char telefone[] = "Telefone";
					fpt = fopen("relatorios.txt", "a");
					fprintf(fpt,"\n%-90.40s  	%-1.4s: %d/%d/%d\n\n", cabec, dataReal, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
					printf("----------------------------------------------------------------------------------------------------------------------------\n");
					fprintf(fpt, "%-50.50s | %-6.10s | %-35.35s | %-10.11s | %-10.11s \n", titulo, codigo, usuario, devolucao, telefone);
			printf("----------------------------------------------------------------------------------------------------------------------------\n");
					j=0;
					while(j != e_totais && e_totais != 0)
					{
						i=0;
						while(i != u_cadastrados && emp[j].matricula!= reg[i].matricula && i!=0)
						{
							i++;
						}
						if(emp[j].matricula == reg[i].matricula)
						{
							char dataRel[8], diaRel[3], mesRel[3], anoRel[5];
							sprintf(dataRel, "%li", emp[j].dev);
							diaRel[0] = dataRel[0];
							diaRel[1] = dataRel[1];
							diaRel[2] = '\0';
							mesRel[0] = dataRel[2];
							mesRel[1] = dataRel[3];
							mesRel[2] = '\0';
							anoRel[0] = dataRel[4];
							anoRel[1] = dataRel[5];
							anoRel[0] = dataRel[6];
							anoRel[1] = dataRel[7];
							anoRel[2] = '\0';
							int diaRel_I = atoi(diaRel), mesRel_I = atoi(mesRel), anoRel_I = atoi(anoRel);
							
							fprintf(fpt, "%-50.50s | %-6.10d | %-35.35s | %-0.2d/%-0.2d/%-0.2d- | %-10.11li \n", emp[j].titulo, emp[j].codigo, reg[i].nome, diaRel_I, mesRel_I, anoRel_I, reg[i].tel);
						}
						j++;
					}
					fprintf(fpt, "\f");
					fclose(fpt);
					break;
				default:
					printf("Operação inválida.\n");
					break;
				}
			}
		}
	}
		printf("Deseja continuar escolhendo opções? [1] Sim [2] Não\n");
		scanf("%d", &i);
		system("clear");
	}	
	// SALVANDO STRUCTS DE USUÁRIOS NOS ARQUIVOS //
	freopen("pessoas.bin", "wb+", fp);

	fseek(fp, 0, SEEK_SET);
	for(i=0; i<u_cadastrados; i++)
		fwrite(&reg[i], sizeof(registro), 1, fp);
	fclose(fp);

	// SALVANDO STRUCTS DE OBRAS NOS ARQUIVOS //
	freopen("obras.bin", "wb+", fp2);

	fseek(fp2, 0, SEEK_SET);
	for(i=0; i<o_cadastradas; i++)
		fwrite(&ob[i], sizeof(obras), 1, fp2);
	fclose(fp2);

	// SALVANDO STRUCTS DE OBRAS NOS ARQUIVOS //
	freopen("emprestimos.bin", "wb+", fp3);

	fseek(fp3, 0, SEEK_SET);
	for(i=0; i<e_totais; i++)
		fwrite(&emp[i], sizeof(emprestimo), 1, fp3);
	fclose(fp3);

	return 0;
}

