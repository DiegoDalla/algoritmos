#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	//Valor é a var. que sera apontada pelo ponteiro
	//25 é um número aleatório
	int valor = 25;
	
	//Declarando a variavel ponteiro do tipo inteiro
	int *ptr;
	
	//Atribuindo o endereço de memoria da variavel valor para ponteiro
	ptr = &valor;
	
	printf("Ultilizando ponteiro...\n");
	printf("Conteudo da variavel 'valor' --> %d\n", valor);
	printf("Endereço da variavel valor --> %x\n", &valor); //'%x' é para valores hexadecimais
	printf("Conteudo da variavel 'ptr' --> %x", ptr);
	
	return 0;
}
