//Uso da 'strstr', a função compara duas strings e devolve (caso exista uma igualdade) , um ponteiro justo onde a substring esta dentro da string

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int n;
    char str1[101] , str2[101];
    int len1=0 , len2=0;
    
    printf("Informe o número de pares de entradas desejado: ");
    scanf("%d", &n);
    getchar();
    
    for(int i = 0 ; i < n ; i++)
    {
        printf("Informe a 1º string:\n");
        fgets(str1, 100, stdin);
		printf("Informe a 2º string:\n");
        fgets(str2, 100, stdin);
        printf("\n");
        
        //Remove a quebra de linha da 1º string
        len1 = strlen(str1);
        if((len1 > 0) && (str1[len1 - 1] == '\n'))
            str1[--len1] = 0;
        //Remove a quebra de linha da 2º string
        len2 = strlen(str2);
        if((len2 > 0) && (str2[len2 - 1] == '\n'))
            str2[--len2] = 0;
        
        
        if((strstr(str1 , str2)-str1) == 0)
            printf("\nAmbas strings são iguais.\n");
        else if((strstr(str1 , str2)-str1) > 0)
            printf("\n'%s' ocorre na posição %ld de '%s'\n", str2 ,strstr(str1 , str2)-str1, str1);
        else if((strstr(str1 , str2)-str1) < 0)
            printf("\n'%s' não ocorre em '%s'\n",str2,str1);
        
        
        printf("\n------------------------------------------------\n");
    }
    
    return 0;
}
