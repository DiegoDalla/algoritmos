#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* ultimoNome (char *string)
{
	// DECLARAÇÃO DE VARIÁVEIS
	int i=0, j=0, tmun=0; // contadores
	int tamanho = strlen(string); //tamanho da string passada por parâmetro para alocar memória na string de retorno
	char *aux=(char*)malloc(strlen(string)*sizeof(char)); // string que vai retornar a abreviação completa
	char *aux2=(char*)malloc(strlen(string)*sizeof(char)); // auxiliar para fazer as abrevições da inicial de cada nome

	i = tamanho; // o tamanho da string é atribuido à variável i
	// LEITURA DO ÚLTIMO NOME
	while(string[i]!= ' ') // laço para ler a string do último caracter até o espaço para armazenar o tamanho do último nome
	{
		i--;
		tmun++;
	}
	int tmabr = tamanho-tmun; // salva o tamanho da string sem o último nome
	for (i = tmabr; i < tamanho; i++, j++) // laço para salvar o último nome na variável auxiliar, pois é o que é exibido primeiro
		aux[j] = string[i+1]; 

	// CONTADORES
	i=0; // zerando contador para usar novamente
	j=4; // o j começa em 4 devido a formatação que deve ser aplicada antes, com virgulas e espaços...

	// FORMATAÇÃO
	aux2[0] = ',';
	aux2[1] = ' '; 
	aux2[2] = string[0]; // exibe a abreviação do primeiro nome
	aux2[3] = '.'; 

	// RESPONSÁVEL POR LER A INICIAL DE CADA SOBRENOME
	while(i<tmabr) // o laço lê cada sobrenome exceto o último
	{
		if(string[i]== ' ') // quando a leitura encontrar um espaço ela salva o caracter que está a frente
		{
			if(string[i+1]!='d') // se o caracter que está a frente começar com a letra minúscula de ou da ele não é salvo
			{
				aux2[j] = string[i+1]; // salva o caracter da inicial do sobrenome no auxiliar
				aux2[j+1] = '.'; // acrescenta um ponto depois do caracter
				j+=2; // o j pula dois espaços, pois armazenou nesses dois os dados acima
			}
		}
		i++;
	}
	// FORMATANDO AUXILIAR PARA CONCATENAR
	int tamanhoaux = strlen(aux);
	aux[tamanhoaux-1] = '\0';

	// CONCATENAÇÃO DOS DOIS PARA EXIBIÇÃO
	strcat(aux, aux2);

	return aux;
}

int main()
{
	// DECLARAÇÃO DE VARIÁVEIS
	char nome[50];
	int n, j=0;	
	
    // LEITURA DA QUANTIDADE DE TESTES QUE SERÃO FEITOS
	scanf("%d", &n);
	getchar();

	// LAÇO QUE EXECUTA CADA TESTE
	while(j<n)
	{
		fgets(nome, 51, stdin);	
		printf("%s\n\n", ultimoNome(nome));
		j++;
	}

	return 0;
}
