#include <stdio.h>
#include <string.h>

int comparaStrings(char* str, char* str2)
{
	// DECLARAÇÃO DE VARIÁVEIS
	char straux[51], c;
	int tm, tm2, con, desl=0, i;	
		
		// TESTE PARA VER SE ELAS SÃO IGUAIS ANTES DE FAZER DESLOCAMENTOS
		if(!strcmp(str,str2)) // a função faz o primeiro teste analisando se as strings são iguais
		{
			return 0; // se forem iguais ele retorna 0 como é pedido na questão
		}else
			{
				tm = strlen(str); // armazena o tamanho da 1 string
				tm2 = strlen(str2); // armazena o tamanho da 2 string
				strcpy(straux, str); // copia a 1 string para um auxiliar para não alterar a string

						con = 0; // contador

						// FAZ A PERMUTAÇÃO CIRCULAR ATÉ A STRING AUXILIAR SER IGUAL A 2 STRING OU CASO ELAS NÃO FIQUEM IGUAIS APÓS DESLOCAMENTOS ATÉ PERMUTAR A STRING TODA
						while(strcmp(straux, str2) != 0 && con < tm-1) 
						{
							c = straux[0]; // armazena a primeira letra da palavra em um auxiliar
							for (i = 0; i < tm; i++)
							{
								straux[i] = straux[i+1]; // vai jogando o caracter da frente pro inicio
							}
							straux[i-1] = c; // coloca o primeiro caracter armazenado na variável no final da string
							
							con++;
						}
						// VERIFICA SE APÓS OS DESLOCAMENTOS AS STRINGS FICARAM IGUAIS
						if(!strcmp(straux, str2)) 
						{
							desl = con; // a variável desl recebe o valor do contador pois ele define quantas vezes foi permutado
						     return desl; // retorna o número de deslocamentos como pede a questão
						}else
							 return -1; // caso as strings sejam diferentes retorna -1 como é pedido na questão
			}
}

int main (int argc, char *argv[])
{
	// DECLARAÇÃO DE VARIÁVEIS
	int n, teste=1, j=0, tm, tm2;
	char str[51], str2[51];
    
	// LEITURA DA QUANTIDADE DE TESTES QUE SERÃO FEITOS
	scanf("%d", &n);
	getchar();

	// LAÇO QUE EXECUTA TODOS OS TESTES E EXIBE SEUS RESULTADOS
	while(j<n)
	{
		// LEITURA DAS STRINGS
		fgets(str, 50, stdin);
		fgets(str2, 50, stdin);

		// RETIRA O \N DO FINAL DA STRING QUE É SALVO AO USAR O FGETS
		tm = strlen(str);
		tm2 = strlen(str2);
		str[tm-1] = '\0';
		str2[tm2-1] = '\0';

		// VERIFICA OS VALORES RETORNADOS E EXIBE O RESULTADO DO TESTE		
		if(comparaStrings(str, str2) == 0)
			printf("\nTeste %d\nAs cadeias são iguais.\n\n", teste++);
		if(comparaStrings(str,str2) < 0)
			printf("\nTeste %d\nA cadeia %s não pode ser obtida a partir da cadeia %s por meio de deslocamentos.\n\n", teste++, str2, str);
		if(comparaStrings(str,str2) > 0)
			printf("\nTeste %d\nA cadeia %s pode ser obtida de %s após %d deslocamentos.\n\n", teste++, str2, str, comparaStrings(str, str2));
		j++;
	}		
	return 0;
}
