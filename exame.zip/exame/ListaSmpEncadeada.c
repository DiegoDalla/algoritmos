//*/*/*/*/Lista Dinamica Encadeada
//Cada elemento é tratado como um ponteiro que é'alocado a medida com que os dados sãoo inseridos
#include <stdio.h>
#include <stdlib.h>
/************************************************************/
//DEFININDO O NÓ
struct elemento
{
    int dados;
    struct elemento *prox;
};
typedef struct elemento Elem;
/************************************************************/
//DEFININDO A LISTA
typedef struct elemento* Lista;
/************************************************************/
//CRIA A LISTA
Lista* cria_lista()
{
    //Aloca memoria
    Lista* li = (Lista* /*Casting*/)malloc(sizeof(Lista));    
    //Como a lista acabou de ser criada
    //O primeiro nó aponta p/ NULL
    if(li != NULL)
    {
        *li = NULL;
    }
    return li;
}
/************************************************************/
//CRIA NÓ
Elem* criar_no()
{
    //Aloca um novo nó dinamicamente
    Elem *no = (Elem* /*Casting*/)malloc(sizeof(Elem));
    return no;
}
/************************************************************/
//LIBERA A LISTA free()
void libera_lista(Lista* li)
{
    //Se a lista existir
    if(li != NULL)
    {
        Elem* no;
        //Faz isso até que a lista esteja toda vazia
        while((*li) != NULL)
        {
            //nó recebe o inicio da lista
            no = *li;
            //Inicio da lista aponta p/ o proximo elemento
            *li = (*li)->prox;
            //Libera o antigo inicio
            free(no);
        }
        //Libera a cabeça da lista
        free(li);
    }
}
/************************************************************/
//TAMANHO DA LISTA
//Caso retorne 0 é que não funcionou
int tamanho_lista(Lista* li)
{
    if(li == NULL)
        return 0;
    int cont = 0; //Contador
    Elem* no = *li;
    //Nó funciona como um aux 
    //Assim não perdemos a referencia do inicio
    while(no != NULL)
    {
        cont++;
        //Incremento
        no = no->prox; 
    }   
    return cont;
}
/************************************************************/
//LISTA CHEIA
//A lista esta cheia somente quando acaba a memoria do pc
int lista_cheia(Lista* li)
{
    return 0;
}
/************************************************************/
//LISTA VAZIA
//1 = verdade   ||   0 = falso
int lista_vazia(Lista* li)
{
    //Esta vazia
    if(li == NULL)
        return 1;
    //Lista não tem elementos
    if(*li == NULL)
        return 1;    
    //Lista não esta vazia
    return 0;
}
/************************************************************/
//INSERÇÃO NO INICIO
//Caso retorne 0 é que não funcionou
int insere_lista_inicio(Lista* li , int dado)
{
    //Verifica se a lista é valida
    if(li == NULL)
        return 0;
    
    //Cria um nó
    Elem *no = criar_no();
    
    //Verifica se foi um sucesso a alocagem de memória
    if(no == NULL)
        return 0;
    //Copio o dado que recebi de parametro para dentro do nó
    no->dados = dado;    
    //O proximo recebe a propria lista
    //Serve para se for vazia ou não
    no->prox = (*li);    
    //Passo o novo nó como o primeiro elemento
    *li = no;    
    return 1;
}
/************************************************************/
//INSERÇÃO NO FINAL DA LISTA
//Caso retorne 0 é que não funcionou
int insere_lista_final(Lista* li , int dado)
{
    //Verifica se a lista é valida
    if(li == NULL)
        return 0;
    //Cria um nó
    Elem *no = criar_no();
    //Verifica se o nó foi criado corretamente
    if(no == NULL)
        return 0;
    //Atribuo o dado ao campo dados do no
    no->dados = dado;
    //Como é no final, o campo proximo aponta p/ NULL
    no->prox  = NULL;
    //Se for uma lista vazia
    //Vai ser o 1° e ultimo elemento
    //Ou seja o inicio aponta a ele e ele aponta p/ NULL
    if((*li) == NULL)
    {
        *li = no;
    }
    else
    {
        //Uso um aux para percorrer a lista
        Elem *aux = *li;
        //Vai até o ultimo elemento
        while(aux->prox != NULL)
        {
            aux = aux->prox; //incremento, de 1 em 1
        }
        aux->prox = no;
    }
    return 1;
}
/************************************************************/
//INSERÇÃO DE FORMA ORDENADA
//Caso retorne 0 é que não funcionou
int insere_lista_ordenada(Lista* li, int dado)
{
    //Verifica se a lista é valida
    if(li == NULL)
        return 0;
    //aloca memoria p/ nó
    Elem *no = criar_no();
    //Verifica se o nó foi alocado corretamente
    if(no == NULL)
        return 0;
    //Passo os dados que recebi como parametro p/ nó
    no->dados = dado;
    //Verifica se a lista é vazia
    if(lista_vazia(li) == 1)
    {
        //Nó recebe o inicio da lista
        no->prox = (*li);
        //Inicio da lista aponta para o nó
        *li = no;
        //Deu certo
        return 1;
    }
    //Se não for uma lista vazia
    else
    {
        //Cria 2 ptrs auxiliares
        Elem *ant , *atual = *li;
        //Enquanto meu atual for diferente da lista
        //e tambem o elemento da lista for menor do que eu quero inserir
        while(atual != NULL &&
              atual->dados < dado)
        {
            ant = atual;
            //Incremento
            atual = atual->prox;
        }
        //Se o atual for igual ao inicio
        //A gente não percorreu nada
        //Ou seja deve ser inserido no inicio da lista
        if(atual == *li)
        {
            no->prox = (*li);
            *li = no;
        }
        //Caso tiver percorrido
        //u a gente insere no final ou no meio
        else
        {
            no->prox = ant->prox;
            ant->prox = no;
        }
        //Funcionou
        return 1;
    }
}
/************************************************************/
//IMPRIMIR LISTA
void imprimir_lista(Elem *li)
{
    Elem *aux = li;
    while(aux != NULL)
    {
        printf("%d\n", aux->dados);
        aux=aux->prox;//Incremento
    }
}
/************************************************************/
//REMOVER ELEMENTO INICIO
int remove_lista_inicio(Lista *li)
{
    //Verifica se a lista existe
    if(li == NULL)
    {
        return 0;
    }
    if((*li) == NULL)
        return 0;
    Elem *no = *li;
    *li = no->prox;
    free(no);
    return 1;
}
/************************************************************/
//REMOVe LISTA FINAL
int remove_lista_final(Lista* li)
{
    if(li == NULL)
        return 0;
    if((*li) == NULL)
        return 0;
    Elem *ant , *no = *li;
    while(no->prox != NULL)
    {
        ant = no;
        no = no->prox;
    }
    if(no == (*li))
        *li = no->prox;
    else
        ant->prox = no->prox;
    free(no);
    return 1;
}
/************************************************************/
int main(void)
{
    //'li' =  inicio da lista
    Lista *li; //ponteiro para ponteiro
    li = cria_lista();
    int x;
    
    x = insere_lista_inicio(li , 3);
    
    if(x == 0)
        printf("Erro pra inserir\n");
    else
        printf("Inserção deu certo\n");
    
    printf("\n\nImprimindo Lista:\n");
    imprimir_lista(*li);
    
    return 0;
}
