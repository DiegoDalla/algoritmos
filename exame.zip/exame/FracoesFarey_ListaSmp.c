
// Questão 3 - Frações de Farey
// Alunos: Diego Dalla Bernardina Thedoldi e Guilherme Suttanni
// Série: 1º Ano - Ciências da Computação
// Objetivo: Desenvolver um software que calcule de forma eficiente a sequencia de Farey


/*****AVISO*******/
//Caso não compilar com 'gcc farey.c' usar 'gcc farey.c -lm'.

#include <stdio.h>
#include <stdlib.h>  
#include <math.h>

typedef struct no
{
    struct no *ant; //Campo anterior
    int dados; //Campo dado
    struct no *prox; //Campo proximo
}No;


//Função para criar um nó
No* criar_no()
{
    //Cria um nó no espaço de memoria reservado c/ MALLOC
    No *novo = (No* /*Casting*/)malloc(sizeof(No));
    
    //Retorna o novo nó
    return novo;
}

//Insere um novo nó no final da lista
No* insere_lista_final(No* li , int dado)
{
    No * no = criar_no();
    
    no->dados = dado;
    
    //Como insere no fim o novo nó->prox sempre
    //aponta para NULL
    no->prox = NULL;
    
    //Caso a lista estiver vazia
    if(li == NULL)
    {
        no->ant = NULL;
        
        //Caso a lista estiver vazia o inicio dela aponta
        //para o respectivo nó
        li = no;                                                                                                                   
    }
    //Se ela estiver vazia nós temos que descobrir quem é o utimo elemento
    //Ou seja, quem esta apontando em NULL
    else
    {
        //Criamos um aux para não mudar a lista de luga
        No* aux = li;
        
        //O aux- percorre de um em um até achar o ultimo
        //Ou seja, quando o aux apontar no campo prox pra NULL o laço para
        while(aux->prox != NULL)
        {
            //Incremento
            aux = aux->prox; 
        }
        
        aux->prox = no;
        
        no->ant = aux;
    }
    
    return li;
}


//Função para realizar o calculo do Farey
//Recebe como parametro o nivel da equação
No* farey(No* li , int n) 
{ 
    //O primeiro termo sempre é 0/1 e o segundo 1/n
    double x1 = 0, y1 = 1, x2 = 1, y2 = n; 
  
    li = insere_lista_final(li , x1);
    li = insere_lista_final(li , y1);
    li = insere_lista_final(li , x2);
    li = insere_lista_final(li , y2);
  
    //Auxiliares para os proximos termos
    double x, y = 0;
    
    if(n != 1)
    {
        while (y != 1.0) 
        { 
            // O laço é usado para entrar o proximo parametro
            //floor é usado para 'arredondar' p/ baixo
            x = floor((y1 + n) / y2) * x2 - x1; 
            y = floor((y1 + n) / y2) * y2 - y1; 
  
            //Insere na lista
            li = insere_lista_final (li , x);
            li = insere_lista_final (li , y);
  
            // Atualiza x1, y1, x2 e y2 para a proxima iteração 
            x1 = x2, x2 = x, y1 = y2, y2 = y; 
        } 
    }
    return li;
} 
  
  
//Função para imprimir os elementos da lista  
void imprimir_lista(No *li)
{
    No* aux = li;
    
    //primeiro parenteses
    printf("(");
    
    while(aux != NULL)
    {
        //Numerador
        printf("%d", aux->dados);
        aux=aux->prox;//Incremento
        
        
        //Denominador
        printf("/%d", aux->dados);
        
        //Virgula para separar
        if(aux->prox != NULL)
            printf(" , ");
        
        aux=aux->prox;        
    }
    
    //segundo parenteses
    printf(")\n");
}


//Libera a memória que  a lista anteriormente ocupava
void libera_lista(No* li)
{
    if(li != NULL)
    {
        No* no;
        
        //Libero memoria até que o nó esteja apontando em NULL
        while(li != NULL)
        {
            no = li;
            li = li->prox;
            free(no);
        }
        
        free(li);
    }
}

int main() 
{ 
    //Entradas
    int n; 
    while(1)
    {
        No * li = NULL;
        printf("Digite o valor: ");
        scanf("%d", &n);
        
        if(n == 0)
        {
            break;
        }
        else
        {
            li = farey(li , n);
            imprimir_lista(li);
        }
        
        libera_lista(li);
    }
    
    printf("\n");
    return 0; 
} 
