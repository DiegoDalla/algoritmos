#include <stdio.h>
#include <stdlib.h>

//Nó da lista
typedef struct elemento* Lista; //Ponteiro chamado Lista

struct elemento
{
    struct elemento *ant; //Campo anterior
    struct aluno dados; //Campo dado
    struct elemento *prox; //Campo proximo
};

typedef struct elemento Elem; //Só para facilitar a implementação

/*********************************************************************/

Lista *li; //Ponteiro para ponteiro

/*********************************************************************/

//CRIA A LISTA
//A função nos retorna uma lista
Lista* criar_lista()
{
    //Reserva um espaço na memoria para nosso tipo de lista
    Lista* li = (Lista* /*Casting*/) malloc(sizeof(Lista));
    
    //Caso a lista não estiver a principio vazia, a gente esvazia ela
    if(li != NULL)
    {
        *li = NULL;
    }
    
    return li; // 'li' vai ser o inicio da lista
               // Conteudo de li é o 1° nó da lista  
;}

/*********************************************************************/

//DEVOLVE A MEMORIA AO S.O.
//Recebe nossa lista como parametro
void libera_lista(Lista* li)
{
    if(li != NULL)
    {
        Elem* no;
        
        //Libero memoria até que o nó esteja apontando em NULL
        while((*li) != NULL)
        {
            no = *li;
            *li = (*li)->prox;
            free(no);
        }
        
        free(li);
    }
}

/*********************************************************************/

//TAMANHO DA LISTA
int tamanho_lista (Lista* li)
{
    if(li == NULL) //Caso ela estiver vazia retorna 0
        return 0;
    
    int cont = 0; //Contador
    Elem* no = *li;
    while(no != NULL)
    {
        cont++;
        no = no->prox;
    }
    
    return cont;
}

/*********************************************************************/

//SABER QUANDO A LISTA ESTA CHEIA
//A lista só fica cheia quando acaba a memoria do sistema
int lista_cheia(Lista* li)
{
    return 0;
}

/*********************************************************************/

//SABER QUANDO A LISTA ESTA VAZIA
int lista_vazia(Lista* li)
{
    if(li == NULL)
        return 1;
    
    if(*li == NULL)
        return 1;
    
    return 0;
}

/*********************************************************************/

//INSERCÇÃO NO INICIO DA LISTA
//Se retornar 0 algo falhou, se retornar 1 tudo certo!
int insere_lista_inicio (Lista* li , struct aluno a1)
{
    //Verifica se a lista existe
    if(li == NULL)
        return 0;
    
    //Aloca espaço para um novo nó
    Elem* no = (Elem* /*Casting*/) malloc(sizeof(Elem));
    
    //Se deu erro na alocação de memoria retorna 0
    if(no == NULL)
        return 0;
    
    //Copio os dados para o nó
    no->dados = a1;
    
    //Passo o 'prox' para o nó seguinte
    no->prox = (*li);
    
    //O anterior passa a ser nulo
    no->ant = NULL;
    
    
    //Verifica se a lista é vazia
    if(*li != NULL)
        (*li)->ant = no;
    
    //Coloco o novo nó para ser o 1° elemento da lista
    *li = no;
    
    return 1;
}


/*********************************************************************/

//INSERCÇÃO NO FINAL DA LISTA
//Se retornar 0 algo falhou, se retornar 1 tudo certo!
int insere_lista_final (Lista* li , struct aluno a1)
{
    //Verifica se a lista existe
    if(li == NULL)
        return 0;
    
    //Aloca memoria p/ o nó
    Elem *no = (Elem* /*Casting*/) malloc(sizeof(Elem));
    
    //Verifica se a alocação funcionou
    if(no == NULL)
        return 0;
    
    //Copio os dados para o nó
    no->dados = a1;
    
    //Como estamos inserindo no final
    //Nao tem ninguem depois dele, ou seja, NULL
    no->prox = NULL;
    
    //Se a lista estiver vazia: insere no inicio
    if((*li) == NULL)
    {
        //Como esta no inicio o anterior é NULL
        no->ant = NULL;
        *li = no;
    }
    
    //Caso a lista não estiver vazia
    else
    {
        //Cria o aux que recebe o inicio da lista
        //Nao podemos manipular a lista, pois, nao pode mudar de lugar
        Elem *aux = *li; 
        
        //Enquanto ele for diferente de nulo, o ponteiro anda na lista
        //Até achar o elemento em que o campo prox é NULL
        while(aux->prox != NULL)
            aux = aux->prox; //incremento
         
        //O aux vai apontar para o novo elemento 
        aux->prox = no;
        
        //O nó aponta para o ultimo elemento
        no->ant = aux;
    }
    
    return 1;
}

/*********************************************************************/

//INSERIR O ELEMENTO DE FORMA ORDENADA
////Se retornar 0 algo falhou, se retornar 1 tudo certo!
int insere_lista_ordenada(Lista* li, struct aluno a1)
{
    //Verifica se a lista existe
    if(li == NULL)
        return 0;
    
    //Aloca memoria p/ o nó
    Elem *no = (Elem* /*Casting*/) malloc(sizeof(Elem));
    
    //Verifica se a alocação funcionou
    if(no == NULL)
        return 0;
    
    //Copio os dados para o nó
    no->dados = a1;
    
    //CASO SIMPLES
    //Se a lista for vazia
    if(lista_vazia(li))
    {
        no->prox = NULL;
        no->ant = NULL;
        
        *li = no;
        
        return 1;
    }
    
    //CASO A LISTA NAO FOR VAZIA
    //Procurar onde inserir
    else
    {
        Elem *ante;
        Elem *atual = *li; //Começa no inicio da lista
        
        //Percorre até o final da lista
        while(atual != NULL && atual->dados.matricula < a1.matricula)
        {
            ante = atual;
            
            atual = atual->prox; //Incremento
        }
        
        //Se atual for igual ao inicio quer dizer que ñ percorreu
        //Ou seja,
        if(atual == *li)
        {
            no->ant = NULL;
            (*li)->ant = no;
            no->prox = (*li);
            *li = no;
        }
        
        else
        {
            no->prox = ante->prox;
            no->ant = ante;
            ante->prox = no;
            
            //Se o atual for igual a nulo eu estou no fim da Lista
            if(atual != NULL)
                atual->ant = no;
        }
        
        return 1;
    }
}

/*********************************************************************/

Lista* remover(Lista *lista , Lista *elemento)
{
    Lista *tmp_inicio;
    
    if(elemento == lista)
    {
        tmp_inicio = lista;
        tmp_inicio = elemento->prox;
        tmp_inicio->ant = NULL
    }
    else
    {
        tmp_inicio = elemento->anterior;
        tmp_inicio->prox = elemento->prox;
        tmp_inicio = lista;
    }
    
    free(elemento);
    
    return tmp_inicio;
}

/*********************************************************************/

//PROGRAMA PRINCIPAL
int main(void)
{
    //li = "Lista inicial"
    Lista *li; //Ponteiro para ponteiro

    
    
    return 0;
}
