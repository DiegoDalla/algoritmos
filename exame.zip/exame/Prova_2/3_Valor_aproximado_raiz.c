#include <stdio.h>
#include <math.h>
#define EPS  0.001

int main(int argc, char **argv)
{
	//Calcula o valor aproximado da raiz quadrada de um valor A
	// com erro menor que 0.001
	double x0, x1 = 1;	//x1 é o x atual e x0 é o x anterior
	double A; 			// valor do radicando
	
	do
	{
		scanf("%lf", &A); 
		if (A >= 0)
		{
			do
			{
				x0 = x1; 			// atualiza o valor do x anterior para o x atual
				x1 = (x0 + A/x0) / 2; //calcula o novo x
			} while (fabs(x1 - x0) >= EPS);
			
			printf("RaizQ de %.3lf = %.3lf\n", A, x1);
		}
	} while (A >= 0);
	
	return 0;
}
