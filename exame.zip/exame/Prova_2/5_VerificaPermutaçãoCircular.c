#include <stdio.h>
#include <string.h>

int main()
{
	char S1[201], S2[201], aux[201], c;
	int l1, l2, test = 1, i, cont;

	while (fgets(S1, 200, stdin))
	{
		fgets(S2, 200, stdin);
		l1 = strlen(S1);
		l2 = strlen(S2);
		S1[l1 - 1] = '\0';
		S2[l2 - 1] = '\0';
		
		l1 = strlen(S1);
		l2 = strlen(S2);
		strcpy(aux, S1);
	
		if (l1 != l2)	// comprimentos são diferentes
		{
			printf("Teste %d\nNÃO\n", test++);  // não é permutação circular
		}
		else
		{
			cont = 0;
			while (strcmp(aux, S2) != 0 && cont < l1-1)
			{
				c = aux[0];
				for (i = 0; i < l1; i++)
				{
					aux[i] = aux[i + 1];
				}
				aux[i-1] = c;
				cont++;
			}
			if (!strcmp(aux, S2))
				printf("Teste %d\nSIM\n", test++);
			else 
				printf("Teste %d\nNÃO\n", test++);
		}
	}
	return 0;
}
