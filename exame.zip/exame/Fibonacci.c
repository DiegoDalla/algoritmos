#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a, b;
    int aux , n;
    int i;
    int cont = 0;
    
    while(1)
    {
        a = 0;
        b = 1;
        
        scanf("%d", &n);
        
        if(n == 0)
            return 0;
        else
        {
            printf("(");
            
            printf("1 , ");
            
            for(i=1 ; i < n ; i++)
            {
                //Monta a sequencia de Fibonacci
                aux = a+b;
                a = b;
                b = aux;
                
                if(cont<n)
                    printf("%d", aux);
                
                if(i < n-1)
                    printf(" , ");
            }
            
            printf(")\n\n");
        }
    }
    
    return 0;
}
