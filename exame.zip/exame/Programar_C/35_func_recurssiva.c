#include <stdio.h>

int main ()
{
    int fatorial (int n);
    
    int numero;
    
    printf("Digite um num inteiro:");
    scanf("%d", &numero);
    
    printf("O fatorial é: %d\n", fatorial(numero));
    return 0;
}

int fatorial (int n)
{
    int resultado;
    
    if(n == 0)
        resultado = 1;
    
    else
        resultado = n * fatorial (n - 1);
                //  3 * (chama fatorial novamente)
                //  2 * (chama fatorial novamente)
                //  1 * (chama fatorial novamente)
                //  0 * (chama fatorial novamente)
                // Viu que é igual a 0 entao retorna 1
    return resultado;
}
