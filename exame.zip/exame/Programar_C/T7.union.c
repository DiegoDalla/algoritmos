
#include <stdio.h>
#include <stdlib.h>

//Declarando uma união
union tipo //uniao com nome tipo
{
    short int x; //Inteiro 16 bits
    unsigned char c; //Caracter sem sinal
};

int main(void)
{
    //Declaração da variavel dentro da func. main
    union tipo exemplo;
    
    //Para acessar as variaveis da nossa union é igual a 'struct'
    exemplo.x = 10;
    exemplo.c = 'g';
    
    return 0;
}

/*
 * A diferença entre 'struct' e 'union' é que a union é uma estrutura de memória compartilhada, ou seja, ela pega o valor que ocupa uma memória maior e DIVIDE ele em dois para que as outras variaveis possam ser armmazenadas tambem. Portando eu não posso trabalhar com dois valores simultaneamente.
 * 
 * 
 * Quando usar 'union':::::: Quando tiver muitas variaveis no meu prrograma, mas elas NÃO PODEM SER USADAS AO MESMO TEMPO; bom para economizar memória
 */
