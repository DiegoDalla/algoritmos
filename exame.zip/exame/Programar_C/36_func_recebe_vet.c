//Ordenando o vetor com função

#include <stdio.h>

int main(void)
{
    void ordemCrescente(int vetor[], int n);
    int vetor[10];
    int i;
    
    //lê o vetor
    for(i=0 ; i<10 ; i++)
        scanf("%d", &vetor[i]);
    
    ordemCrescente(vetor, 10); //peciso passar somente o nome do vetor e o numero inteiro é o numero de membros do vetor, ou seja, 10
    
    //Printa o vetor
    printf("[");
    for(i=0 ; i<10 ; i++)
    {
        if(i < 9)
            printf(" %d |", vetor[i]);
        else
            printf("%d ]\n", vetor[i]);
    }
    
    return 0;
}

//eu posso deixar o tamnho do vetor vazio, não faz diferença
//n é o numero de membros
void ordemCrescente(int vetor[], int n) 
{
    //A logica é a seguinte:
    //o 1º é maior que o 2º??, caso sim, inverta
    //o 2º é maior que o 3º??, caso sim, inverta
    //o 3º é maior que o 4º??, caso sim, inverta
    //assim por diante
    //o algoritimo repete o processo até que todos sejam falsos
    
    int i, j, aux;

    for (i = 0 ; i < n ; i++)
        for(j = i + 1 ; j < n ; j++)
            if(vetor [i] > vetor [j])
            {
                aux = vetor[i];
                vetor[i] = vetor[j];
                vetor[j] = aux;
            }
    
    
}
