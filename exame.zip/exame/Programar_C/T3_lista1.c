#include <stdio.h>
#include <stdlib.h>

struct lista
{
    int valor;
    struct lista *proximo;
};

int main(void)
{
    
}

struct lista *procurar_valor (struct lista *pLista , int value)
{
    while(pLista != (struct lista *)0)
    {
        if(pLista->valor == value)
        {
            return 1;
        }
        else
        {
            pLista = pLista->proximo;
        }
    }
}
