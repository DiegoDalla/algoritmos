//Este é o método lógico, ha maneiras mais faceis de fazer com a biblioteca string.h

#include <stdio.h>

//declaração da função em hambito global
_Bool stringsIguais (char string1[] , char string2[]);

int main(void)
{
    //leitura das strings
    int n;
    printf("Qual o tamanho da string?  ");
    scanf("%d", &n);
    
    char s1[n+1] , s2[n+1];
    printf("Digite as strings:\n");
    scanf("%s %s",s1 , s2);
    
    //Hora que eu chamo a função (ja que ela é boolena) se ela retornar "true" ela executa o bloco de comando do if .... mas se ela retornar "false" executa o bloco de comando do else
    if(stringsIguais(s1 , s2))
    {
        printf("As strings são IGUAIS\n");
    } 
    else
    {
        printf("As strings são DIFERENTES\n");    
    }
    
    return 0;
}

//variavel booleana é capaz de armazenar somente dois valores (false {0} ou true {1}), ela só retorna esses dois valores

/*
     * LOGICA:
     * 
     * ||||||||| 0   1   2   3   4   5   6   7
     * STRING1|| C   A   S   A   \0
     * STRING2|| C   A   S   A   \0
     * 
     * Ele verifica da seguinte forma:
     * --> O caracter 0 da string1 é igual o da string2??
     *      caso sim pula pro próximo e assim sucessivamente até chegar no "\0" se todos forem positivos ele retorna "true"
     *      caso ocorrer algum erro no meio do caminho ele retorna um "false"
*/


_Bool stringsIguais (char string1[] , char string2[])
{
    int i = 0; //indice para o while
    
    while(string1[i] == string2[i] && string1[i] != '\0' && string2[i] != '\0')
    {
        i++;
    }
    
    if(string1[i] == '\0' && string2[i] == '\0')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
