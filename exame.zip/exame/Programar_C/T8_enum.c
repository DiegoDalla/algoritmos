#include <stdio.h>
#include <stdlib.h>

//definindo uma enumeração
//Aqui não são strings, são criados VALORES, o 1° - Domingo tem valor 0 ; o 2° - Segunda tem valor 1 etc ....
enum semana                                                                    {Domingo,Segunda,Terca,Quarta,Quinta,Sexta,Sabado};

//Neste caso eu defino onde a numeração vai começar
enum semana2
{Domingo=1,Segunda,Terca,Quarta=7,Quinta,Sexta,Sabado};
/*
 * Neste caso
 * Domingo = 1
 * Segunda = 2
 * Terça = 3
 * 
 * Quarta = 7
 * Quinta = 8
 * Sexta = 9
 * Sabado = 10
 * 
 */


int main ()
{
    enum semana  s = Domingo;
    
    //Como as 'variaveis' declaradas no enum são como valores, quando printados são printados conforme o valor que receberam
    
    printf("%d\n",s);
    
    s++;
    
    printf("%d\n",s);
    
    printf("\n*******************************************\n\n");
    
    return 0;
}
