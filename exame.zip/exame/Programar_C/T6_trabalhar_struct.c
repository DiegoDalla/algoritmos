#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct pessoa
{
    char nome[20];
    char rua[20];
    int idade;
};

int main(void)
{
    struct pessoa info;
    
    strcpy(info.nome , "Guilherme S.");
    strcpy(info.rua , "das Mangueiras");
    info.idade = 18;
    
    printf("Nome - %s\nRua %s\nIdade - %d\n", info.nome,info.rua,info.idade);
    
    return 0;
}
