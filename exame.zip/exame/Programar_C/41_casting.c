#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int x = 16;
    int y = 3;
    
    float reultado;
    
    //se eu dividir uma variavel inteira por uma inteira a resposta é uma saida em numero inteiro
    //ai que entra o cast, tenho que colocar outro tipo de varivael, a da que eu queira como saida
    resultado = (float)x / (float)y;
    
    printf("%f", resultado);
    
    return 0;
}
