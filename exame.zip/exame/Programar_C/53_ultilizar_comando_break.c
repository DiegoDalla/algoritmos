//programa roda até que encontre um valor menor que cem e maior que o numero digitado que seja divisivel o mesmo tempo por 3 e 9
#include <stdio.h>

int main(void)
{
    int i, j; //indice para o laço
    
    scanf("%d", &j);
    
    for(i = j ; i <= 100 ; i++)
    {
        if(i % 3 == 0 && i % 9 == 0)
        {
            printf("%d é divisivel por 3 e 9\n", i);
            break; //ele para o laço assim que o 'if' for executado
        }
        else
        {
            printf("%d não é divisivel\n", i);
        }
    }
    
    return 0;
}
