#include <stdio.h>

int main()
{
    int num1, num2;
    int resposta;
    
    scanf("%d %d", &num1, &num2);
    
    num1 < num2 ? printf("sim\n") : printf("nao\n");
    
    return 0;
}

/*
 
    condição ? se_é_verdade : se_não;
    
*/
