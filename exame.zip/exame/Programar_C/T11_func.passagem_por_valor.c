#include <stdio.h>
#include <stdlib.h>

void soma_um (int x);

int main(void)
{
    int x;
    
    printf("Digite um valor: ");
    scanf("%d", &x);
    
    system("clear");
    
    printf("Antes da função: %d\n\n", x);
    
    soma_um(x);
    
    printf("Depois da função: %d\n", x);
    
    return 0;
}

void soma_um (int x)
{
    x++;
    
    printf("************************************\n\nDentro da função: %d\n\n**************************************\n\n", x);
}
