//Se eu usar um vetor, tudo que eu posso armazenar dentro dele são valores do mesmo tipo do que foi declarado no inicio do escopo
//Com a struct eu consigo armazenar varios tipos de variavel, ela é aberta a todos os tipos de entrada

#include <stdio.h>

int main()
{
    
    //definindo estrutura:
    struct horario
    {
        //eu poderia colocar um double mais um float, totalmente customizavel
        
        int hora;
        int minuto;
        int segundo;
    };
    
    
    //Declarei uma estrutura do tipo horario chamada agora
    //O agora é do tipo horario
    struct horario agora;
    
    
    //Alterando o valor das variaveis na estrutura "agora"
    printf("Digite a hora: ");
    scanf("%d %d %d", &agora.hora, &agora.minuto, &agora.segundo);
    
    //printando a estrutura agora com as variaveis
    printf("%d : %d : %d\n", agora.hora, agora.minuto, agora.segundo);
    
    
    return 0;
}
