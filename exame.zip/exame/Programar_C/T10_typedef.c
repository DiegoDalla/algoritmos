#include <stdio.h>
#include <stdio.h>

typedef int inteiro;

int main(void)
{
    //Int e inteiro neste caso são o mesmo tipo
    int x = 10;
    inteiro y = 20;
    int resultado;
    
    resultado = x + y;
    
    printf("Soma = %d\n", resultado);
    
    return 0;
}
