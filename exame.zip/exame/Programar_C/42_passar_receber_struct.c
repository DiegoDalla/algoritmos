#include <stdio.h>

    //definição da estrutura horario com tres variaveis inteiras
    //ela tem que ser global para tanto a função main enxergar ela quanto a função teste
    struct horario
    {
        int hora;
        int minuto;
        int segundo;
    };


    
    
int main(void)
{
    //declarando uma função com nome "teste", a func recebe como argumento uma estrutura (o que esta entre parenteses; e retorna uma strutura do tipo horario, oque esta no começo
    struct horario teste (struct horario x);
    
    //declaração a estrutura agora do tipo horario
    struct horario agora;
    agora.hora = 10;
    agora.minuto = 42;
    agora.segundo = 58;
    
    
    //declaração a estrutura proxima do tipo horario
    struct horario proxima;
    proxima = teste(agora);
    
    //proxima recebe a estrutura agora mas executada com a função teste
    printf("%d : %d : %d\n", proxima.hora , proxima.minuto , proxima.segundo);
    
    
    //os valores da estrutura agora não mudaram
    printf("%d : %d : %d\n", agora.hora , agora.minuto , agora.segundo);
    return 0;
}



//"x" é o nome da minha struct
struct horario teste (struct horario x)
{
    printf("%d : %d : %d\n", x.hora , x.minuto , x.segundo);
    
    x.hora = 100;
    x.minuto = 100;
    x.segundo = 100;
    return x;
}
