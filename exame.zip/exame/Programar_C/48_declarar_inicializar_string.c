#include <stdio.h>

int main(void)
{
    /*
     * TIPOS DE DECLARAÇÃO
     * 
     * char palavra[6] = {'B','r','a','s','i','l'};
     * char palavra[] = {'B','r','a','s','i','l'};
     * char palavra[7] = {"Brasil"};
     * char palavra[] = {"Brasil"};
     * char palavra[] = "Brasil";
     *
     * As primeira declaração esta errada, porque eu não posso          esquecer do \0 no final das strings; que tambem ocupa   casa, é o caracter nulo
     * No computador ele nao enxerga somente "Brasil" e sim "Brasil\0" para informar que a string acabou
     */
    
    
    
    /* 
     * COMANDO PARA PRINTAR A STRING MAIS FACILMENTE
     * 
     * printf("%s", palavra);
     * 
     * 
     */
    
    
    return 0;
}
