#include <stdio.h>

struct horario
{
    int *ptrHora;
    int *ptrMin;
    int *ptrSeg;
};

int main(void)
{
    struct horario hoje; //estrutura hoje do tipo horario
    
    int hora  = 200;
    int minuto = 300;
    int segundo = 400;
    
    //Como fazer o "ptrHora" apontar no endereço de memória do int "hora"
    hoje.ptrHora = &hora;
    hoje.ptrMin = &minuto;
    hoje.ptrSeg = &segundo;
    
    printf("Antes: %i : %i ; %i\n", *hoje.ptrHora , *hoje.ptrMin , *hoje.ptrSeg);
    
    //Quando eu coloco o asteristico eu estou trabalhando o VALOR do ponteiro
    *hoje.ptrHora = 1;
    *hoje.ptrMin = 2;
    *hoje.ptrSeg = 3;
    
    printf("Depois: %i : %i ; %i\n", *hoje.ptrHora , *hoje.ptrMin , *hoje.ptrSeg);
    
    return 0;
}
