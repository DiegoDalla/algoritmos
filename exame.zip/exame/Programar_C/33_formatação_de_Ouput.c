#include <stdio.h>

int main(void)
{
    int intVar = 999999;
    int intVar2 = 10;
    double doubleVar = 100.1234567;
    
    //FORMATAÇÃO VARIAVEL INTEIRA
    //1º: Se eu quiser escrever ex: %i na tela eu preciso colocar %%i assim o programa entende que eu nao quero chamar nenhuma varivel
    //Se eu quiser que a minha saida do printf fique ex: 7 espaços para a direita eu posso colocar da seguinte forma
    //printf("Variavel inteira (%%d) = %7d\n", intVar); 7 antes do tipo da var
    printf("Variavel inteira (%%d) = %d\n", intVar); //d = "digito"
    printf("Variavel inteira (%%i) = %i\n", intVar); //i = "inteiro"
    printf("Variavel inteira (%%x) = %x\n", intVar); //x = "hexadecimais"
    printf("Variavel inteira (%%o) = %o\n", intVar); //o = "octais"
    printf("\n\n");
    
    
    //FORMATAÇÃO VARIAVEL float // double
    printf("Variavel double (%%f) = %f\n", doubleVar); 
    printf("Variavel double (%%e) = %e\n", doubleVar); //notação cientifica
    printf("Variavel double (%%g) = %g\n", doubleVar); //numero com - casas
    printf("Variavel double (%%a) = %a\n", doubleVar); //outra notação
    printf("\n\n");
 
    
    return 0;
}
