#include <stdio.h>

int main (void)
{
    int x = 10;
    double y = 20.50;
    char z = 'a';
    
    int *ptrX = &x; //declarando ponteiro do tipo inteiro
    //Endereço do ponteiro aponta para o endereço de memória de 'x' 
    //se caso eu usasse *ptrX ao inves de ptrX eu estaria dizendo que o valor do ponteiro é igual ao endereço de memoria de X
    printf("\nEndereço de X: %d  <-->  Valor de X: %d\n\n", ptrX, *ptrX);
    
    /**********************************************************/
    
    double *ptrY = &y;
    printf("\nEndereço de Y: %d  <-->  Valor de Y: %lf\n\n", ptrY, *ptrY);
    
    
    /***********************************************************/
    
    char *ptrZ = &z;
    printf("\nEndereço de Z: %d  <-->  Valor de Z: %c\n\n", ptrZ, *ptrZ);
    //Sempre que o ponteiro estiver com '*' quer dizer que é o valor do ponteiro e não o endereço
    
    return 0;
}
