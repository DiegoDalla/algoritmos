#include <stdio.h>
       
//Neste caso o programa não vai ser limitado ao número de palavras
//GETCHAR é uma função padrao da linguagem C que nos permite pegar um caracter da linha de comanddo que o usuario digitar
int main (void)
{  
    char linha[100]; //onde vai ser armazenado a frase
    char caractere; //como se fosse um aux
    int i = 0;
    
    do{
      
        caractere = getchar();
        linha[i] = caractere;
        
        i++; //faz o ciclo rodar
        
    }while(caractere != '\n'); 
    //O limitador é o '\n' porque quando o usuario aperta ENTER no final da frase nada mais é do que um '\n'
    
    
    linha[i - 1] = '\0'; 
    //é [i - 1] porque mesmo após quando o ciclo "do while" for interrompdo ainda vai acrescentar \n ao final, ou seja quando se coloca [i-1] troca-se o \n por \0 que indica o final da frase
    
    
    printf("%s\n", linha);
    //printa a frase que o usúario digitou no terminal
    
    return 0;
}
