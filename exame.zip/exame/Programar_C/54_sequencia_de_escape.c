/*
 * Estes são os comandos
 * 
 * "\a" --> alarme sonoro do sistema "bip"
 * "\b" --> Move o cursor uma posição para a esquerda
 * "\n" --> Pula uma linha
 * "\t" --> Como se fosse a tecla TAB
 * "\r" --> Volta para o inicio da linha
 * "\0" --> Caracter nulo, normalmente indica o fim de uma string
 *  \' e \" --> é usado para printar as aspas no konsole do usuario
 * 
 */


#include <stdio.h>

int main (void)
{
    
    return 0;
}
