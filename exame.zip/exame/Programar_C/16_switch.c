#include

int main()
{
    int i;
    
    printf("Insira um numero de 1 a 5\n");
    scanf("%d", &i);
    
    switch (i)
    {
        case 1:
            printf("Primeiro\n");
            break;
        
        case 2:
            printf("Segundo\n");
            break;
            
        case 3:
            printf("Terceiro\n");
            break;
            
        case 4:
            printf("Quarto\n");
            break;
            
        default:
            printf("Opção não valida\n");
            break;
    }
    
    return 0;
}

        /*EXEMPLO:
    switch (variavel_a_ser_analisada)
    {
        case valor_do_caso1:
            bloco_de_comando;
            break;
        
        case valor_do_caso2:
            bloco_de_comando;
            break;
            
        case valor_do_caso3:
            bloco_de_comando;
            break;
            
        etc........
        
        default:
            bloco_de_comando;
            break;
    }*/
