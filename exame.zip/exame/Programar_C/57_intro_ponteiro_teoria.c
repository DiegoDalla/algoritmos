//PURA TEORIA

/*  bit  */ --> Um bit é o menor espaço que podemos lidar em relação a memória do computador --> armazena dois valores : 0 ou 1

            --> Quando esquevemos por exemplo "int x" nosso computador vai na memoria verifica um espaço livre que seja sulficiente, e separa este espaço para a variavel do tipo inteiro (No caso são 4 bit) ou seja 0.5 byte

/* Ponteiros */ --> Ultiliza a favor do programador os endereços de memoria em que estao armazenadas as variaveis
