#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p1;
    //calloc diferentemente de malloc recebe 2 argumentos
    //EXEMPLO
    //calloc(Quantas vezes quero alocar aquilo , Tamanho que eu quero alocar)
    
    //Neste caso com o calloc
    //É armazenado cinco espaços de inteiros
    //Ou seja, 5 vezes 4 bytes = 20 bytes
    p1 = (int *) calloc(5 , sizeof(int));
    //Outra diferença que ela tem para o MALLOC é que ela inicia o espao de memoria com 0, e não deixa o lixo (como o MALLOC)
    
    *p1 = 10; //Escreve 10 no primeiro membro do CALLOC
    *(p1+1) = 20; //Acessa o 2º termo
    *(p1 + 2) = 30;
    
    for(int i = 0 ; i < 5; i++)
    {
        printf("Endereço de p[%i] = %p \n Valor de p[%i] = %i\n***********************************\n",i, (p1+i),i,*(p1+i) );
    }
    
    free(p1); 
    
    
    return 0;
}

//Esse codigo quer dizer:::
//Primeiro criamos um ponteiro que aponta para tipo de dado int
//alocamos memoria sulficiente para armazenar uma variavel inteira, dentro do '*p1'
//Printamos o valor que esta armazenado no endereço de memoria de '*p1'
//Limpando a memoria 
