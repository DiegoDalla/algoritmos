#include <stdio.h>
#include <stdlib.h>

//A função free, pega a memoria que o programa alocou e devolve para o S.O. caso o programa for encerrado
int main(void)
{
    int *p1 = (int *)malloc(sizeof(int));
    
    *p1 = 1000;
    
    printf("\n%d\n\n", *p1);
    
    free(p1); //Aliviando a memoria 
    
    //Poderia ocorrer que nessa nova declaração poderia pegar o espaço que anteriormente foi esvaziado
    int *p2 = (int *)malloc(sizeof(int));
    
    return 0;
}
//Esse codigo quer dizer:::
//Primeiro alocamos memoria sulficiente para armazenar uma variavel inteira, dentro do '*p'
//Nesse espaço de memoria escrevemos o valor 1000
//Printamos o valor do endereço de memoria do ponteiro
