//há um documento em que eu desenhei como funciona as listas
#include <stdio.h>
#include <stdlib.h>

//Com o typedef fica mais facil eu me referir a struct
//É como se ela ganhasse um apelido
typedef struct lista
{
    int elemento;
    struct lista *proximo;
}celula;//'Apelido' da minha struct

//Para poder alterar o valor do lugar que o ponteiro da main esta apontando tem que usar um ponteiro para poonteiro
void insereHOME(celula **topo, int elemento);

int main(void)
{
    //Para otimizar o código, vamos usar um ponteiro para cabeça da lista
    celula *topo = NULL;
    
    return 0;
}

//A gente vai criar/inserir um elemento, usar o topo para llocalizar a celula que a gente vai criar
//E posteriormente apontar p/ um proximo elemento
//HOME é porque estamos inserindo no inicio
void insereHOME(celula **topo, int elemento)
{
    celula *novo;
    novo = malloc(sizeof);
    
    //verifica se o conteudo do top é nulo
    if(*topo == NULL)
    {
        novo->proximo = NULL;
        topo = novo;
    }else{ //Se o topo for diferente de NULL ja existe outro(s) elementos
        novo->prox = *topo;
        *topo = novo
    }
}
