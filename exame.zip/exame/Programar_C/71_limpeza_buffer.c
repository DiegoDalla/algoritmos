#include <stdio.h>
#include <stdlib.h>

void limpar_buffer(void);



//Buffer é o tempo de espera para ultilizar uma regiao de memoria iniciada que até o momento não foi fechada
//Então ou o Buffer enche ou ele recebe um comando que tem que esvaziar
int main(void)
{
    //Executando isso dessa forma ele vai ler só dois caracteres, pois o Buffer tambem guarda o 'enter' que é a mesma coisa que o '\n'
    //Ou seja, ficou a sujeira do 'ENTER'
    char a , b , c;
    
    a = getchar();
    b = getchar();
    c = getchar();
    
    printf("%c\n%c\n%c\n", a,b,c);
    
    
    printf("\n*******************************************\n");
    
    //CORRETO
    //Uso uma função que eu vou criar
    char a1 , b1 , c1;
    
    limpar_buffer();
    a1 = getchar();
    limpar_buffer();
    b1 = getchar();
    limpar_buffer();
    c1 = getchar();
    limpar_buffer();
    
    printf("\n\n%c\n%c\n%c\n", a1,b1,c1);
    
    
    return 0;
}

void limpar_buffer(void)
{
    char c;
    while((c = getchar()) != '\n' && c != EOF);
    //Vai la no BUFFER e "retira o lixo"
}
