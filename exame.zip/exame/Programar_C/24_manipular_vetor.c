#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    float notas[5] = {0};
    float total = 0;
    float media = 0;
    
    printf("Insira 5 notas:\n");
    
    //le o vetor
    for(int i=0 ; i < 5 ; i++)
        scanf("%f", &notas[i]);
    
    //soma as notas
    for(int i=0 ; i < 5 ; i++)
        total += notas[i];
    
    media = total / 5; //5 é a quantidade de notas
    
    printf("A média do aluno é: %.2f\n", media);
    
    return 0;
}
