#include <stdio.h> 
#include <stdLib.h>
//Tipo de arvore
typedef struct arvore 
{
    int info;
    struct arvore *esq,*dir;
};
//Insere em ordem
void insere(struct arvore **inicio, int info)
{
    struct arvore *aux;
    /* Como a funçao é recursiva, em alguem momento receberá um início igual a NULL,
       ou caso a árvore esteja vazia. */
    if (!*inicio)
    {
        if((aux = (struct arvore*) malloc(sizeof(struct arvore))) != NULL)
        {
            aux -> info = info;
            aux -> dir = NULL;
            aux -> esq = NULL;
            *inicio = aux;
        }
        else
            printf("Nao foi possivel alocar memoria");
    }
    else
    {
        /* Se o info atual for MAIOR que o valor a ser inserido, então esse 
           valor será inserido do lado ESQUERDO. */
        if ((*inicio)->info > info)
	    insere(&((*inicio)->esq), info);
	else
	    /* Se o info atual for MENOR que o valor a ser inserido, então esse 
               valor será inserido do lado DIREITO. */
	    if((*inicio)->info < info)
	        insere(&((*inicio)->dir), info);
		/* Caso ele seja igual, isso significa que já pertece a árvore.*/
	    else
		printf("%d ja pertence a arvore \n", info);
    }    
}
//Imprime tudo a esquerda e depois a raiz e depois tudo a direita
void inOrder(struct arvore *inicio)
{
    if (inicio) 
    {
        inOrder(inicio->esq);
        printf("%d ", inicio->info);
        inOrder(inicio->dir);
    }
}

//Verifica se um valor n esta presente na arvore
//Caso sim retorna 'true' caso nao retorna 'false'
bool verifica(struct arvore *inicio, int info)
{
    if (inicio)
    {
        if(inicio ->info == info)
	    return true;
        else
        {
            if(inicio ->info < info)
                return verifica(inicio->dir, info);
            else
                return verifica(inicio->esq, info);
        }
	return false;
    }
}

//Retorna o maior valor da arvore
/* O maior  será ou a raiz ou o que tiver a sua direita. */
int maior(struct arvore *inicio)
{
	if((inicio->dir) && (inicio->dir->info > inicio->info))
        	return maior(inicio->dir);
	else
		return inicio->info;
}

//Retorna o menor valor da arvore
/* O menor sempre será ou a raiz ou o que tiver a esquerda*/
int menor(struct arvore *inicio)
{
    if((inicio->esq) && (inicio->esq->info < inicio->info))
        return menor(inicio->esq);
    else
        return inicio->info;
}

//Retorna a soma de todos os nós
/* Basta somar o valor do no com o lado direito mais o lado esquerdo.*/
int somaNos(struct arvore *inicio)
{
    if (inicio) 
        return inicio->info + somaNos(inicio->esq) + somaNos(inicio->dir);
    else
        return 0;
}

//Retorna a quantidade de nós presente na arvore
/* Quantidades de Nos basta somar o 1 com o lado direito mais o lado esquerdo.*/
int qtdNos(struct arvore *inicio)
{
    if (inicio)
        return 1 + qtdNos(inicio->esq) + qtdNos(inicio->dir);
    else
        return 0;
}

//Retorna a media simples dos nós da arvore
//Divide a soma dos Nos pela quantidade de Nos.
int mediaNos()
{
    return somaNos(oi)/ qtdNos(oi);
}

//Retorna a quantidade de NULLS
/* Se o no for válido retorna 0 + + qtdNulls(inicio->dir) + qtdNulls(inicio->esq), caso contrário  retorna 1.*/
int qtdNulls(struct arvore *inicio)
{
    if(inicio)
        return 0 + qtdNulls(inicio->dir) + qtdNulls(inicio->esq);
    else
        return 1;
}

//Retorna o numero de nós em que são multiplos de 3
/* Se o valor atual for múltiplo  de 3 retorna 1 + lado esquerdo + lado direito, se não 0 + lado esquerdo + lado direito.*/
int nosMult3(struct arvore *inicio)
{
    if (inicio)
    {
        if(inicio -> info% 3 == 0)
            return 1 + nosMult3(inicio->esq) + nosMult3(inicio->dir);
	else
            return 0 + nosMult3(inicio->esq) + nosMult3(inicio->dir);
    }
    else
        return 0;
}

//Retorna o numero e folhas de uma arvore
/* Um elemento é uma folho quando a sua esquerda e sua direita foram NULLs, então basta verificar isso se esq e dir forem NULL soma 1 + qtdFolha(inicio->dir) + qtdFolha(inicio->esq) caso contário 0 + qtdFolha(inicio->dir) + qtdFolha(inicio->esq).*/
int qtdFolha(struct arvore *inicio)
{
    //Usa recursiva
    if (inicio)
    {
        if((!inicio->esq) && (!inicio->dir))
	    return 1 + qtdFolha(inicio->dir) + qtdFolha(inicio->esq);
	else
	    return 0 + qtdFolha(inicio->dir) + qtdFolha(inicio->esq);
    }
    else
        return 0;
}

//Retorna a altura da arvore
int altura(struct arvore *inicio)
{
    if(inicio)
    {
        if(altura(inicio->esq) > altura(inicio->dir))
            return 1 + altura(inicio->esq);
	else
            return 1 + altura(inicio->dir);
    }
    else
       return 0;
}

//Retorna se a base é estritamente binaria
//(uma árvore é estritamente binária caso todos os seus nós possuam 2 filhos ou sejam folhas).
/* Se a árvore for vazia ela é estritamente binária, se a esquerda for NULL e a direita não ou se a direita for NULL e a esquerda não, logo a árvore não é estritamente binária, caso contrátio é.*/
bool arvoreBinaria(struct arvore *inicio)
{
    if (inicio) 
    {
        if(((!inicio ->dir)&&(inicio ->esq)) || (inicio ->dir)&&(!inicio ->esq))
	    return false;
	else
	    return arvoreBinaria(inicio ->esq) && arvoreBinaria(inicio ->dir);
    }
    return true;
}

//Faz uma copia de uma arvore para outra
/* Verifica se a árvore é diferente de NULL se for manda inserir a raiz, em seguida tudo a direita, depois tudo a esquerda.*/
void copy(struct arvore *source, struct arvore **des)
{
    if(source)
    {
        insere(des, source->info);
	copy(source->dir, des);
	copy(source->esq, des);
    }
}

/////////////////////////////////////////////////////////////////

int main()
{
    //Declara a arvore
    struct arvore *oi = NULL;
    
    //Insere elemento
    insere(&oi, 3);
    insere(&oi, 5);
    insere(&oi, 1);
    insere(&oi, 3);
    
    //Imprime em ordem
    inOrder(oi);
    
    //Verifica se um valor n esta presente na arvore
    bool test = verifica(oi,7);
    
    //Verifica o maior valor da arvore
    int maior = maior(oi);

    //Verifica o menor valor da arvore
    int menor = menor(oi);
    
    //Verifica a soma dos nós
    int soma = somaNos(oi);
 
    //Verifica quantos nós ha na arvore
    int qnt = qtdNos(oi);
    
    //Verifica a quantidade de NULLS
    int nulls = qtdNulls(oi);
    
    //Media dos nós da arvore
    int media = mediaNos(oi);
    
    //Verifica quantos multiplos de 3 ha na arvore
    int multiplos3 = nosMult3(oi);
    
    //Verifica quantas folhas ha na arvore
    int folhas = qtdFolha(oi);
    
    //Retorna a altura da arvore
    int alturaArvore = altura(oi);
    
    //Retorna true para se for binaria e false caso contrario
    bool binaria = arvoreBinaria(oi);
    
    //Faz a copia de uma arvore para outra
    //Copia de 'oi' para 'oi2'
    copy(oi , &oi2);
    
    return 0;
}
