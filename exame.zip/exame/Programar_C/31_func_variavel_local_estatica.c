#include <stdio.h>

int main(void)
{
    void teste(void);
    
    teste();
    
    teste(); 
    
    return 0;
}

void teste(void)
{
    int variavelLocalAutomatica = 2; //É recriada toda vez que a func é chamada
    variavelLocalAutomatica *= 2;
    
    static int VariavelLocalEstatica = 2; //Ela nao perde o valor quando a função é rechamada
    VariavelLocalEstatica *= 2;
    
    printf("Local Auto: %i\n", variavelLocalAutomatica); 
    //vai ser 4 nas duas vezes em que for chamada
    //ela é criada uma vez e vai ser aquele até o return 0 chegar
    
    printf("Local Estatica:%i\n", VariavelLocalEstatica);
    //ela mantem o valor que recebeu na ultima chamada e executa o comando da chamada presente
    //ou seja: na primeira chamada: recebe 2 e é multiplicado por 2 == 4
    //na segunda chamada: tinha o valor de 4 e é multiplicado por 2 == 8
}
