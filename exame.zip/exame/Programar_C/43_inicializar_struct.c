#include <stdio.h>

int main(void)
{
    /*
      MANEIRA QUE ESTAVAMOS FAZENDO
      
    //definindo a estrutura.
    struct horario
    {
        int hora;
        int minuto;
        int segundo;
    };
    
    
    //define uma variavel desse tipo de estrutura.
    struct horario agora;
    
    
    //inicializa os membros dela.
    //ou colocando valores fixos ou lendo valores do user.
    agora.horas = 10;
    agora.minuto = 20;
    agora.segundo = 30;
    */
    
    
    
    /*---------------------------------------------------*/
    
    
    
    //A um jeito mais facil de iniciar uma struct
    
    
    /*
    struct horario
    {
        int hora;
        int minuto;
        int segundo;
    }agora, teste, depois; 
    
    //ja declaro aqui a variavel, quantas eu quiser
    */
    
    
    
     /*---------------------------------------------------*/
     
     
     
     //Ou eu posso atribuir valor a essa variavel de forma ainda mais facil
     
     
     
    /*
     * 
     struct horario
    {
        int hora;
        int minuto;
        int segundo;
    }agora = {10 , 20 , 30};
    
    //os valores vao ser respectivos a ordem das variaveis da struct horario
    
    */
    return 0;
}
