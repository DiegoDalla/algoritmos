#include <stdio.h>

//Para acessar o endereço de memória a gente usa o '&' no printf
int main(void)
{
    int x;
    x = 10; 
    
    printf("Valor da variavel: %d\n\n", x); //printa o valor da variavel
    
    
    //Por algum motivo nao esta funcinando
    printf("Endereço de memória em que foi armazenada: %d\n", &x);
    
    
    /****************************************************/
    
    
    int *ponteiro; //ponteiro que aponta para um inteiro mas nao aponta em nenhum lugar até agora
    
    ponteiro = &x; //O ponteiro aponta para o endereço de memória do x
    
    //Quando eu Imprimo o ponteiro no terminal ele vai mostrar oque havia naquele endereço de memória, ou seja, no caso, 10
    printf("\n*Ponteiro: %d\n", *ponteiro);
    
    //Mas caso eu Imprimo a variavel ponteiro sem o asteristico ela imprime o endereço de memória
    printf("\nPonteiro: %d\n", ponteiro);
    
    
    /**************************************************/
    
    printf("\n\n*************************************\n\n");
    
    //Ver como os ponteiros conseguem alterar um valor somente manuseando seu endereço de memória
    
    int a = 10;
    int *ptr;
    ptr = &a; //ponteiro aponta o endereço de memória de x
    
    int b = 20;
    *ptr = b; //O valor do ponteiro vai ser igual a y
    
    printf("\nx = %d || y = %d\n", a, b);
    
    
    //O valor de x foi alterado na "fonte" diretamente no endereço de memória
    
    return 0;
 }
