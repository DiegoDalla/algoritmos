#include <stdio.h>
#include <stdlib.h>

float calcularAreaQuadrado(float x, float y);

int main(void)
{
    float x , y;
    
    scanf("%f %f", &x, &y);
    
    //float calcularAreaQuadrado(float x, float y);
    
    printf("A area do  quadrado é: %.2f\n", calcularAreaQuadrado(x, y));
    
    return 0;
}

float calcularAreaQuadrado(float x, float y)
{
    float area;
    
    area = x * y;
}
