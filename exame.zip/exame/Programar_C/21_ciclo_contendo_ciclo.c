#include <stdio.h>

int main()
{
    for(int i = 1 ; i <= 10 ; i++)
    {
        printf(" --> VOLTA %d <--\n", i);
        for(int j = 1 ; j <= 10 ; j++)
        {
            printf("Ponto %d\n", j);
        }
        
        printf("\n");
    }
}
