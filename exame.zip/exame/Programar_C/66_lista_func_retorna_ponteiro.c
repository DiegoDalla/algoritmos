//Procurar um valor que o usuario digitou dentro de uma lista concatenada

#include <stdio.h>
#include <stdlib.h>

struct lista
{
    int valor;
    struct lista *proximo;
};

struct lista *procurarValor (struct lista *pLista, int valor);

int main (void)
{
        struct lista m1,m2,m3;
        struct lista *resultado;
        struct lista *gancho = &m1; //aponta no primeiro membro da minha lista
        int valor;
    
        
        printf("Atribua valor aos 3 elementos da lista:\n");
        printf("\n1º --> ");
        scanf("%d", m1.valor);
        printf("\n2º --> ");
        scanf("%d", m2.valor);
        printf("\n3º --> ");
        scanf("%d", m3.valor);
        printf("\n");
        
        
        m1.proximo = &m2;
        m2.proximo = &m3;
        m3.proximo = (struct lista *)0;
        
        printf("Digite o valor que quer pesquisar: ");
        scanf("%d", &valor);
        
        //Atribui o resultado da pesquisa para a vari./avel resultado
        resultado = procurarValor(gancho , valor);
        
        if(resultado == (struct lista *)0)
            printf("Valor não encontrado\n");
        else
            printf("O valor encontrado foi %d\n", resultado->valor);
        
        return 0;
}

//Função "procurarValor" retorna um ponteiro (endereço de memoria) de uma struct do tipo lista
//A função recebe um ponteiro (endereço de memória para uma struct lista)
struct lista *procurarValor (struct lista *pLista, int valor)
{
    //responsavel de pegar o primeiro elemento da lista e ir membro por membro
    //enquanto nao apontar pra elemento nulo ele não para de rodar
    while(pLista != (struct lista *)0) 
    {
        //Se o valor que esta no pLista for igual ao valor que o usuario passou como parametro quer dizer que foi encontrado o valor que o usuario estava procurando
        if(pLista->valor == valor)
        {
            return (pLista);
        }
        //Caso o if não for aprovado ele aponta para o proximo elemento da lista
        else
        {
            pLista = pLista->proximo;
        }
    }
    return (struct lista *) 0;
}
