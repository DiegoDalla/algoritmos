#include <stdio.h>

int main()
{
    //ela assume um caractere
    char variavelChar = 'x';
    scanf("%c", &variavelChar);
    printf("%c\n", variavelChar);
    
    
    //ela assume somente uma situação, como ligado ou desligado (true = 1 || false = 0)
    bool variavelBool = false;
    printf("%i\n", variavelBool);
    
    
    //A quantidade de bits que a variavel armazena é maior do que quando declaramos uma variavel do tipo somente'int'
    //Mas ha um problema, se o programa puder trabalhar com valores menores é melhor, pois ocupa menos espaço
    //funciona tambem para os outros tipos de variaveis
    long int variavelInt = 1032302492304;
    scanf("%li\n", variavelInt);
    printf("%li\n", variavelInt);
    
    
    //Funciona como a 'long int' mas para o float
    //Tem uma precisão bem maior no quesito casas decimais
    double variavelDouble =10.10;
    scanf("%lf", &variavelDouble);
    printf("%lf\n", variavelDouble);
}
