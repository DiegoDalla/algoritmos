#include <stdio.h>
#include <stdlib.h>

//Cria a 'struct no' e muda o nome dela p/ 'No'
typedef struct no No;

struct no
{
    int num;
    struct no *prox;
};

/********************************************************/

No* criar_no()
{
    //Cria um nó no espaço de memoria reservado c/ MALLOC
    No *novo = (No* /*Casting*/)malloc(sizeof(No));
    
    //Retorna o novo nó
    return novo;
}

/********************************************************/

No* inserir_no_inicio(No* Lista, int dado)
{
    //Usa a função 'criar_no' para criar um nó
    No *novo_no = criar_no();
    
    //Coloca o dado dentro do nó
    novo_no->num = dado; 
    
    //Caso a lista esteja vazia:::
    //Acrescenta um nó na lista e aponta o msm para NULL por ele ser o primeiro e ultimo elemento
    if(Lista == NULL)
    {
        Lista = novo_no;
        novo_no->prox = NULL;
    }
    
    
    //Caso a lista ja tenha algum elemento
    else
    {
    //Lembrando que a lista não é alocada, ela é só um ptr
    //Aponta o novo ponteiro onde anteriormente a lista apontava
        novo_no->prox = Lista;
        
    //Lista apoonta agora no novo 1º elemento   
        Lista = novo_no;
    }
}

/********************************************************/

void imprimir_Lista(No* Lista)
{
    //Usamos aux pq a lista ñ pode mudar a posiçao
    No *aux = Lista;
    
    while(aux != NULL)
    {
        printf("\n%d\n\n", aux->num);
        aux = aux->prox; //Encremento
    }
}

/********************************************************/
int main(void)
{
    //Criando a lista
    No *Lista = NULL;
    
    //Inserindo um elemento na lista
    Lista = inserir_no_inicio(Lista,10);
    Lista = inserir_no_inicio(Lista,20);
    Lista = inserir_no_inicio(Lista,30);
    Lista = inserir_no_inicio(Lista,40);
    
    imprimir_Lista(Lista);
    
    return 0;
}
