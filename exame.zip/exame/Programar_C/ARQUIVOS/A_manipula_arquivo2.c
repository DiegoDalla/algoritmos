/*
    Para escrever em arquivos podemos usar 4 func:
        fputc --> Imprime apenas um caractere.
        fputs --> Imprime uma string diretamente, sem formatação.
        fprintf --> Imprime uma string formatada.
        fwrite --> Grava dados binarios p/ um arquivo.
        
    Para ler arquivos tambem ha 4 func:
        fgetc --> Recebe apenas um caractere.
        fgets --> Lê uma string (geralmente uma linha inteira).
        fscanf --> Recebe uma string formatada.
        fread --> Lê dados binarios de um arquivo.
        
    Outras funções:
        feof --> Detecta se o final do arquivo foi atingido
        ferror --> Verifica se a ultima operação de leitura ou escrita foi executada com sucesso.
        fseek --> Movimenta o indicador de posição dentro do arquivo para um local especificado.
        rewind --> Volta para o começo do arquivo.
        remove --> Remove um arquivo especificado. 
*/
    
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *arq;
    char string[100];
    int i , j;
    
    arq = fopen("A2.txt" , "w");
    
    if(arq == NULL)
    {
        printf("Houve um erro ao abrir o arquivo.\n");
        return 0;
    }
    else
        printf("Arquivo aberto com sucesso.\n");

    
    printf("Digite uma string, em seguida press[ENTER]: \n");
    setbuf(stdin, NULL);
    fgets(string , 100 , stdin);
    
    printf("Digite um número: ");
    scanf("%d", &i);
    
    printf("Digite mais um numero: ");
    scanf("%d", &j);
    
    //Colocando os dados que eu recebi do user no arquivo
    fputs(string , arq);
    fputc('\n' , arq);
    fputc('\n' , arq);
    fprintf(arq , "%d x %d = %d", i , j , i*j);
    
    if(ferror(arq))
    {
        printf("Erro na gravação do arquivo.\n");
        return 0;
    }
    else
    {
        printf("Dados armazenados corretamente.\n");
    }
    return 0;
}

