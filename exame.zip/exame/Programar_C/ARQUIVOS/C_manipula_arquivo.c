typedef struct cadastro
{
    char nome[30];
    char endereco[50];
    int idade;
}cad;

int main(void)
{
    FILE *arq;
    
    //Repare que é usado 'wb'
    //'w' de 'wrhite' que é criar o arquivo
    //'b' de binari, que é o tipo de arquivo binario, que é armazenado dreto no S.O.
    if((arq = fopen("C.txt","wb")) == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return 0;
    }
    
    printf("Digite seu nome: ");
    setbuf(stdin, NULL);
    fgets(cad.nome, 30 , stdin);
    
    printf("Digite seu endereço: ");
    setbuf(stdin, NULL);
    fgets(cad.endereco , 100 , stdin);
    
    printf("Digite sua idade: ");
    scanf("%d", &cad.idade);
    
    
    //Prototipo de fwrite
    //int fwrite(void *buffer , int bytes , int count , FILE *fp);
    //Buffer:ponteiro para os dados
    //Bytes:tamanho de cada unidade a ser gravada/lida
    //Cout:total de unidades a ser gravadas/lidas
    //fp: ponteiro para o arquivo
    if(fwrite(&cad , sizeof(struct cadastro)
    
    return 0;
}
