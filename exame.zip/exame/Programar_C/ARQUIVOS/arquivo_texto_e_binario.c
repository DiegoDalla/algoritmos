#include <stdio.h>
#include <stdlib.h>

/*
 * A linguagem C trabalha c/ dois tipos de arquivos
 * Arquivo texto
 * Arquivo binario
*/

//Num arquivo de texto cada digito é convertido para seu respectivo caracte ASCII

int main(void)
{
 /*   
->Arquivos texto: podem ser editado no bloco de not
     --Os dados sao gravados exatamente como sao                              impressos na tela
     --Os dados sao gravados como caracter d 8 bits ultilizando a tabela ASCII
     --Para isso existe portanto uma etapa de conversão
 
 ->Arquivos binario: Não pode ser editado no bloco de nota
 */
    
    return 0;
}
