//APRENDER A LLER O ARQUIVO QUE FOI CRIADO 'B.txt'

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *arq;
    char linha[100];
    char *conseguiuLer;
    char c;
    
    if((arq = fopen("B.txt" , "r")) == NULL)
    {
        printf("Houve um erro ao  abrir o arquivo.\n");
        
        return 0;
    }
    
    
    //Aqui ele printa na tela do usuario oque esta no arq
    //Ele lê linha a linha
    //Roda enquanto o arquivo não chegar ao final
    while(!feof(arq))
    {
        //fgets nesse caso lê até 100 char ou até o '\n'
        conseguiuLer = fgets(linha , 100 , arq);
        
        //Se foi possivel realizar a leitura
        if(conseguiuLer)
            printf("%s", linha);
    }
    
    
    
    //Aqui ele printa na tela do usuario oque esta no arq
    //Mas ele lê char a char
    while (!feof(arq))
    {
        c = fgetc(arq);
        printf("%c" , c);
    }
    
    
    
    
    //Faz a leitura formatada do arquivo e printa na tela
    while(!feof(arq))
    {
        fscanf(arq , "%c" , &c);
        printf("%c", c);
        c = ' '; //Para não repetir o ultimo char
    }
    
    return 0;
}
