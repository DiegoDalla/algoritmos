#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *file;
    
    
    //INTRODUÇÃO AO fopen()
    //Dentro de 'fopen()' eu coloco duas strings
    //1º Informando o caminho para se chegar onde deve-se armazenar a string, e por ultimo o nome do arquivo
    //2º é um caracter
    /*
      * "r"->Ler info de um arquivo
      * "w"->Escrever em um arquivo
      * "a"->alterar arquivos
    */
    file = fopen("1.txt" , "w");
    
    
    //INTRODUÇÃO AO fprintf()
    //Escreve dentro do arquivo
    //Recebe também 2 parametros
    //1º -> Qual o ponteiro do arquivo
    //2º -> A mensagem
    fprintf(file , "Guilherme Suttanni Ferreira");
    
    
    //INTRODUÇÃO AO fclose()
    //Funciona como o 'salvar e sair'
    //Recebe como parâmetro o ponteiro que aponta p/ o arquivo
    fclose(file);
    
    
    return 0;
}
