#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int x,y,z;
    FILE *file;
    
    file = fopen("2.txt" , "r");
    
    
    //Caso o ponteiro nao aponte em nada
    //Provavelmente o '2.txt' nao existe caso ocarra esse erro
    if(file == NULL)
    {
        printf("Arquivo não pode ser aberto\n");
        return 0;
    }   
    
    
    //INTRODUÇÃO A fscanf()
    //Ela funciona assim como o 'scanf'
    //Recebe como parametro os seguintes:
    //1º-> nome do arquivo que vai ler
    //2º-> como se fosse um scanf normal
    fscanf(file , "%d %d %d", &x, &y, &z);
    
    
    //Para provar que foi passado os valores de x,y,z corretamente
    printf("%d , %d , %d\n", x, y, z);
    
    
    fclose(file);
    
    return 0;
}
