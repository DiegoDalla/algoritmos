#include <stdio.h>
#include <stdlib.h>

/*
Para manipular um arquivo há basicamente tres etapas:

    1 - Abrir o arquivo
    2 - Ler / Gravar os dados
    3 - Fechar o arquivo
*/

int main(void)
{
    //Declara var do tipo arquivo (ponteiro);
    FILE *arq;
    
    
    
    
    
    
    /*
    fopen()::
    
    Para abrir um arquivo ultilizamos a função 'fopen'.
    Essa func recebe como parametro o nome do arquivo que se deseja manipular (ou o caminho do arquivo, caso nao se encontre no mesmo diretorio em que esta o executavel) e o modo de acesso do arquivo.
    */
    
    arq = fopen("A.txt" , "w"); //Abrindo o arquivo
    
    /*
    Modos de acesso::
    
    r --> Abre o arquivo somente para leitura , o arquivo deve existir ('r' vem do ingles read , ler).
    
    r+ -> Abre o arquivo para leitura e escrita, o arquivo deve existir.
    
    w --> Abre o arquivo somente para escrita no inicio. Apagara o conteudo do arquivo se ele ja existir anteriormente, ou, criara um novo arquivo se não exixstir. ('w' vem de write, escrever);
    
    w+ -> Abre o arquivo para esrita e leitura, apagando o conteudo pré existente
    
    a --> Abre o arquivo para escrita no final. Não apaga o conteudo pré-existente. ('a' vem do ingles append, adicionar).
    
    a+ -> Abre o arquivo para escrita no final e para leitura
    */
    
    
    
    /*
    Caso ocorra algum erro o ponteiro 'arq' retornara NULL.
    Então é possivel criar um controle para informar qual é o erro.
    */
    if(arq == NULL)
    {
        printf("Houve um erro ao abrir o arquivo.\n");
        return 0;
    }
    else
        printf("Arquivo criado com sucesso\n");
    
    
    //Fechando o arquivo
    //Sempre fechar quando acabar o programa.
    fclose(arq);
    
    return 0;
}
