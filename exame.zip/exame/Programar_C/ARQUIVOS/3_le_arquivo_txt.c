#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *file;
    file = fopen("3.txt" , "r");
    
    //Caso 'file' ñ aponta em nada
    //Arquivo nao foi entrontrado
    if(file == NULL)
    {
        printf("Não foi possivel abrir o arquivo.\n");
        getchar();
        return 0;
    }
    
    char frase[100];
    
    //INTRODUÇÃO AO COMANDO fgets()
    //Recebe como parametro
    //1º -> A cadeia de char
    //2º -> O tamanho max. da string
    //3º -> O arquivo
    
    //Quando a função nao retornar mais nada o while para
    //fgets tem que estar dentro de um laço pois ela só lê até a quebra de linha quando esta solta no codigo
    while(fgets(frase , 100 , file) != NULL)
    {
        printf("%s", frase);
    }
    
    fclose(file);
    
    printf("\n");
    return 0;
}
