#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *file;
    
    file = fopen("4.txt" , "a");
    
    if(file == NULL)
    {
        printf("Arquivo não pode ser aberto.\n");
        getchar();
    }
    
    fprintf(file , "1 -- ADICIONADO\n");
    
    
    
    char frase[] = "2 -- ADICIONADO\n";
    
    //Essa função adiciona uma string ao documento
    fputs(frase , file);
    
    
    
    char character = '3';
    
    //Essa função adiciona um char ao documento
    fputc(character , file);
    
    
    fclose(file);
    
    
    return 0;
}
