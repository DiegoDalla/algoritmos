#include <stdio.h>
#include <stdlib.h>

typedef struct Aluno
{
    int ra;
    char nome[30];
}Aluno;

//Cria uma variavel 'aluno' do tipo Aluno global
Aluno aluno;

int main(void)
{
    
    
    return 0;
}
