/*
 * Para realizar buscas em arquivos ultilizamos a função fseek(). Que move o ponteiro da posição corrente de leitura / escrita no arquivo para a posição especificada.
 * 
 * 
 * Seu prototipo é:
 * int fseek(FILE *fp , long NumBytes , int origem);
 * O 2º parametro é pra ver o tamanho do arquivo, que é onde vc indentifica onde quer começar a ler
 * o 3º parametro determina a partir de onde os numBytes serao contados para a movimentação
 * 
 * 
 * Os parametros origem estao na tabela seguinte
 * 
 * Nome                 Valor                Significado
 * SEEK_SET               0                 Inicio do arquivo
 * SEEK_CUR               1              Ponto corrente no arquivo
 * SEEK_END               2                  Fim do arquivo
 */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *arq;
    char linha[100];
    char *conseguiuLer;
    char c;
    
    if((arq = fopen("B2.txt" , "r")) == NULL)
    {
        printf("Houve um erro ao  abrir o arquivo.\n");
        
        return 0;
    }
    
    
    //Coloca o ponteiro antes do ultimo caractere do arquivo
    //O '-2' é para ele ficar em uma posição atras do final, pois ele retorna 2 bytes, ou seja, o cursor passa pelo '\n' e pelo ultimo char
    fseek(arq , sizeof(char) - 3 , 2);
    c = getc(arq);
    printf("Ultimo caractere do arquivo: %c\n", c);
    
    
    //Volta o cursor para o inicio
    rewind(arq);
    c = getc(arq);
    printf("Primeiro caractere do arquivo: %c\n", c);
    
    fclose(arq);
    return 0;
}
