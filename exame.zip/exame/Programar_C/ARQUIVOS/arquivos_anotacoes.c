//Arquivos são uma coleção de bytes que são armazenados em dispositivos secundarios

/*VANTAGENS::::
 * Armazenamento duravel -> mesmo depois de desligado o pc as coisas continuam armazenada
 * Permite armazenar uma grande quantidade de info
 * Acesso concorrente aos dados
 */

//Ao se mudar a extensão de um arquivo não se muda nada em seu interior 'codigo'

//Para trabalhar com arquivos ultilizamos : stdio.h

//A linguagem C ultiliza um tipo especial de ponteiro para se referir a ARQUIVOS
//FILE *nome_ponteiro
