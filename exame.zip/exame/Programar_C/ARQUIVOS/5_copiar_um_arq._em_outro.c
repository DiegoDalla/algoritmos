#include <stdio.h>
#include <stdlib.h>

void copiarConteudo(FILE *f1 , FILE *f2)
{
    char leitor[1000];
    
    //O ciclo roda enquanto:
    //Nao tenha mais nenhuma info para ler
    while(fgets(leitor , 1000 , f1) != NULL)
    {
        fputs(leitor , f2);
    }
}

int main(void)
{
    FILE *f1 = fopen("5-1.txt" , "r");
    
    if(f1 == NULL)
    {
        printf("Erro ao abrir o arquivo '5/1.txt'\n");
    
        return 0;
    }
    
    FILE *f2 = fopen("5-2.txt" , "w");
    
    if(f2 == NULL)
    {
        printf("Erro ao abrir o arquivo '5/2.txt'\n");
    
        return 0;
    }
    
    copiarConteudo(f1 , f2);
    
    //Fechando arquivos
    fclose(f1);
    fclose(f2);
    
    return 0;
}
