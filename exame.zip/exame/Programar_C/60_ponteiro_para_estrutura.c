//O objetivo vai ser alterar os dados de horario da estrutura agora ultilizando o ponteiro depois

#include <stdio.h>

//Define a estrutura
struct horario
{
    int hora;
    int minuto;
    int segundo;
};

int main(void)
{
    //Declarando as estruturas do tipo horario
    struct horario agora; //estrutura 'agora' do tipo 'horario'
    struct horario *depois; //ponteiro que aponta para a estrutura do tipo horario
    
    //O ponteiro aponta para a estrutura do tipo 'agora'
    depois = &agora;
    
    //Isso não funcionaria, a ordem de prescedencia da linguagem C que executa primeiro o ponto depois o '*', é necessario usar parenteses no ponteiro  
    /*    *depois.hora = 20;    */
    
    //Desse modo funciona
    (*depois).hora = 20;
    (*depois).minuto = 20;
    (*depois).segundo = 20;
    
    printf("%i : %i : %i\n", agora.hora , agora.minuto , agora.segundo);
    
    return 0;
}
