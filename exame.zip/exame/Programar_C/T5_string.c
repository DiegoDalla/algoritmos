//PROGRAMA PARA CONTAR O NUMERO DE VOGAIS DE UMA FRASE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    
}
