#include <stdio.h>

int main(void)
{
    //concatenar é a mesma coisa que juntar
    //função com objetivo de juntas as strings palavra 1 e 2
    void concatenarStrings(char string1[] , int tamanho1,
                           char string2[] , int tamanho2,
                           char string3[] , int tamanho3);
    
    char palavra1[] = {'p' , 'a' , 'o', ' '};
    char palavra2[] = {'m' , 'o' , 'r' , 't' , 'a' , 'd' , 'e' , 'l' , 'a'};
    char frase[13];
    
    void concatenarStrings(palavra1, 4,
                           palavra2, 9,
                           frase, 13);
    
    return 0;
    
}


void concatenarStrings(char string1[] , int tamanho1,
                       char string2[] , int tamanho2,
                       char string3[] , int tamanho3)
{
    int i , j; //indices for
         
    for(i=0 ; i < tamanho1 ; i++)
        string3[i] = string1[i];
    
    for(j=0 ; j < tamanho2 ; j++)
        string3[j+tamanho1] = string2[j];
}
