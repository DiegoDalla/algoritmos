#include <stdio.h>

int main(void)
{
    struct horario
    {
        int hora;
        int minuto;
        int segundo;
    };
    
    //vetor do tipo struct horario
    //para matriz é a mesma coisa
    struct horario vet[5];
    
    //só pra ver como funciona
    vet[0].hora = 10;
    vet[0].minuto = 20;
    vet[0].segundo = 30;
    
    printf("%d : %d : %d\n\n", vet[0].hora, vet[0].minuto, vet[0].segundo);
    
    
    printf("\n*---------------*------------------*---------------*\n\n\n");
    
    
    //maneira mais facil de atribuir valor
    struct horario vet2[5] = {{10, 20 , 30} , {100, 200 , 300} , {500 , 600 , 900} , {1,2,3} , {17,18,19}};
    
    //printando o valor com um looping
    for (int i = 0 ; i < 5 ; i ++)
        printf("%d : %d : %d\n\n",  vet2[i].hora, 
                                    vet2[i].minuto,                         
                                    vet2[i].segundo);
        
        
    return 0;
}
