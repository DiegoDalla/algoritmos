#include <stdio.h>

int main()
{
    void imprimaMensagem (void); 
    //declarou a variavel "imprimaMensagem"
    //o void é oque eu quero que minha função retorne
    
    imprimaMensagem();    
    
    return 0;
}

void imprimaMensagem (void)
{
    
    printf("teste\n");
    
}
