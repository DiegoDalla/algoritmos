//site : ASCIItabble.com
//posso usar por exempplo para verificar se um caracter digitado pelo usuario é uma letra minuscula, ou seja se ele pertencer ao intervalo [97 , 122]

#include <stdio.h>

int main(void)
{
    int x; //de acordo com a tabela ASCII, 97 é a letra 'a'
    
    //le o valor da tabela ASCII desejado
    printf("Digite o valor decimal correspondente na tabela ASCII: ");
    scanf("%d", &x);
    
    
    //printa o caractere
    printf("%c\n", x); 
    //lembrando que %c é o comando para caracteres
    
    return 0;
}
