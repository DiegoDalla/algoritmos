#include <stdio.h>
#include <stdlib.h>

struct exemplo
{
    int ex1,
    char ex2;
};

//Eu resumo "struct exemplo" para "ex", como se fosse um apelido
typedef struct exemplo ex;

int main(void)
{
    //As duas formas dão na mesma:::
    struct exemplo primeiro;
    
    ex segundo;
    
    return 0;
}
