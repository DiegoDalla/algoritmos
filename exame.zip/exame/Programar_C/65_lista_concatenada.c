#include <stdio.h>

struct lista
{
    int valor;
    struct lista *proximo; //ponteiro "proximo" que aponta em uma estrutura lista
};

int main(void)
{
    struct lista m1 , m2 , m3;
    struct lista *gancho = &m1;
    
    m1.valor = 10;
    m2.valor = 20;
    m3.valor = 30;
    
    //m1 aponta em m2 ; m2 aponta em m3 e assim por diante se houvesse mais variaveis
    //como acaba no m3, ele nao tem onde apontar
    m1.proximo = &m2;
    m2.proximo = &m3;
    m3.proximo = (struct lista *)0; //proximo aponta em uma struct lista de valor nulo
    
    
    //ACESSAR A LISTA
    while(gancho != (struct lista *)0) //enquanto o gancho nao apontar em uma estrutura nulo o ciclo continua
    {
        //começa em m1
        printf("\n%d\n\n", gancho->valor); //para acessar um ptr dentro de uma struct a gente usa '->'
        
        gancho = gancho -> proximo; //Sempre que rodar o gancho pula para o proximo e quando o gancho for NULO o laço para
    }
    
    return 0;
}

/*::: É melhor desenhar :::
 * 
 * struct lista *gancho ---> &m1
 * 
 * m1 (valor 10) / struct lista *proximo ---> &m2
 * 
 * m2 (valor 20) / struct lista *proximo ---> &m3
 * 
 * m3 (valor 30) / struct lista *proximo ---> (struct lista *)0 (NULO)
 *   
 */
