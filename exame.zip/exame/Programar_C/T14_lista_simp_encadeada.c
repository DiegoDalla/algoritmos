//LISTA SIMPLESMENTE ENCADEADA
//CRIAR // INSERIR INICIO // IMPRIMIR

//Declarando funções
no* criar_no();
no* inserir_no_inicio(no *lista , int dado);
void imprimir_lista(no *lista);



typedef struct no no;

//Criando a estrutura nó
struct no
{
   int num;
   struct no *prox;
};



/*********************************************************/



int main(void)
{
    //Abrindo uma lista inicialmente vazia
    //A lista não aloca um nó, ela simplesmente guarda o endereço de memória do primeiro valor
    no *lista = NULL; 
    
    
    //Passei o numero 10 para guardar na 1° posição da lista
    lista = inserir_no_inicio(lista , 10);
    
    //Imprimindo a lista
    imprimir_lista(lista);
    
    
    return 0;
}



/*********************************************************/




//Função para criar um novo nó
//malloc recebe uma quantidade de byte e retorna um ponteiro do tipo void
no* criar_no()
{
    //Recebe uma quantidade de byte que o nó ocupa na memoria e retorna um ptr p/ esse nó 
    no *novo = malloc((no* /*CASTING*/)sizeof(no));
    
    return novo;
}





//Recebe como parametro a nossa lista e o dado que queremos inserir
//Objetivo é inserir um nó no inicio da lista
no *inserir_no_inicio(no *lista , int dado)
{
    //Criamos um novo nó
    no *novo_no = criar_no();
    
    //Fazemos com que o novo no receba um dado no campo num da nossa 'struct no'
    novo_no->num = dado;
    
    //Esse caso é para se a lista esta inicialmente nula
    if(lista == NULL)
    {
        //lista aponta para nó
        lista = novo_no;
        
        //O campo 'proximo' do no aponta para NULL por ele ser o ultimo
        novo_no->prox=NULL;  
    }
    else //caso não estiver vazia , ou seja , ja tenha sido inserido outro elemento
    {
        novo_no->prox = lista;
        lista=novo_no;
    }
    
    
    return lista;
}




//Como a gente ñ pode mudar a lista de lugar(Ela sempre aponta para o primeiro elemento), nos temos que criar um ponteiro auxiliar para apontar para o mesmo luga que a lista aponta, e dessa forma ir percorrendo
void imprimir_lista(no *lista)
{
    //Criando o nó auxiliar
    //A partir de agora só trabalhamos com o aux
    no *aux = lista;
    
    //enquanto houver elemento na lista a gente continua mostrando os elementos
    while(aux != NULL)
    {
        printf("%d", aux->num);
        aux = aux->prox;
    }
    
}
