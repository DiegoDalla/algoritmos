#include <stdio.h>

void overflow(void);
void nop_overflow(void);


int main(void)
{
    overflow(); //Neste caso como short não suporta o valor designado a ele, vai aparecer alguns valores aleatórios no prompt de comando
    
    printf("\n\n");
    
    nop_overflow(); //Como um int permite armazenar valores maiores aqui neste caso vai funcionar
    
    return 0;
}

void overflow(void)
{
    short x = 2145623212; //short é uma variavel inteira que armazena enor do que uma int
    short y = -2312432123;
    
    printf("%i\n", x);
    printf("%i\n", y);
}

void nop_overflow(void)
{
    int x = 2145623212; //short é uma variavel inteira que armazena enor do que uma int
    int y = -231243;
    
    printf("%i\n", x);
    printf("%i\n", y);
}
