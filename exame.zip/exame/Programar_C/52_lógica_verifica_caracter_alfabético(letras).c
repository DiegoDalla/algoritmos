//O objetivo é mostrar a lógica de se verificar se o caracter digitado pelo usuario é uma letra, um numero, um caracter  especial etc... se é uma letra ou não

#include <stdio.h>

_Bool alfabetico(char var); //declarando a função

int main(void)
{
    char palavra[20]; 
    //o tamanho maximo que a palavra pode ter é de 19 letras
    //a ultima posição da string é o caracter nulo
    int aux = 0;
    
    //lê a palavra desejada pelo usuario
    printf("Digite uma palavra: ");
    scanf("%s", palavra);

    
    int i = 0; //índice para o laço
    //enquanto a palavra nao chega no caracter nulo o while continua rodando
    while(palavra[i] != '\0') 
    {
        //chama a função
        aux = alfabetico(palavra[i]);
        
        i++;
    }
    
    return 0;
}

//void porque a func não retorna nada
_Bool alfabetico(char var)
{
    //Nunca esquecer que na em c# a letra 'a' é diferente de 'A'
    //Nós podemos fazer isso, compara caracteres assim como nós comparamos números
    //Este bloco de comando testa se os caracteres da palavra digitada pelo usuario são letras ou não
    if((var >= 'a' && var <= 'z') || (var >= 'A' && var <= 'Z'))
    {
        printf("É uma letra\n");
    }
    else
    {
        printf("Não é letra\n");
    }
}
