#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    void funcaoPrint (int x, int vetor[]);
    int x  = 10; 
    int vetor[3] = {10};
    
    funcaoPrint (x, vetor);
    
    printf("\n\n");
    
    printf("Variavel int na função principal = %d \n", x);
    printf("Vetor na função principal = %d \n" vetor[1]);
    
    return 0;
}


//é como se eu tivesse uma cópia de x, ou seja, abriu mais uma variavel independente da da função main

void funcaoPrint (int x , int vetor[])
{
    x = x + 10;
    vetor [1] = 20;
    
    printf("Variavel int na função print = %d \n", x);
    printf("Vetor na função print = %d \n" vetor[1]);
}
