#include <stdio.h>
#include <stdlib.h>

int fatorial (int n);

int main(void)
{
    int x;
    
    scanf("%d", &x);
    
    x = fatorial(x);
    
    printf("\n%d\n", x);
    
    return 0;
}

int fatorial (int n)
{
    if(n == 0)
        return 1;
    else
        return n*fatorial (n - 1);
}
