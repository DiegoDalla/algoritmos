#include <stdio.h>

int main(void)
{
    void teste(void);
    
    teste(); //neste caso o valor de retorno sera '4'
    
    teste(); //vai continuar sendo 4, porque:
    //A variavelLocalAutomatica é local na função teste, ou seja, não é visivel para função main   
    //E é automatica porque toda vez que a função teste é chamada, ela é recriada, todo valor que ela tinha anteriormente é ignorado
    
    return 0;
}

void teste(void)
{
    int variavelLocalAutomatica = 2;
    
    variavelLocalAutomatica *= 2;
    
    printf("%i\n", variavelLocalAutomatica);
}
