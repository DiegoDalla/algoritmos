#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct horario
{
    int hora;
    int min;
    int seg;
};

void print(int relogio.hora , int relogio.min , int relogio.seg);

int main(void)
{
   struct horario relogio; //Declarando estrutura do tipo horario relogio
   
   while (getchar())
   {
    
    relogio.seg++; //aumenta um no ponteiro dos segundos
       
    if(relogio.seg == 60)
    {   
        //acrescenta 1 ao ponteiro dos minutos e zera os segundos
        relogio.min++;
        relogio.seg = 0;
    }
    
    if(relogio.min == 60)
    {
        relogio.hora++;
        relogio.min = 0;
    }
    
    if(relogio.hora == 24)
    {
        relogio.hora = 0;
    }
    
    system("clear");
    system("sleep 003");
    
    print(relogio.hora , relogio.min , relogio.seg);
    
   }
    
  return 0;  
}
