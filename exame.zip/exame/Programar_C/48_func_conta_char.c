#include <stdio.h>

int main(void)
{
    int tamanhoString(char string[]);
    
    char stringUsuario[20];
    
    printf("Digite uma palavra (string): ");
    scanf("%s", stringUsuario);
    
    int num;
    num = tamanhoString(stringUsuario);
    
    printf("A string '%s' possui %d letras. \n", stringUsuario, num);
    
    
    return 0;
}

int tamanhoString(char string[])
{
    int numCaracteres = 0;
    
    //A string vai aumentar um até atingir o caracter nulo
    while(string[numCaracteres] != '\0')
    {
        numCaracteres++;
    }
    
    return numCaracteres;
}
