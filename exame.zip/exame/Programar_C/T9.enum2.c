#include <stdio.h>
#include <stdlib.h>

enum especial{retroceder='\b',tab='\t',enter='\n'};

int main(void)
{
    enum especial acao;
    
    acao = tab;
    
    printf("Caso %c de %c teste\n", acao , acao);
    
    printf("\n***************************************************************\n\n");
    
    acao = enter;
    
    printf(" Caso %c de %c teste\n", acao , acao);
    
    return 0;
}
