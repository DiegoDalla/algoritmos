//string é um vetor de caracteres
//uma frase é um conjunto de caracteres
//a biblioteca <string.h> é só para as funções que facilitam strings

#include <stdio.h>
#include <string.h>

int main()
{
    char teste[] = {'b' , 'r' , 'a' , 's' , 'i' , 'l'};
    int i;
    
    for(i = 0 ; i < 6 ; i++)
        printf("%c", teste[i]);
    
    printf("\n");
    
    return 0;
}
