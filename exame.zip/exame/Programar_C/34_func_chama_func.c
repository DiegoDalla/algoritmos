//Criando um programa que some o valor absoluto de 2 numeros ignorando o sinal

#include <stdio.h>

//Função principal
int main()
{
    float somaDeDigitos(float num1, float num2);    
    
    float a, b, soma;
    
    printf("Digite dois numeros:\n");
    scanf("%f %f", &a ,&b);
    
    soma = somaDeDigitos(a , b);
    
    printf("A soma é: %.4f\n", soma);
    return 0;
}

//Testa se o valor é negativo e soma o num1 e num2
float somaDeDigitos(float num1, float num2)
{
    float valorAbsoluto (float x);
    
    if(num1 < 0)
        num1 = valorAbsoluto(num1);
    
    if(num2 < 0)
        num2 = valorAbsoluto(num2);
    
    return num1 + num2;
}


//Recebe o valor negativo e o transforma em positivo multiplicando por (-1)
float valorAbsoluto (float x)
{
    return x * (-1);
}
