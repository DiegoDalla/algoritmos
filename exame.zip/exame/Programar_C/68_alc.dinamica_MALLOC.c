#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //MALLOC = 'memory allocation'
    //Responsavel por pedir para o S.O. um bloco de memoria de um tamanho que a gent expecificar
    //A função retorna pra nos um ponteiro que aponta p/ o endereço desse bloco que foi alocado
    
    //A função retorna um ponteiro do tipo de dado 'void', ou seja, um ponteiro generico, de qualquer tipo
    //Portanto quando tentamos atribuir um ponteiro int para o malloc que é void vai dar ERROR
    //Por isso ultilizamos o 'casting'
    
    int *p  =  (int * /*Isso é casting*/)malloc(4); 
    //O valor entre parenteses é o numero de bytes que é para reservar na memoria
    
    int *p2 = (int *)malloc(sizeof(int)); //Normalmente é usado assim, usando sizeof juntamente com o malloc
    
    //Caso o ptr p retorne o valor de 'NULL' quer dizer que o MALLOC não funcionou
    
    //Agora ja podemos acessar aquele endereço de memoria
    *p2 = 1000;
    
    printf("%d\n", *p2);
    return 0;
}
