#include <stdio.h>
#include <stdlib.h>

#define MAX 10 //Tamanho maximo da nossa pilha
int inicio , fim;
int pilha[];
//////////////////////////////////////////////////////////////
//Inserir elemento
void push (int x)
{
    //Caso a pilha não estiver cheia
    if( !pilhaCheia() )
    {
        //Ele atribui o valor de x no 'fim' anterior
        pilha[fim++] = x;
    }
    else
        printf("---PILHA CHEIA---\n");
}
//////////////////////////////////////////////////////////////
//Retira um elemento
int pop()
{
    int aux;
    //Testa se a pilha esta vazia
    if( !pilhaVazia() )
    {
        //Recupera a posição anterior do topo
        aux = pilha[fim - 1];
        //Tira um elemento
        fim --;
        return aux;
    }
    else
    {
        return -1; //LISTA ESTA VAZIA
    }
}
//////////////////////////////////////////////////////////////
//Testa se o ptr de inicio é igual ao do fim
int pilhaVazia()
{
    //Se eles forem iguais a pilha esta vazia
    return (inicio == fim);
}
//////////////////////////////////////////////////////////////
//Se a pilha esta cheia quer dizer que o fim atingiu o maximo
int pilhaCheia()
{
    return (fim == MAX);
}
////////////////////////////////////////////////////////////
int main(void)
{
    inicio = 0;
    fim = 0;
    //Aqui posso usar um laço ou algo assim para inserir mais dinamicamente
    push(12);
    push(34);
    
    printf("%d\n", pop());
    printf("%d\n", pop());
    if(pop() == -1)
        printf("--LISTA VAZIA--\n");
    return 0;
}
