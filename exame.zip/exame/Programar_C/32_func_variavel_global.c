//Eu nao posso usar as variaveis de outra função na main(); portando esta é a tecnica se voce quiser usar uma variavel global:

//Para isso eu declaro ela fora do escopo das funções

int gVariavelGlobal = 2; //O g na frente da variv é só para melhor localizar em programas grandes

#include <stdio.h>

int main(void)
{
    void teste(void);
    
    printf("Variavel Global = %d\n", gVariavelGlobal);
    
    teste();
    
    teste(); 
    
    return 0;
}

void teste(void)
{
    int variavelLocalAutomatica = 2; 
    variavelLocalAutomatica *= 2;
    
    static int VariavelLocalEstatica = 2; 
    VariavelLocalEstatica *= 2;
    
    printf("\n\n");
    
    printf("Variavel Global = %d\n", gVariavelGlobal);
    gVariavelGlobal *= 2;
    
    printf("Local Auto: %i\n", variavelLocalAutomatica); 
    
    
    printf("Local Estatica:%i\n", VariavelLocalEstatica);
}
