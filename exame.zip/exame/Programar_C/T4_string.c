//Operações com strings ultilizando a biblioteca "string.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    /*
    strlen --> retorna o tamanho da string
    
    strcpy --> Copia uma string
    
    strcat --> Concatenar duas string
    
    strcmp --> Compara duas strings
    */
    
    
    //STRLEN
    char palavra[20] = "Linguagem C";
    int tam = 0;
    
    //"tam" vai receber o numero de caracteres que a string "palavra" tem antes do \0
    tam = strlen(palavra);
    
    printf("Tamanho da string 'Linguagem C': %d\n", tam);
    
    
    printf("\n****************************************************************\n");
    
    
    //STRCPY
    char palavra2[20] = "Linguagem JAVA";
    char novastring[30];
    
    //A string 'palavra2' vai ser copiada para a string 'novastring'
    strcpy(novastring , palavra2);
 
    printf("\nString 1 --> %s\n\nString 2 --> %s\n", palavra2 , novastring);
    
    
    printf("\n****************************************************************\n");
    
    
    //STRCAT
    char str1[20] = "Linguagem ";
    char str2[30] = "Phython";
    
    //O conteudo da str2 vai ser colocada no final de str2
    strcat(str1 , str2);
 
    printf("\nPalavra concatenada--> %s\n", str1);
    
    
    printf("\n****************************************************************\n");
    
    
    //STRCMP    
    char string1[20] = "Linguagem c++";
    char string2[20] = "LINGUAGEM c++"; 
    
    //Verifica se as strings são iguais ; Se retorna um valor igual a 0 quer dizer que são iguais, caso contrario são diferentes
    if(strcmp(string1 , string2) == 0)
    {
        printf("Strigs %s  e  %s são iguais\n", string1 , string2);
    }
    else
    {
        printf("Strigs %s  e  %s são diferentes\n", string1 , string2);
    }
    
    printf("\n****************************************************************\n");
    
    return 0;
}
