//fazer operações matematica usando ponteiro

#include <stdio.h>

//Define a estrutura
struct horario
{
    int hora;
    int minuto;
    int segundo;
};

int main(void)
{
    //Declarando as estruturas do tipo horario
    struct horario agora; //estrutura 'agora' do tipo 'horario'
    
    struct horario *depois; //ponteiro que aponta para a estrutura do tipo horario
    
    //O ponteiro aponta para a estrutura do tipo 'agora'
    depois = &agora;
    
    
    (*depois).hora = 10; //da para usar 'depois->hora = 20'
    (*depois).minuto = 20;
    (*depois).segundo = 30;
    
    int somatorio = 100;
    
    //O valor do ponteiro 'depois' vai atribuir valores aos membros da estrutura do tipo horario
    struct horario antes;
    
    antes.hora = somatorio + depois->segundo;
    antes.minuto = agora.hora + depois->minuto;
    antes.segundo = somatorio - agora.hora + depois->minuto;
    
    
    printf("\nAgora:\n%i : %i : %i\n\n", agora.hora , agora.minuto , agora.segundo);
    
    printf("\nDepois das operações:\n%i : %i : %i\n\n", antes.hora , antes.minuto , antes.segundo);
    return 0;
}
