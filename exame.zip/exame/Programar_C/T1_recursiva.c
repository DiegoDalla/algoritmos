//Calcular fatorial usando função recursiva

int fatorial(int x);

int main(void)
{
    int x;
    int aux;
    printf("Digite o valor que pretende usar:");
    scanf("%d", &x);

    aux = fatorial(x);
    
    printf("%d\n", aux);
    
    return 0;
}

int fatorial(int x)
{
    int resultado;
    
    if(x == 0)
    {
        return 1;
    }
    else
    {
        return x*(fatorial(x -1));
    }
}
