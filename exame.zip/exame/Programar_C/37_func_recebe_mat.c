//printa a matriz em uma função separada da main

#include <stdio.h>

int main (void)
{
    void funcaoPrintMat (int m[][3]);
    
    int matriz[3][3];
    int l, c; //indice para o for
    
    //lê a matriz
    for(l = 0 ; l < 3 ; l++)
        for(c = 0 ; c < 3 ; c++)
            scanf("%d", &matriz[l][c]);
    
    funcaoPrintMat(matriz);    
        
    return 0;
}

//Eu preciso agora no minimo informar o numero de coluna (segunda parte) ou informar o tamnho completo, no caso, [3][3]

void funcaoPrintMat (int m[][3])
{
    int l, c;
    
    for(l = 0 ; l < 3 ; l++)
    {
        for(c = 0 ; c < 3; c++)
        {
            printf("%d\t", m[l][c]);
        }       
        printf("\n");
    }
    
}
