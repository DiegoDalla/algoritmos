//Lista simplesmente encadeada
//Criar , Inserir fim , Imprimir

#include <stdio.h>
#include <stdlib.h>

/*******************************************************/

//Definindo nosso nó

typedef struct no No;
struct no
{
    int dado; //Dado
    struct no *prox; //*ptr
};

/*******************************************************/

No* criar_no()
{
    //Aloca um novo nó dinamicamente
    No *no = (No* /*Casting*/)malloc(sizeof(No));
    
    return no;
}

/*******************************************************/

//Ela recebe a lista na qual queremos inserir e o numero
No* inserir_elemento_fim(No *Lista , int num)
{
    //Cria o novo nó
    No *no = criar_no();
    
    //O campo dado da struct 'No' recebe o parametro 'num'
    no->dado = num;
    
    //Se a lista estiver vazia (1° caso);
    if(Lista == NULL)
    {
        //Como ele é o 1° e ultimo, o nó aponta NULL
        no->prox = NULL;
        
        //Faço com que a lista aponte pro nó criado
        Lista = no;
    }
    
    //Se ela estiver vazia nós temos que descobrir quem é o utimo elemento
    //Ou seja, quem esta apontando em NULL
    else
    {
        //Criamos um aux para não mudar a lista de luga
        No* aux = Lista;
        
        //O aux- percorre de um em um até achar o ultimo
        //Ou seja, quando o aux apontar no campo prox pra NULL o laço para
        while(aux->prox != NULL)
        {
            //Incremento
            aux = aux->prox; 
        }
        
        //Passa o No no campo prox para ultima posição ( -> NULL)
        no->prox = NULL;
        
        //Coloca o No anterior (que era o ultimo antes) aponte para o ultimo atual
        aux->prox = no;
    }
    
    return Lista;
}

/*******************************************************/

void imprimir_Lista(No* Lista)
{
    //Usamos aux p/ ñ correr risco de alterar a posição da Lista quando for percorrer ela
    No* aux = Lista;
    
    while(aux!=NULL)
    {
        //Printa os elementos
        printf("\n%d\n\n", aux->dado);
        
        //Incremento
        aux = aux->prox; 
    }
}

/*******************************************************/

int main(void)
{
    //Cria uma lista inicialmente vazia
    No* Lista = NULL;
    
    //Insere elementos na Lista
    Lista = inserir_elemento_fim(Lista , 10);
    Lista = inserir_elemento_fim(Lista , 20);
    Lista = inserir_elemento_fim(Lista , 30);
    Lista = inserir_elemento_fim(Lista , 40);
    
    imprimir_Lista(Lista);
    
    return 0; 
}
