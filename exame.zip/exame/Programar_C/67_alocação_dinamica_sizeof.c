#include <stdio.h>
#include <stdlib.h>

typedef struct x
{
    int a;
    int b;
    int c;
};

int main(void)
{
    //Operador 'sizeof()' traz pra gente o tamanho, em byte, da variavel
    
    int x;      //4 byte
    double y;   //8 byte
    int vetor[10];
    
    printf("Exemplo a variavel 'double y' tem tamanho::  %li\n", sizeof(y));
    
    printf("Exemplo a variavel 'int x' tem tamanho::  %d\n", sizeof(x));
    
    printf("Exemplo a variavel 'int vetor[10]' tem tamanho::  %d\n", sizeof(vetor));
    
    
    
    struct x exemplo;
    printf("Exemplo a variavel 'struct x exemplo' tem tamanho::  %d\n", sizeof(exemplo));
    
    return 0;
}
