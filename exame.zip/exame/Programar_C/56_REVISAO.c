//O programa vai fazer um "mini-dicionario" usando todos os conceitos vistos até agora

#include <stdio.h>
#include <stdbool.h> //Permite usar variaveis booleanas


//Definindo as funções
int procurar_strings(const struct dicionario lingua[] ,
                     const char procurar[] ,
                     const int num_de_palavras);

bool compararStrings(const char palavra1[] ,
                     const char palavra2[]);




//Definindo uma estrutura GLOBAL
struct dicionario
{
  char palavra[21];
  char definicao[61];
};




//função principal
int main(void)
{
    //Definindo as variaveis
    const int num_de_definicoes = 7; //numero de palavras que meu dicionario vai ter
    
    char palavra[20]; //armazena a palavra do usuario
    
    int resultado_da_pesquisa;
    
    
    //Estrutura chamada portugues do tipo dicionario com 7 definiçoes
    //vetor estrutura do tipo dicionario
    const struct dicionario portugues[num_de_definicoes] = 
    {
        //a primeira parte é a palavra a segunda é a definição
        {"pao" , "Comida feita de farinha"},
        {"mortadela" , "Comida de porco"},
        {"feijao" , "Vegetal"},
        {"tropeiro" , "Tipo de feijao"},
        {"queijo" , "Derivado do leite"},
        {"macarrao" , "Coisa de vó"},
        {"pizza" , "Tipico da Italia"}
    }
    
    printf("Digite uma palavra: ");
    scanf("%s", palavra);
    
    //a variavel "portugues" que passamos para a função procurar_strings é o nome da nossa estrutura
    //Tudo isso que passei para a minha função é oque ela precisava para realizar seu trabalho
    resultado_da_pesquisa = procurar_strings(portugues , palavra , num_de_definicoes);
    
    if(resultado_da_pesquisa != -1)
    {
        printf("%s\n", portugues[resultado_da_pesquisa].definicao);
    }
    else
        printf("Palavra não encontrada\n");
    
    return 0;
}





//função para receber duas palavras, analisar se a palavra1 é igual a palavra2 e vai retornar para o úsuario verdadeiro ou facil
//o CONST quer dizer que a nossa variavel char é constante não consigo alterar o valor dela
bool compararStrings(const char palavra1[] , const char palavra2[])
{
    int i = 0; //indice para o laço
    
    //verifica se as palavras são iguais
    while(palavra1[i] == palavra2[i]
       && palavra1[i] != '\0'
       && palavra2[i] != '\0')
    {
        i++; //roda o laço caracter por caracter
    }
    
    //se caso as duas palavras chegaram ao final quer dizer que as duas são iguais
    if(palavra1[i] == '\0' && palavra2[i] == '\0')
    {
        return true; //necessario a biblioteca "stdbool.h"
    }
    else
    {
        return false;
    }
}






//essa função recebe uma palavra e tambem um local onde vai procurar, essa função é responsavel por pegar o termo de pesquisa e pesquisar até encontrar o significado, caso nao encontrar quer dizer que a palavra nao esta em nosso banco de dado

int procurar_strings(const struct dicionario lingua[] ,
                     const char procurar[] ,
                     const int num_de_palavras) 
{
    int i = 0; //indice para o laço
    
    //num_de_palavras é a quantidade de palavra que o dicionario possui
    while(i < num_de_palavras) 
    {
        //compara usando a função compararStrings se as duas são iguais
        //se as duas forem iguais, o valor de 'i' corresponde a palavra que possui a definição que eu estou procurando
        if(compararStrings(procurar , lingua[i].palavra))
        {
            return i;
        }
        else
        {
            i++;
        }
        
        return -1;
    }
}





