#include <stdio.h>

int main()
{
    
    //defino a estrutura
    struct horario
    {
        int hora;
        int minuto;
        int segundo;
    };
    
    //declaro a 1º
    struct horario agora;
    printf("Digite a hora de agora: ");
    scanf("%d %d %d", &agora.hora, &agora.minuto, &agora.segundo);
    
    //declaro a 2º
    struct horario depois;
    depois.hora = agora.hora + 10;
    depois.minuto = agora.minuto + 10;
    depois.segundo = agora.segundo + 10;
    
    printf("\n*-----------*------------*------------*\n");
    
    //printo as estruturas
    printf("\nHora agora:  %d:%d:%d", agora.hora, agora.minuto, agora.segundo);
    
    printf("\nHora depois: %d:%d:%d\n", depois.hora, depois.minuto, depois.segundo);
    
    
    return 0;
}
