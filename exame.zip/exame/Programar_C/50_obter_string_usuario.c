#include <stdio.h>

int main(void)
{
    char nome[20];
    char sobrenome[20];
    
    printf("Insira seu nome e sobrenome:\n");
    scanf("%s %s", nome , sobrenome); 
    //limitado a capturar duas strings, nao vai ler somente uma nem mais que duas
    
    printf("Seu nome é: %s %s\n", nome, sobrenome);
    
    return 0;
}
