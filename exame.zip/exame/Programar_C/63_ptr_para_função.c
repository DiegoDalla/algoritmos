#include <stdio.h>

//Declarando função
void TesteVariavel(int x);
void TestePonteiro(int *ptr);

int main(void)
{
    int teste = 1;
    int *ptrTeste
    ptrTeste = &teste;

    
    //-------->Neste caso se eu executar o TesteVariavel o valor de teste vai permanecer 1, pois, quando chamo esta função é como se fosse criada uma coópia da variavel que eu criei, o programa tem um espaço de memoria pra a variavel teste de valor 1 que eu acessei com o ponteiro, e outro endeeço para a outra variavel que é a nova
    //-------->Mas se eu executar o TestePonteiro o valor vai acrescentar 1, neste caso não existe cópia, pois oque eu passo para minha função é o endereço de memória da variavel principal "teste" ; ou seja vai direto na fonte e adiciona '1' lá
    TesteVariavel(teste);
    TestePonteiro(ptrTeste);//eu passo sem '*' , pois eu quero passar o endereço de memória
    
    //Isto é util porque ocupa bem menos recursos do meu computador, se eu usar uma função muito pesada e ela tives que fazer uma cópia do valor toda vez que for chamada vai ficar muito pesada, portando eu posso acessar sempre diretamente o endereço de memória
    
    
    printf("%i\n", teste);
    
    return 0;
}



void TesteVariavel(int x)
{
    x++;
}

void TestePonteiro(int *ptr)
{
    *ptr++
}
