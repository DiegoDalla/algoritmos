#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct pessoa
{
    char nome[40];
    int idade;
};

int main(void)
{
    //Com este vetor é possivel armazenar dados para 4 pessoas
    struct pessoa dado[4];
    
    char caractere; 
    int i = 0;
    int j = 0;
    
    strcpy(dado[0].nome , "Guilherme");
    dado[0].idade = 18;
    strcpy(dado[1].nome , "Joao");
    dado[1].idade = 10;
    strcpy(dado[2].nome , "Adriano");
    dado[2].idade = 43;
    strcpy(dado[3].nome , "Vania");
    dado[3].idade = 44;
    //O limitador é o '\n' porque quando o usuario aperta ENTER no final da frase nada mais é do que um '\n'
    
    for(int i = 0 ; i < 4 ; i++)
    {
        printf("\n%s tem %d anos\n\n", dado[i].nome , dado[i].idade);
    }
    
    return 0;
}
