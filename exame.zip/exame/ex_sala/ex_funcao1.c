#include <stdio.h>

//função para somar dois numeros, a e b

float soma(float a, float b)
{
    a += b;
    return a;
}

int main()
{
    float a = 3, b = 4;
    
    printf("%f + %f = %f\n", 1.0, 2.0, soma(1.0, 2.0));
    printf("antes da soma: a = %f , b = %f\n", a, b);
    printf("%f + %f = %f\n", a, b, soma(a,b));
    printf("depois da soma: a = %f , b = %f\n", a, b);
    
    return 0;
}
