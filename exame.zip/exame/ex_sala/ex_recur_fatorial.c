#include <stdio.h>

int fatorial(int n); //FUNÇÃO PRESENTE NA LINHA 14 

int main()
{
    int n;
    printf("Digite um inteiro positivo: ");
    scanf("%d", &n);

    printf("%d! = %d\n", n, fatorial(n));
}

int fatorial(int n)
{ 
    //FATORIAL = 5! --> 5*4*3*2*1
    //FATORIAL --> n! == n * (n - 1)!
    if(n < 1)
        return 1; // ELA PARA QUANDO CHEGA EM 0
                  // 0! POR DEFINIÇÃO É IGUAL A 1
    else
        return ( n * fatorial(n-1));
}
