//FUNCIONANDO
//Coordenadas do caminho não estão sendo 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

//Casa houver uma saida
//Printa a matriz e a coordenada do caminho que foi percorrido
void print_maze(char **maze, int largura, int altura)
{
    int x, y;
    int i, j;
    
     
    //Caminho que foi percorrido
    printf("[");
    for(i = 0; i < altura; i++)
    {
        for(j = 0; j < largura; j++)
        {
            if(maze[i][j] == '*')
            {
                printf("(");
                printf("%d,%d", i, j);
                printf(")");
            }
        }
    }
    printf("]");
    printf("\n\n");
    
    //Matriz
    for(y = altura - 1; y >= 0; y--)
    {
        for(x = 0; x < largura; x++)
        {
            printf("%c", maze[x][y]);
        }
        printf("\n");
    }
    
    printf("\n\n");
}

int labirinto(int x_atual, int y_atual, char **maze, int largura, int altura) 
{
    //Caso o caminho pego não estiver correto
    if (x_atual < 0 || x_atual >= largura || y_atual < 0 || y_atual >= altura) 
        return 0;
    
    
    char aqui = maze[x_atual][y_atual];

    // Verifica se achou a saída.
    if (aqui == 's')
    {
        return 1;
    }

    // Se bateu na parede ou voltou para algum lugar que já esteve,
    // então este não é o caminho certo.
    if (aqui == '1' || aqui == '*' || aqui == '*' || aqui == '*' || aqui == '*')
        return 0;
    
    
    //Caso queira saber como é feita cada iteração
    /*      print_maze(maze , largura , altura );     */
        
    //Caso algum dos seguintes 'if' funcione
    //Quer dizer que o rato esta passando por um caminho viavel
    
    // Tenta ir para cima.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual, y_atual + 1, maze, largura, altura)) 
    {
        return 1;
    }
    
    // Tenta ir para a direita.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual + 1, y_atual, maze, largura, altura))
    {
        return 1;
    }
    
    // Tenta ir para baixo.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual, y_atual - 1, maze, largura, altura ))
    {
        return 1;
    }
    
    // Tenta ir para a esquerda.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual - 1, y_atual, maze, largura, altura))
    {
        return 1;
    }
    
    // Não deu, então volta.
    maze[x_atual][y_atual] = 'O';   
    return 0;
}


/***********************************************************************/


int main(void) 
{
    int largura, altura, x_entrada, y_entrada;
    int resultado;
    
    //lê o tamanho da sua matriz
    scanf("%d %d\n", &largura, &altura);
    
    //Aloca a memoria para a largura da matriz
    char **a = malloc(largura * sizeof(char*));
    
    //Aloca memoria sulficiente para (largura x altura)
    for (int x = 0; x < largura; x++) 
        a[x] = malloc(altura * sizeof(char));
    
    for (int y = altura - 1; y >= 0; y--) 
    {
        for (int x = 0; x < largura; x++) 
        {
            //Lê os caracteres da matriz
            //Um a um e sem espaços entre eles
            a[x][y] = getchar();
            
            //Quando verificar o caractere 'e'
            //As coordenadas de x e y vão ser a saida do labirinto
            if (a[x][y] == 'e') 
            {
                x_entrada = x;
                y_entrada = y;
            }
        }
        //Lê o '\n' a quebra de linha
        getchar();
    }
    printf("\n..........................................................\n");
    printf("\n");
    
    //Caso a func 'labirinto' retornar 1: funcionou, caso contrario labirinto sem saida ou mal formmatado
    resultado = labirinto(x_entrada, y_entrada, a, largura, altura);

        
    if(resultado == 1)
    {
        printf("\nS\n\n");
        print_maze(a, largura, altura);
    }
    else
        printf("\nN\nLabirinto sem saida\n");
    
    return 0;
}
