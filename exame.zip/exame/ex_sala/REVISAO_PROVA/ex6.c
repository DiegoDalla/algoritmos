#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float SOMATORIO (int n);

int main()
{
    int x;
    
    scanf("%d", &x);
    
    printf("O valor do somatorio é: %.2f\n", SOMATORIO(x));
    
    return 0;
}

float SOMATORIO(int n)
{
    int i = 480, j;
    float s = 0.0;
    
    for(j = 10 ; j-10 <= n ; j++ , i -= 5)
    {
        if(j%2 == 0)
            s -= (float)i / (float)j;
        
        else if(j%2 == 1)
            s += (float)i / (float)j;
    }
}
