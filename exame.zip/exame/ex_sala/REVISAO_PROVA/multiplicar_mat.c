#include <stdio.h>

int main()
{
    int mat1[][3] = {{1} , {1} , {1} ,\
                     {1} , {1} , {1} ,\
                     {1} , {1} , {1}};
        
    int mat2[][3] = {{1} , {1} , {1} ,\
                     {1} , {1} , {1} ,\
                     {1} , {1} , {1}};
    
    int matR[3][3] = {0};
    
    
    for(int l = 0 ; l < 3 ; l++)
        for(int c = 0 ; c < 3 ; c++)
            for(int k = 0 ; k < 3 /*Tamanho da linha ou coluna*/ ; k++)
            {
                matR[l][c] += mat1[l][k] * mat2[k][c];
            }
            
    for(int l = 0 ; l < 3 ; l++)
    {
        for(int c = 0 ; c < 3 ; c++)
        {
            printf("%d\t", matR[l][c]);
        }
        
        printf("\n");
    }       
            
    return 0;
}

