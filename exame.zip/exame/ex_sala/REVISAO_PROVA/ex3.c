#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x;
    
    scanf("%d", &x);
    
    float SOMATORIO (int n);
    
    printf("O valor do somatorio é: %.2f\n", SOMATORIO(x));
    
    return 0;
}

float SOMATORIO(int n)
{
    int x=37, y=38, z=1;
    int k;
    float s;
    
    for(k = 1 ; k <= n ; k++,x--,y--,z++)
        s += (x * y) / z; 
    return s;
}

