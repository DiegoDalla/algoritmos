#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    
    scanf("%d", &x);
    
    float SOMATORIO (int n);
    
    printf("O valor do somatorio é: %f\n", SOMATORIO(x));
    return 0;
}

float SOMATORIO (int n)
{
    int i, j; //INDICE PARA O FOR
    float s = 0; //SAIDA
    
    for(i = 1 ; i <= n ; i++)
        for(j = 1 ; j <= n ; j++)
        {
            s += ((float)i / (float)j); 
            
            i += 2;
        }
}
