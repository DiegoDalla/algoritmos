# include <stdio.h>

# include <stdlib.h>

int i=0,cont=0;

char dna[4],cadeia[30],resultado;

int genoma()
{
	for(i=0;i<30;i++)
	{
		if(dna[0]==cadeia[i] && dna[1]==cadeia[i+1] && dna[2]==cadeia[i+2] && dna[3]==cadeia[i+3])
		cont++;
	}
	printf("O total de ocorrencias entre os dois genomas foi de.: %d ocorencias.\n\n",cont);
	printf("As ocorrencias foram..:\n");
	return 0;
}

int main()

{

FILE*arquivo;

arquivo=fopen("dna.txt","r+");

printf("Informe o DNA:");

gets(dna);

fprintf(arquivo,"\nDNA DIGITADO:%s",dna);

fclose(arquivo);

printf("\nDNA INFORMADO COM SUCESSO.\n");

getch();

system("cls");

FILE*arquivo2;

arquivo2=fopen("Cadeia.txt","r+");

printf("Informe a Cadeia:");

gets(cadeia);

fprintf(arquivo2,"\nCADEIA:%s",cadeia);

fclose(arquivo2);

printf("\nCADEIA INFORMADO COM SUCESSO.\n");

getch();

system("cls");

genoma();

system("pause");

}
