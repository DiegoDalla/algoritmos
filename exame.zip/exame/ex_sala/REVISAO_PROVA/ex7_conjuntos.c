#include <stdio.h>

int main()
{
    int x; //numero de elementos do conjunto
    int i, j, k, l; //parametro para o while
    int contI=0 , contU=0; //contadores
    
    scanf("%d", &x);
    
    int a[x] , b[x]; //conjuntos de entrada
    
    for(i = 0 ; i < x ; i++)
        scanf("%d", &a[i]);
    
    for(i = 0 ; i < x ; i++)
        scanf("%d", &b[i]);
    
    for(i = 0 ; i < x ; i++)
        for(j = 0 ; j < x ; j++)
        {
            //Contador para o tamanho do vetor intercecção
            if(a[i] == b[j])
                contI++;
        }
        
    contU = (2*x)-contI
    
    int vetI[contI] , vetU[contU];
    int contA=0;
    
    for(i = 0 ; i < x ; i++)
        for(j = 0 ; j < x ; j++)
            if(a[i] == b[j])
                for(k = 0 ; k < contI ; k++)
                    vetI[k] = a[i];
        
    for(i = 0 ; i < x ; i++)
        for(j = 0 ; j < x ; j++)
        {
            if(a[i] != b[j])
            {
                vetU =
            }
            else
                for(l = contI+1 ; l <= contU ; l++)
                    vetU[l] =
        }           
    return 0;
}

