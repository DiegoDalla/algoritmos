#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x;
    
    scanf("%d", &x);
    
    float SOMATORIO (int n);
    
    printf("O valor do somatorio é: %f\n", SOMATORIO(x));
    
    return 0;
}

float SOMATORIO (int n)
{
    int i, j = 50; //INDICE PARA O FOR
    float s;  //SAIDA
    
    for(i = 1 ; i <= n ; i++,j--)
    {
        s += ((pow(2.00,(float)i)) / (float)j);
    }    
    
    return s;
}
