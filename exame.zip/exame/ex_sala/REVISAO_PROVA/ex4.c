#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x;
    
    scanf("%d", &x);
    
    float SOMATORIO (int n);
    
    printf("O valor do somatorio é: %.2f\n", SOMATORIO(x));
    
    return 0;
}

float SOMATORIO(int n)
{
    int i;  //indice para o for
    float s;    //saida
    
    for(i = 1 ; i <= n ; i++)
    {
        if(i % 2 == 1)
            s += (i / pow(i,2));
        else if(i % 2 == 0)
            s -= (i / pow(i,2));
    }
    
    return s;
}
