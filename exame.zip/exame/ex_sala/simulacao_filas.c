#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    
    for(int i=0;;i++)
    {
        printf("Laço\n\n");
    }
    return 0;
}
