#include <stdio.h>

int contadigito(int digito, int num);

int main()
{
    int a, b;
    scanf("%d %d", &a, &b);
    printf("%d aparece %d vezes no numero %d\n", a, contadigito(a,b), b);
}

int contadigito(int digito, int num)
{
    if(num == 0)
        return 0;
    
    else
        return(num % 10 == digito) + contadigito(digito , num/10);
}
