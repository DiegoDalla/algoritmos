//  GUILHERME SUTTANNI FERREIRA
//  TRABALHO DE LISTAS ENCADEADAS
//  ALGORITIMOS - 1º PERIODO - UNIOESTE - CASVEL/PR
//  DATA DE ENTREGA : 19 / 08 / 19


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>


//DECLARANDO AS FUNÇÕES
void insertionSort(int ptr[], int n); 
int cmp(int a,int b);
void swp(int *ptr1,int *ptr2);
void print(int *ptr,int n);
void verifica(int *ptr,int n);

int main()
{
    int *array,n;
    
    printf("Numero de elementos: ");
    scanf("%d",&n);
    array = (int *)	malloc(n*sizeof(array));

    //Pega os elementos do usuario
    printf("Informe os elementos e press ENTER:  ");
    verifica(array,n);
    
    //Começa a medir o tempo de execução
    clock_t Ticks[2];
    Ticks[0] = clock(); 
    
    //Imprime os elementos do usuario
    printf("\nVetor digitado:  ");
    print(array,n);
    
    insertionSort(array,n);
    //O Insertion Sort começa a trabalhar com o segundo valor do vetor e vai jogando ele para a esquerda (início do vetor). Ele percorre todo o vetor um única vez
    
    //Imprime o novo vetor
    printf("\nVetor ordenado:  ");
    print(array,n);
    
    //Termina de medir o tempo de execução
    Ticks[1] = clock();
    double Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
    printf("\n\nTempo gasto: %g ms.\n", Tempo);
    
    
    return 0;
}

//Função de ordenação
void insertionSort(int *ptr, int n) 
{ 
    int i, aux, j;  //O aux é o primeiro número que não esta ordenado
    for (i = 1; i < n; i++) { 
        aux = ptr[i]; 
        j = i - 1; 

        while (j >= 0 && ptr[j] > aux) { 
            ptr[j + 1] = ptr[j]; 
            j = j - 1; 
        } 
        ptr[j + 1] = aux;
        //Move os elementos que são maior dentro do vetor para uma posição a frente da sua posiçao atual
        
        //VANTAGENS
        /*
         * É um bom metodo para quando o arquivo ja esta quase ordenado
         * É bom para quando faltam poucos elemento para serem add
         * É um algoritimo estavel
         * 
         */
        //DESVANTAGENS
        /*
         * Alto custo para movimentar os elementos
         */
    } 
} 

//Função p/ comparar os valores
int cmp(int a,int b)
{
    if(a>b){
        return 1;
    }else{ 
        return 0;
    }
}

void swp(int *ptr1,int *ptr2)
{
    int aux;
    
    aux = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = aux;
}


void verifica (int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        scanf("%d",&ptr[i]);
}

void print(int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        printf("%s%d%s",(i==0)?(""):(""),ptr[i],(i<n-1)?(" , "):("\n"));
}
