int MDC(int a, int b)
{
    if(b == 0)
        return a;
    
    else
        return MDC(b , a % b);
}

int main()
{
    int x, y;
    int saida;
    
    scanf("%d %d",&x,&y);
    
    saida = MDC(x , y);
    
    printf("%d" ,saida);
    
    return 0;
}
