#include <stdio.h>

int IMC(int p , int alt)
{
    int imc;
    
    scanf("%d %d", &p , &alt);
    
    imc = p * alt;

}

int main()
{
    int a , b;
    
    printf("IMC = %d" ,IMC(a,b));
    
    return 0;
    
}
    
