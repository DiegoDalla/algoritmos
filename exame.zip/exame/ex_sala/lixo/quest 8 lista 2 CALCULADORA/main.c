#include <stdio.h>
#include <stdlib.h>

int main()
{
    int op1 , op2 , res; //OS OPERADOS E O RESULTADO
    char op;  //OPERA��O

    scanf("%d %c %d", &op1, &op, &op2);
    switch(op)
    {
        case '+':
            res = op1 + op2; break;
        case '-':
            res = op1 - op2; break;
        case '*':
            res = op1 * op2; break;
        case '/':
            res = op1 / op2; break;
    }
    printf("%d %c %d = %d\n",op1,op,op2,res);
    return 0;
}
