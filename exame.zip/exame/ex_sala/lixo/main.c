#include <stdio.h>
#include <stdlib.h>
#define n 5

int main()
{
    int i;
    int vet[5];


    for( i = 0 ; i <= 5 ; i++)
    {
        scanf("%d", vet[i]);
    }

    printf("[");
    for( i = 0 ; i <= 5 ; i++)
    {
        printf("%d", vet[i]);
        if(i < 5 - 1)
        {
            printf(",");
        }
    }
    printf("]\n");

    return 0;
}
