//FUNCIONANDO
//Coordenadas do caminho não estão sendo 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>


void print_position(int x, int y)
{
  printf("(%d, %d)", x, y);
}

//Casa houver uma saida
//Printa a matriz e a coordenada do caminho que foi percorrido
void print_maze(char **maze, int largura, int altura)
{
    int x, y;
    
    //Matriz
    for(y = 0; y < altura; y++)
    {
        for(x = 0; x < largura; x++)
        {
            printf("%c", maze[x][y]);
        }
        printf("\n");
    }
    
    printf("\n\n");
}

//Ultiliza recursiva para encontrar o caminho do labirinto
int labirinto(int x_atual, int y_atual, char **mat, int largura, int altura) 
{
    //Caso o caminho pego não estiver correto
    if (x_atual < 0 || x_atual >= largura || y_atual < 0 || y_atual >= altura) 
        return 0;
    
    
    char aqui = mat[x_atual][y_atual];

    // Verifica se achou a saída.
    if (aqui == 's')
    {
        return 1;
    }

    // Se bateu na parede ou voltou para algum lugar que já esteve,
    // então este não é o caminho certo.
    if (aqui == '1' || aqui == '*' || aqui == '*' || aqui == '*' || aqui == '*')
        return 0;
    
    
    //Caso queira saber como é feita cada iteração
    /*      print_maze(mat , largura , altura );     */
    //Caso algum dos seguintes 'if' funcione
    //Quer dizer que o rato esta passando por um caminho viavel
    
    // Tenta ir para cima.
    mat[x_atual][y_atual] = '*';
        
    
    //Mostra as coordenadas que o rato passou
    print_position(y_atual+1,x_atual+1);    
      
    if (labirinto(x_atual, y_atual + 1, mat, largura, altura)) 
    {
        return 1;
    }
    
    // Tenta ir para a direita.
    mat[x_atual][y_atual] = '*';
    
    if (labirinto(x_atual + 1, y_atual, mat, largura, altura))
    {
        return 1;
    }
    
    // Tenta ir para baixo.
    mat[x_atual][y_atual] = '*';
   
    if (labirinto(x_atual, y_atual - 1, mat, largura, altura ))
    {
        return 1;
    }
    
    // Tenta ir para a esquerda.
    mat[x_atual][y_atual] = '*';
    
    if (labirinto(x_atual - 1, y_atual, mat, largura, altura))
    {
        return 1;
    }
    
    //ARMAZENA AS POSIÇÕES QUE JA FORAM PASSADAS
    //Coloca o '0' novamente caso tenha pego o caminho errado
    // Não deu, então volta.
    mat[x_atual][y_atual] = '0';   
    return 0;
}

/***************************************************************************/


int main(void) 
{
    int largura, altura, xEnt, yEnt;
    int resultado;
    
    //lê o tamanho da sua matriz
    scanf("%d %d\n", &largura, &altura);
    
    //Aloca a memoria para a largura da matriz
    char **a = malloc(largura * sizeof(char*));
    
    //Aloca memoria sulficiente para (largura x altura)
    for (int x = 0; x < largura; x++) 
        a[x] = malloc(altura * sizeof(char));
    
    for (int y = 0; y < altura; y++) 
    {
        for (int x = 0; x < largura; x++) 
        {
            //Lê os caracteres da matriz
            //Um a um e sem espaços entre eles
            a[x][y] = getchar();
            
            //Quando verificar o caractere 'e'
            //As coordenadas de x e y vão ser a saida do labirinto
            if (a[x][y] == 'e') 
            {
                xEnt = x;
                yEnt = y;
            }
        }
        //Lê o '\n' a quebra de linha
        getchar();
    }
    printf("\n..........................................................\n\n");
    
    //Caso a func 'labirinto' retornar 1: funcionou, caso contrario labirinto sem saida ou mal formmatado
    resultado = labirinto(xEnt, yEnt, a, largura, altura);
    
    printf("\n");
        
    
    if(resultado == 1)
    {
        printf("\nS\n\n");
        print_maze(a, largura, altura);
    }
    else
    {
        
        printf("\nN\nLabirinto sem saida\n");
    }
    return 0;
}
