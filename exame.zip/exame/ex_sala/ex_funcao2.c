#include <stdio.h>

int MULT(int a , int b)
{
    int saida;
    
    saida = a * b;
}

int main(void)
{
    int x, y;
    int res; //RESPOSTA
    
    scanf("%d %d", &x, &y);
    
    res = MULT(x , y);
    
    printf("%d x %d = %d\n", x, y, res);
    
    return 0;
}

