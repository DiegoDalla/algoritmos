#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 m = linha
 n = coluna
 i = indice da linha
 j = indice da coluna
 a = num entre 0 e m
 b = num entre 0 e  n
 x = posição entre i , j
*/

/*----------------------------------------------------------*/

//Estrutura de cada valor
typedef struct celula
{
    struct celula *direita , *abaixo;
    int linha , coluna;
    float valor;
}tipo_celula;

//Estrutura de toda a matriz
typedef struct matriz_esparsa
{
    int m , n;
    //Registra a cabeça e o fim de cala linha/coluna
    tipo_celula *inicio, *fim_linha , *fim_coluna;
}matriz_esparsa;

/*----------------------------------------------------------*/

int insere_cabeca_coluna(matriz_esparsa *mat)
{
    tipo_celula *cabeca;
    
    cabeca = (tipo_celula*)malloc(sizeof(tipo_celula));
    
    if( !cabeca )
        return 0; //Ocorreu erro
        
    cabeca->coluna = -1;
    cabeca->linha = 0;
    
    mat->fim_coluna->direita = cabeca;
    mat->fim_coluna = cabeca;
    
    cabeca->direita = mat->inicio;
    cabeca->abaixo = cabeca;
    
    return 1; //Funcionou
}

/*----------------------------------------------------------*/

int insere_cabeca_linha(matriz_esparsa *mat)
{
    tipo_celula *cabeca;
    cabeca = (tipo_celula*/*Casting*/)malloc(sizeof(tipo_celula));
    
    if(!cabeca)
        return 0; //Ocorreu erro
        
    cabeca->coluna = 0;
    cabeca->linha = -1;
    
    mat->fim_linha->abaixo = cabeca;
    mat->fim_linha = cabeca;
    
    cabeca->abaixo = mat->inicio;
    cabeca->direita = cabeca;
    
    return 1; //Funcionou
}

/*----------------------------------------------------------*/

//Insere cabeça no campo da linha e coluna
//Cria a estrutura
int inicia_cabeca(matriz_esparsa *mat)
{
    int aux = 0;
    
    tipo_celula *cabeca;
    
    //Aloca memoria para cada cabeça
    cabeca = (tipo_celula*/*Casting*/)malloc(sizeof(tipo_celula));
    
    //singnifica um erro
    if(!cabeca)
        return 0;
    
    //cabeça principal [-1 , -1]
    //Pois o primeiro elemento esta no [0 , 0]
    cabeca->coluna = -1;
    cabeca->linha = -1;
    
    mat->fim_coluna = cabeca;
    mat->fim_linha = cabeca;
    mat->inicio = cabeca;
    
    for(aux = 1 ; aux <= mat->n; aux++)
        insere_cabeca_coluna(mat);
    for(aux = 1 ; aux <= mat->m; aux++)
        insere_cabeca_linha(mat);
    
    return 1; //funcionou
}

/*----------------------------------------------------------*/

//Aloca memoria sulficiente para a matriz
//e tambem para as cabeças de cada linha/coluna
matriz_esparsa *criar_matriz (int m , int n)
{
    matriz_esparsa *mat;
    
    mat = (matriz_esparsa* /*Casting*/)malloc(sizeof(matriz_esparsa));
    
    //Caso a matriz nao tiver nenhum elemento
    if(!mat || m <= 0 || n <= 0)
    {
        return 0;
    }
    
    mat->fim_linha = NULL;
    mat->fim_coluna = NULL;
    mat->inicio = NULL;
    
    //Recebe numero de linhas
    mat->m = m;
    
    //Recebe numero de colunas
    mat->n = n;
    
    inicia_cabeca(mat);
    
    return mat;
}

/*----------------------------------------------------------*/

int insere_valor(matriz_esparsa *mat,int linha,int coluna,float valor)
{
    int i , j;
    
    //Nao insere
    if(!mat || mat->m <= 0 || mat->n <= 0 || !valor)
        return 0;
    
    //Nao insere
    if(linha>mat->m || coluna>mat->n || !valor || linha < 1 || coluna < 1)
        return 0;
    
    tipo_celula *pCelula; //aux temporario
    tipo_celula *pCelulaColuna; //aux temporario p/ coluna
    tipo_celula *pCelulaLinha; //aux temporario p/ linha
    
    pCelula = (tipo_celula*/*Casting*/)malloc(sizeof(tipo_celula));
    
    if(!pCelula)
        return 0;
    
    pCelula->linha = linha;
    pCelula->coluna = coluna;
    pCelula->valor = valor;
    
    //Como é linha entao passa para baixo 
    //aponta para a 1º cabeça da linha
    pCelulaLinha = mat->inicio->abaixo;
    
    //Como é coluna passa ppra frente
    //aponta para a 1º cabeca da coluna
    pCelulaColuna = mat->inicio->direita;
    
    //Percorre ate a linha do elemento
    //Percorre nas cabecas ate a informada
    //Usa 'linha-1' porque ja esta na primeira
    for(i = 0 ; i<linha-1 ; i++)
        //Vai pra baixo ate achar a correta
        pCelulaLinha = pCelulaLinha->abaixo;
    
    j = 0;
    while(j<coluna && pCelulaLinha->direita->linha != -1)
    {
        //Caso a celula estiver a esquerda
        if(pCelulaLinha->direita->coluna > pCelula->coluna)
        {
            pCelula->direita = pCelulaLinha->direita;
            pCelulaLinha->direita = pCelula;
        }
        else
            pCelulaLinha = pCelulaLinha->direita;
        
        j++;
    }
    
    //Caso a celula esta a direita
    if(pCelulaLinha->direita->linha == -1)
    {
        //Aponta para a cabeça
        pCelula->direita = pCelulaLinha->direita;
        
        //Ultima celula/cabeça
        //Se nao houver celula aponta para cabeça
        pCelulaLinha->direita = pCelula;
    }
    
    //Se chegou até aqui a linha foi encontrada
    //E tambem apontada
    
    
    //Agora encontramos a coluna
    //'coluna-1' pq ja ta na primeira
    for (i = 0; i < coluna-1; i++)
    {
        //Percorre a direita ate achar a coluna correta
        pCelulaColuna = pCelulaColuna->direita;
    }
    
    i=0;
    while(i<linha && pCelulaColuna->abaixo->coluna != -1)
    {
        if(pCelulaColuna->abaixo->linha > pCelula->linha)
        {
            pCelula->abaixo = pCelulaColuna->abaixo;
            pCelulaColuna->abaixo = pCelula;
        }
        else
            pCelulaColuna = pCelulaColuna->abaixo;
        
        i++;
    }
    
    if(pCelulaColuna->abaixo->coluna == -1)
    {
        //Aponta para a cabeça
        pCelula->abaixo = pCelulaColuna->abaixo;
        
        pCelulaColuna->abaixo = pCelula;
    }
    
    return 1;
}

/*----------------------------------------------------------*/

float obtemElem(matriz_esparsa *mat , int linha , int coluna)
{
    tipo_celula *pCelula;
    int i = 0;

    pCelula = mat->inicio->direita;

    //Coloca o indice na coluna desejada
    for (i = 0; i < coluna-1; i++)
    {
        pCelula = pCelula->direita;
    }

    do{
        pCelula = pCelula->abaixo;
        
        if (pCelula->linha == linha)
            return pCelula->valor; //Elemento encontrado
        
    }while(pCelula->coluna != -1);

    return 0; //elemento nao encontrado
}

/*----------------------------------------------------------*/

//Lembrar que a soma de duas matrizes só são possiveis quando ambas tem a mesma ordem
matriz_esparsa *somaMatriz(matriz_esparsa *matA,matriz_esparsa *matB)
{
    int i , j;
    float soma;
    
    //Matriz resultante
    matriz_esparsa *matC;
    tipo_celula *pCelulaA , *pCelulaB;
    
    if(matA->m != matB->m || matA->n != matB->n)
    {
        printf("\n--ERRO--\nmatA e matB possuem ordem diferentes\n");
        return NULL; //ERRO
    }
    
    if(!matA || !matB || !matA->m || !matA->n)
        return NULL; //ERRO
        
    matC = criar_matriz(matA->m , matB->n);
    
    pCelulaA = matA->inicio->abaixo;
    pCelulaB = matB->inicio->abaixo;
    
    for(i=1 ; i<=matA->m ; i++)
    {
        for(j=1 ; j<=matA->n ; j++)
        {
            if(j == pCelulaA->direita->coluna && j == pCelulaB->direita->coluna)
            {
                soma = pCelulaA->direita->valor + pCelulaB->direita->valor;
                
                if(soma)
                    insere_valor(matC , i , j , soma);
                
                pCelulaA = pCelulaA->direita;
                pCelulaB = pCelulaB->direita;
            }
            else if(j == pCelulaA->direita->coluna)
            {
                insere_valor(matC,i,j,pCelulaA->direita->valor);
                pCelulaA = pCelulaA->direita;
            }
            else if(j == pCelulaB->direita->coluna)
            {
                insere_valor(matC,i,j,pCelulaB->direita->valor);
                pCelulaB = pCelulaB->direita;
            }
        }
        
        pCelulaA = pCelulaA->direita->abaixo;
        pCelulaB = pCelulaB->direita->abaixo;
    }
    
    return matC;
}

/*----------------------------------------------------------*/

//O numero de colunas de A tem que ser igual ao numero de B
matriz_esparsa *multiplicaMatriz(matriz_esparsa *matA , matriz_esparsa *matB)
{
    int i = 0 , j = 0 , k = 0;
    float total;
    
    //Matriz resultante
    matriz_esparsa *matC;
    
    if(matA->n != matB->m)
    {
        printf("\n--ERRO--\nO numero de colunas da matriz A não é igual ao numero de linhas da matriz B\n");
        return NULL;
    }
    
    //C te o mesmo numero de linhas que A e o de colunas de B
    matC = criar_matriz(matA->m , matB->n);
    
    for(i = 1 ; i <= matA->m ; i++)
    {
        for(j = 1 ; j <= matB->n ; j++)
        {
            total = 0;
            
            for(k = 1 ; k <= matA->n; k++)
            {
                total += obtemElem(matA,i,k)*obtemElem(matB,k,j);
            }
            if(total)
                insere_valor(matC,i,j,total);
            
        }
    }
    
    return matC;
}

/*----------------------------------------------------------*/

int imprimeMatriz(matriz_esparsa *mat)
{
    int i, j;
    
    tipo_celula *pCelula;
    
    if(!mat || !mat->m || !mat->n)
        return 0; //Ocorreu erro, 'mat' ñ existe
        
    pCelula = mat->inicio->abaixo;
    printf("\n");
    
    for(i = 1 ; i <= mat->m ; i++)
    {
        for(j = 1 ; j <= mat->n ; j++)
        {
            if(pCelula->direita->linha == i && pCelula->direita->coluna == j)
            {
                pCelula = pCelula->direita;
                
                printf("  \t%0.2f  ", pCelula->valor);
            }
            else
                printf("  \t%0.2f  ", 0.0F);
        }
        printf("\n");
        pCelula = pCelula->direita->abaixo;
    }
    
    return 1; //Funcionou
}

/*----------------------------------------------------------*/

int apagaMatriz(matriz_esparsa *mat)
{
    int i = 1; 
    int j = 1;
    
    tipo_celula *pCelula , *aux;
    
    if(!mat || !mat->m || !mat->n)
        return 0;
    
    pCelula = mat->inicio->abaixo;
    pCelula = pCelula->direita;
    
    for(i = 1 ; i <= mat->m ; i++)
    {
        for(j = 1 ; j <= mat->n ; j++)
        {
            if(pCelula->linha == i && pCelula->coluna == j)
            {
                aux = pCelula;
                pCelula = pCelula->direita;
                
                free(aux); //Limpa o espaço de memoria
            }
        }
        
        pCelula = pCelula->abaixo->direita;
    }
    
    pCelula = pCelula->abaixo->direita;
    
    for(i = 0 ; i < mat->m ; i++)
    {
        aux = pCelula;
        pCelula = pCelula->abaixo;
        
        free(aux);
    }
    
    pCelula = mat->inicio;
    free(pCelula);
    
    mat->fim_coluna = mat->fim_linha = mat->inicio = NULL;
    mat->m = mat->n = 0;
    mat = NULL;
    
    return 1;
}

/*----------------------------------------------------------*/

matriz_esparsa* le(matriz_esparsa *mat)
{
    int m=0 , n=0;
    int l=0 , c=0;
    float valor=0;
    
    printf("\nInforme as dimensões da matriz: ");
    scanf("%d %d", &m, &n);
    
    if(m<=0 || n<=0)
    {
        printf("Dimensões invalidas\n");
        return 0;
    }
    
    mat = criar_matriz(m , n);
    
    printf("Informe os elementos da matriz:\n");
    printf("Não esqueça que as coord começam em [1][1]\n");
    printf("---------------------------------------------------\n");
    
    for(int i=0 ; i<(m*n) ; i++)
    {
        printf("Coordenada: ");
        scanf("%d %d", &l, &c);
        printf("Valor [%d][%d]:", l , c);
        scanf("%f", &valor);
        
        if(valor)
            insere_valor(mat , l , c , valor);
    }
    
    return mat;
}

/*----------------------------------------------------------*/

int main(void)
{
    int op,aux,opt;
    int m;
    int l , c; //linha / coluna
    
    matriz_esparsa *matA = NULL;
    matriz_esparsa *matB = NULL;
    matriz_esparsa *matC = NULL;

    
    while(1)
    {
        system("clear");
        
        printf("\n---------------------------------------");
        printf("\n-> 1 . Ler matriz");
        printf("\n-> 2 . Imprimir matriz");
        printf("\n-> 3 . Apagar matriz");
        printf("\n-> 4 . Somar matriz");
        printf("\n-> 5 . Multiplicar matrizes");
        printf("\n-> 0 . SAIR");
        printf("\n---------------------------------------\n");
        printf("\nEscolha uma opção: ");
        scanf("%d", &op);
        printf("\n");
        
        switch(op)
        {
            case 1:
            {
                system("clear");
                
                printf("Para ler dados armazenados em um arquivo (1)\n");
                printf("Para digitar as matrizes (2)\n");
                scanf("%d", &opt);
                system("clear");
                
                if(opt == 1)
                {
                    
                }
                else if(opt == 2)
                {
                    printf("Você deseja inicializar a matriz A(1) ou B(2)?: ");
                    scanf("%d", &m);
                
                    switch(m)
                    {
                        case 1:
                        {
                            matA = NULL;
                        
                            //Caso a matriz tenha algum lixo nela
                            //Essa func limpa p/ as op. futuras
                            if(matA)
                                apagaMatriz(matA);
                        
                            matA = le(matA);
                        
                            if(matA == NULL)
                                printf("Erro ao inicializar matriz\n");
                        
                            break;
                        }
                    
                        case 2:
                        {
                            matB = NULL;
                        
                            if(matB)
                                apagaMatriz(matB);
                        
                            matB = le(matB);
                        
                            if(matB == NULL)
                                printf("Erro ao inicializar matriz\n");
                            break;
                        }
                    }
                    break;
                }
            }
            
            
            case 2:
            {
                system("clear");
                
                printf("Qual matriz você deseja imprimir?");
                printf(" A(1) B(2) C(3): ");
                scanf("%d", &m);
                
                switch(m)
                {
                    case 1:
                    {
                        if(!matA)
                            break;
                        
                        
                        imprimeMatriz(matA);
                        break;
                    }
                    
                    case 2:
                    {
                        if(!matB)
                            break;
                        
                        
                        imprimeMatriz(matB);
                        break;
                    }
                    
                    case 3:
                    {
                        if(!matC)
                            break;
                        
                        
                        imprimeMatriz(matC);
                        break;
                    }
                }
                
                getchar();
                printf("\nPress [ENTER] para continuar.\n");
                while(getchar() != '\n')
                {}
                
                break;
            }
             
            
            case 3:
            {
                system("clear");
                printf("Deseja apagar qual matriz?");
                printf(" A(1) , B(2) , C(3):  ");
                scanf("%d", &m);
                
                switch(m)
                {
                    case 1:
                    {
                        printf("Apagando Matriz 'A'....\n");
                        matA = NULL;
                        
                        getchar();
                        printf("\nPress [ENTER] para continuar.\n");
                        while(getchar() != '\n')
                        {}
                    
                        
                        break;
                    }
                    
                    case 2:
                    {
                        printf("Apagando Matriz 'B'....\n");
                        matB = NULL;
                        
                        getchar();
                        printf("\nPress [ENTER] para continuar.\n");
                        while(getchar() != '\n')
                        {}
                        
                        break;
                    }
                    
                    case 3:
                    {
                        printf("Apagando Matriz 'C'....\n");                         matC = NULL;
                        
                        getchar();
                        printf("\nPress [ENTER] para continuar.\n");
                        while(getchar() != '\n')
                        {}
                        
                        break;
                    }
                }
                
                break;
            }
            
            case 4:
            {
                system("clear");
                
                if(matA == NULL || matB == NULL)
                {
                    if(matA == NULL)
                    {
                        printf("A matriz 'A' não foi lida\n");
                    }
                    
                    if(matB == NULL)
                    {
                        printf("A matriz 'B' não foi lida\n");
                    }
                    
                    getchar();
                    printf("\nPress [ENTER] para continuar.\n");
                    while(getchar() != '\n')
                    {}
                    
                    break;
                }
                
                if(matA && matB)
                {
                    printf("A matriz C é a resultante de A+B\n");
                    matC = somaMatriz(matA,matB);
                
                    getchar();
                    printf("\nPress [ENTER] para continuar.\n");
                    while(getchar() != '\n')
                    {}
                    
                    break;
                }
                
                break;
            }
            
            case 5:
            {
                system("clear");
                
                if(matA == NULL || matB == NULL)
                {
                    if(matA == NULL)
                    {
                        printf("A matriz 'A' não foi lida\n");
                    }
                    
                    if(matB == NULL)
                    {
                        printf("A matriz 'B' não foi lida\n");
                    }
                    
                    getchar();
                    printf("\nPress [ENTER] para continuar.\n");
                    while(getchar() != '\n')
                    {}
                    
                    break;
                }
                
                if(matA && matB)
                {
                    printf("A matriz C é a resultante de A*B\n");
                    matC = multiplicaMatriz(matA,matB);
                    
                    getchar();
                    printf("\nPress [ENTER] para continuar.\n");
                    while(getchar() != '\n')
                    {}
                    
                    break;
                }
                
                break;
            }
            
            case 0:
            {
                printf("SAINDO....\n");
                return 0;
                break;
            }
            default:
            {
                printf("Comando invalido.\n");
                break;
            }
        }
    }
    
    printf("\n\n");
    
    return 0;
}
