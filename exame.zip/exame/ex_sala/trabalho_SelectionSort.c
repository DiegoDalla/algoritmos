//  GUILHERME SUTTANNI FERREIRA
//  TRABALHO DE LISTAS ENCADEADAS
//  ALGORITIMOS - 1º PERIODO - UNIOESTE - CASVEL/PR
//  DATA DE ENTREGA : 19 / 08 / 19


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>


//DECLARANDO AS FUNÇÕES
void selectionSort(int *arr, int n);
int cmp(int a,int b);
void swp_selection(int *xp, int *yp);
void print(int *ptr,int n);
void verifica(int *ptr,int n);

int main()
{
    int *array,n;
    
    printf("Numero de elementos: ");
    scanf("%d",&n);
    array = (int *)	malloc(n*sizeof(array));

    //Pega os elementos do usuario
    printf("Informe os elementos e press ENTER:  ");
    verifica(array,n);
    
    //Começa a medir o tempo de execução
    clock_t Ticks[2];
    Ticks[0] = clock(); 
    
    //Imprime o vetor digitado pelo usuario
    printf("\nVetor digitado:  ");
    print(array,n);
    
    selectionSort(array,n);
    //Selection Sort é um algoritimo de ordenação que se baseia em passar em todos os casos o menor valor do vetor para a primeira posição, ou pode ser tambem o maior, tudo depende da ordem requerida
    
    
    //Imprime o vetor
    printf("\nVetor ordenado:  ");
    print(array,n);

    //Termina de medir o tempo de execução
    Ticks[1] = clock();
    double Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
    printf("\n\nTempo gasto: %g ms.\n", Tempo);
    
    
    return 0;
}


//Função de ordenação
void selectionSort(int *ptr, int n) 
{ 
    int i, j;
    int minimo; 
  
    for (i = 0; i < n-1; i++) 
    { 
        minimo = i; 
        for (j = i+1; j < n; j++) 
        {
          if (ptr[j] < ptr[minimo])
          {
            minimo = j;
          }
        }
        
        //Na linha 48, é trocado o menor numero pelo primeiro
        swp_selection(&ptr[minimo], &ptr[i]); 
    } 
} 


//Função p/ comparar os valores
int cmp(int a,int b)
{
    if(a>b){
        return 1;
    }else{ 
        return 0;
    }
}



void verifica (int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        scanf("%d",&ptr[i]);
}


void swp_selection(int *ptr1, int *ptr2) 
{ 
    int temp = *ptr1; 
    *ptr1 = *ptr2; 
    *ptr2 = temp; 
} 


void print(int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        printf("%s%d%s",(i==0)?(""):(""),ptr[i],(i<n-1)?(" , "):("\n"));
}
