//  GUILHERME SUTTANNI FERREIRA
//  TRABALHO DE LISTAS ENCADEADAS
//  ALGORITIMOS - 1º PERIODO - UNIOESTE - CASVEL/PR
//  DATA DE ENTREGA : 19 / 08 / 19


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>


//DECLARANDO AS FUNÇÕES
void BubbleSort(int *arr, const int n);
void BubbleSort_rec(int *ptr, const int n);
int cmp(int a,int b);
void swp(int *ptr1,int *ptr2);
void print(int *ptr,int n);
void verifica(int *ptr,int n);

int main()
{
    int *array,n;
    
    printf("Numero de elementos: ");
    scanf("%d",&n);
    array = (int *)	malloc(n*sizeof(array));

    //Pega os elementos do usuario
    printf("Informe os elementos e press ENTER:  ");
    verifica(array,n);
    
    //Começa a medir o tempo de execução
    clock_t Ticks[2];
    Ticks[0] = clock(); 
    
    //Imprime o vetor informado pelo usuario
    printf("\nVetor digitado:  ");
    print(array,n);
    
    BubbleSort(array,n);
    //é verificado os elementos de dois nós "adjacentes", se eles estiverem ja em ordem nada ocorre, mas se eles estiverem em meio decrescente entao trocamos os elementos, fazemos isso com um elemento de cada vez até ele  assumir sua posição original;
    
    //Imprime o novo vetor
    printf("\nVetor ordenado:  ");
    print(array,n);
    
    //Termina de medir o tempo de execução
    Ticks[1] = clock();
    double Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
    printf("\n\nTempo gasto: %g ms.\n", Tempo);
    
    
    return 0;
}

void BubbleSort(int *arr, const int n)
{
    
    int sort=1;
    int i;
    
    
    //caso o laço ficar em 0, a lista esta ordenada
    for(i=0  ;  i<n-1&&sort  ;  i++) 
    {
        sort=0;
        for(int j=0;j<n-1-i;j++)
            if(cmp(arr[j],arr[j+1]))
            {
                swp(&arr[j],&arr[j+1]);
                sort=1;
            }
    }
}

void BubbleSort_rec(int *ptr, const int n)
{

    //Caso base,os últimos n-1 elementos já estão ordenados
    if(n==1) return;
    
    //flag 'booleana' para marcar se houve alguma troca em uma iteração
    int sort=0;

    for(int i=0;i<n-1;i++)
        if(cmp(ptr[i],ptr[i+1]))
        {
            swp(&ptr[i],&ptr[i+1]);
            sort=1;
        }


    if(!sort) 
        return;

    //recursiva para verificar se o valor está no local correto
    return (BubbleSort_rec(ptr,n-1));
}

//Função p/ comparar os valores
int cmp(int a,int b)
{
    if(a>b){
        return 1;
    }else{ 
        return 0;
    }
}

void swp(int *ptr1,int *ptr2)
{
    int aux;
    
    aux = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = aux;
}


void verifica (int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        scanf("%d",&ptr[i]);
}

void print(int *ptr,int n)
{
    int i; //indice para o laço
    for(i=0;i<n;i++)
        printf("%s%d%s",(i==0)?(""):(""),ptr[i],(i<n-1)?(" , "):("\n"));
}
