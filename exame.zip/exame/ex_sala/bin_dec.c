//GUILHERME SUTTANNI FERREIRA
//CIENCIA DA COMPUTAÇÃO ... UNIOESTE
//20 / 05 / 2019
//CONVERSÃO DE BINARIO PARA DECIMAL
//METODO POSICIONAL

/*
COMO FAZER ---->
Pegar a quantidade de numeros binários e depois multiplicar por 2 , com um expoente representante do numero
Exemplo: 1101 na base BINARIO = 1x2³+1x2²+0x2¹+1x2º = 11 na base DECIMAL
Ou seja, os numeros (0 ou 1) vezes 2 elevado ao valor de sua posição (iniciando em 0)
*/

#include <stdio.h>

//FUNÇÃO PARA CALCULAR BINARIO PARA DECIMAL
int bin_dec(int bin)
{
    int total = 0;
    int pot   = 1;

    while(bin > 0) //REALIZAR OS CALCULOS ATÉ O BINARIO CHEGAR A 0
    {
        total +=  bin % 10 * pot;   
        bin    =  bin / 10;         //Diminui um no TAMANHO do numero binario --> retira o valor a direita
        pot    =  pot * 2;          //O pot tem o efeito de 1 | 2 | 4 | 8 | ...
    }

    return total; //retorna o valor de 'total'
}

int main(void)
{
    int dec = 0;
    int bin = 0;

    printf("DIGITE O VALOR DO BINARIO:\t");
    scanf("%d", &bin);

    dec = bin_dec(bin); //Chama a função

    printf("DECIMAL = %d\n", dec);

    return 0;
}
