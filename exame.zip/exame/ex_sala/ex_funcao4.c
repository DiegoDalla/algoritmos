#include <stdio.h> 

int soma(int x, int y)
{
    int res;
    
    res = x + y;
}

int main()
{
    int a, b;
    int sm;
    
    scanf("%d %d", &a , &b);
    
    sm = soma(a ,b);
    
    printf("%d\n", sm);
    
    return 0;
}
