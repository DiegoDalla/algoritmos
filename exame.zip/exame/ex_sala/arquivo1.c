//Abrir um arquivo texto em modo somente leitura (modo "r": o arquivo deve existir) e outro arquivo de escrita

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    FILE *input; //arquivo entrada
    FILE *output; //arquivo de saida
    char InputFileName[256]; //nome arquivo entrada
    char OutputFileName[256]; //nome arquivo de saida
    char linha[300]; //ler o arquivo de entrada
    unsigned i = 0;
    
    if (argc != 3)
    {
        printf("Erro 1: Numero de parametro insulficiente.\n");
        exit(1);
    }
    
    strcpy(InputFileName);
    
    return 0;
}
