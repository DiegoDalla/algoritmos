#include <stdio.h>
#include <stdlib.h>


//Declarando a função
void bubble_sort(long [], long);
 
int main()
{
  long array[100], n, c, d, troca;
 
  printf("Numero de elementos\n");
  scanf("%ld", &n);
 
  printf("Entre com %ld inteiros\n", n);
 
  for (c = 0; c < n; c++)
    scanf("%ld", &array[c]);
 
  bubble_sort(array, n);
 
  printf("Lista ordenada em ordem crescente:\n");
 
  //O laço roda até que todos os valores 
  for (c = 0; c < n; c++)
     printf("%ld\n", array[c]);
 
  return 0;
}
 
void bubble_sort(long list[], long n)
{
  long c, d, aux;
 
  for (c = 0 ; c < n - 1; c++)
  {
    for (d = 0 ; d < n - c - 1; d++)
    {
      if (list[d] > list[d+1])
      {
        //troca
 
        aux       = list[d];
        list[d]   = list[d+1];
        list[d+1] = aux;
      }
    }
  }
}
