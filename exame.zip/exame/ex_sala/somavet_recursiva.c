//EXERCICIO RECURSIVIDADE
//CONSTRUIR UMA FUNÇÃO RECURSIVA PARA CALCULAR A SOMA DOS ELEMENTOS DE UM VETOR

#include <stdio.h>

int somav(int v , int n)
{
    if(n == 0)
        return 0;
    else
        return v[n-1] + somav(v , n-1);
}

