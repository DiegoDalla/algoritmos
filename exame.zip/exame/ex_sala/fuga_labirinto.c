//FUNCIONANDO
//Coordenadas do caminho não estão sendo 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

/*********************************************************************/

void print_maze(char **maze, int largura, int altura)
{
    int x, y;
    int i, j;
    
    
    printf("[");
    for(y = altura - 1; y >= 0; y--)
    {
        for(x = 0; x < largura; x++)
        {
            
            if(maze[x][y] == '*')
            {
                printf("(");
                printf("%d,%d", x, y);
                printf(")");
            }
        }
    }
    printf("]");
    printf("\n\n");
    
    for(y = altura - 1; y >= 0; y--)
    {
        for(x = 0; x < largura; x++)
        {
            printf("%c", maze[x][y]);
        }
        printf("\n");
    }
    
    
    printf("\n\n");
}

int labirinto(int x_atual, int y_atual, char **maze, int largura, int altura) 
{
    // Se tentou sair do labirinto, este não é o caminho certo.
    if (x_atual < 0 || x_atual >= largura || y_atual < 0 || y_atual >= altura) 
    {
        return 0;
    }
    char aqui = maze[x_atual][y_atual];

    // Verifica se achou a saída.
    if (aqui == 's')
    {
        return 1;
    }

    // Se bateu na parede ou voltou para algum lugar que já esteve,
    // então este não é o caminho certo.
    if (aqui == '1' || aqui == '*' || aqui == '*' || aqui == '*' || aqui == '*')
        return 0;
    
    
    //passo a passo
    //print_maze(maze , largura , altura );
        
    
    // Tenta ir para cima.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual, y_atual + 1, maze, largura, altura)) 
    {
        return 1;
    }
    
    // Tenta ir para baixo.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual, y_atual - 1, maze, largura, altura))
    {
        return 1;
    }
    
    // Tenta ir para a esquerda.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual - 1, y_atual, maze, largura, altura))
    {
        return 1;
    }
    
    // Tenta ir para a direita.
    maze[x_atual][y_atual] = '*';
    if (labirinto(x_atual + 1, y_atual, maze, largura, altura))
    {
        return 1;
    }
    
    // Não deu, então volta.
    maze[x_atual][y_atual] = 'O';   
    return 0;
}


int main(void) 
{
    int largura, altura, x_entrada, y_entrada;
    int resultado;
    scanf("%d %d\n", &largura, &altura);
    char **a = malloc(largura * sizeof(char*));
    for (int x = 0; x < largura; x++) {
        a[x] = malloc(altura * sizeof(char));
    }
    for (int y = altura - 1; y >= 0; y--) {
        for (int x = 0; x < largura; x++) {
            a[x][y] = getchar();
            if (a[x][y] == 'e') {
                x_entrada = x;
                y_entrada = y;
            }
        }
        getchar(); //pegar a quebra de linha
    }
    
    printf("\n\n");
    
    resultado = labirinto(x_entrada, y_entrada, a, largura, altura);
    
    if(resultado == 1)
    {
        printf("\nS\n\n");
        print_maze(a, largura, altura);
    }
    else
        printf("\nN\nLabirinto sem saida\n");
    
    return 0;
}
