#include <stdio.h>
#include <string.h>
#include <malloc.h>

/*Declaração do nó para a árvore, composto de ponteiros
da direita e esquerda e de um campo para dado que no caso
é o campo char dado[30];
*/
struct no {
       
       char dado[30];
       struct no *direita;
       struct no *esquerda;
       
       };
       
struct no *raiz; //Ponteiro da raiz
struct no *alocar; //Ponteiro para fazer alocação

/*Rotina de busca
Insere o dado em string e ela retorna o ponteiro em hexa
para a região da memória para o qual o ponteiro está
apontando.
*/
struct no * buscar(char *dado) {
       
      struct no *ponteiro;
      
      ponteiro = raiz;
       
      while (ponteiro) { 
            
      if (strcmp(dado, ponteiro->dado)==0) //Faz a comparação de strings
            return ponteiro; //Retorna ponteiro se o encontrar
            
      if (strcmp(dado, ponteiro->dado)>0)
            ponteiro = ponteiro->direita;

      else
            ponteiro = ponteiro->esquerda; 
      
      }
      
      return NULL; //Retorna o ponteiro nulo
}

/*Rotina que faz a inserção na árvore binária de busca
O Parâmetro dado recebe um ponteiro para string 
A função não retorna valor nem referência
*/
void inserir(char *dado) {
     
    alocar = (struct no *) malloc(sizeof(struct no)); //Faz alocação na memória
        
    if (!alocar) { //Se não for possível a alocação, sai do programa
       printf("Falta de memória"); 
       exit(0);
    }
    
    strcpy(alocar->dado, dado); //Copia o dado para o novo nó alocado
     
     if (!raiz) { //Se não houver elemento ainda na árvore, insere na raiz
         raiz = alocar;
     }
     
     else //se não...
     
     {
       //ponteiros para busca
       struct no *ponteiro; 
       struct no *ponteiroAnterior;
       ponteiro = raiz; //ponteiro inicia na raiz
       ponteiroAnterior = NULL; //anterior inicial em NULL
         
        while (ponteiro) { //Faz a busca do lugar ao qual deve ser inserido o nó
              
              ponteiroAnterior = ponteiro;
              
              if (strcmp(dado, ponteiro->dado)==0) {
                 printf("\nDado inserido já existe!");
                 return;
                 }
              
              if (strcmp(dado, ponteiro->dado)>0){
                 ponteiro = ponteiro->direita;
              }
              else {
                 ponteiro = ponteiro->esquerda; 
                   }
           }

        if  (strcmp(dado, ponteiroAnterior->dado)>0) {
              ponteiroAnterior->direita = alocar; 
              //atribui o endereço de alocação ao ponteiro da direita do nó anterior
            }  
        else  {
              ponteiroAnterior->esquerda = alocar;
              //atribui o endereço de alocação ao ponteiro da esquerda do nó anterior
              }
     }
}

/*Faz o caminhamento em ordem recursivamente*/
void caminharEmOrdem(struct no *ponteiro) {
     if (ponteiro) {
           caminharEmOrdem(ponteiro->esquerda);
           printf("\n%s", ponteiro->dado);
           caminharEmOrdem(ponteiro->direita);
          }
     }

     
     
     
     
No *MaiorDireita(No **no){
    if((*no)->direita != NULL) 
       return MaiorDireita(&(*no)->direita);
    else{
       No *aux = *no;
       if((*no)->esquerda != NULL) // se nao houver essa verificacao, esse nó vai perder todos os seus filhos da esquerda!
          *no = (*no)->esquerda;
       else
          *no = NULL;
       return aux;
       }
}

No *MenorEsquerda(No **no){
    if((*no)->esquerda != NULL) 
       return MenorEsquerda(&(*no)->esquerda);
    else{
       No *aux = *no; 
       if((*no)->direita != NULL) // se nao houver essa verificacao, esse nó vai perder todos os seus filhos da direita!
          *no = (*no)->direita;
       else
          *no = NULL;
       return aux;
       }
}

void remover(No **pRaiz, int numero)
{
    if(*pRaiz == NULL){   // esta verificacao serve para caso o numero nao exista na arvore.
       printf("Numero nao existe na arvore!");
       getch();
       return;
    }
    if(numero < (*pRaiz)->numero)
       remover(&(*pRaiz)->esquerda, numero);
    else 
       if(numero > (*pRaiz)->numero)
          remover(&(*pRaiz)->direita, numero);
       else{    // se nao eh menor nem maior, logo, eh o numero que estou procurando! :)
          No *pAux = *pRaiz;     // quem programar no Embarcadero vai ter que declarar o pAux no inicio do void! :[
          if (((*pRaiz)->esquerda == NULL) && ((*pRaiz)->direita == NULL)){         // se nao houver filhos...
                free(pAux);
                (*pRaiz) = NULL; 
               }
          else{     // so tem o filho da direita
             if ((*pRaiz)->esquerda == NULL){
                (*pRaiz) = (*pRaiz)->direita;
                pAux->direita = NULL;
                free(pAux); pAux = NULL;
                }
             else{            //so tem filho da esquerda
                if ((*pRaiz)->direita == NULL){
                    (*pRaiz) = (*pRaiz)->esquerda;
                    pAux->esquerda = NULL;
                    free(pAux); pAux = NULL;
                    }
                else{       //Escolhi fazer o maior filho direito da subarvore esquerda.
                   pAux = MaiorDireita(&(*pRaiz)->esquerda); //se vc quiser usar o Menor da esquerda, so o que mudaria seria isso:
                   pAux->esquerda = (*pRaiz)->esquerda;          //        pAux = MenorEsquerda(&(*pRaiz)->direita);
                   pAux->direita = (*pRaiz)->direita;
                   (*pRaiz)->esquerda = (*pRaiz)->direita = NULL;
                   free((*pRaiz));  *pRaiz = pAux;  pAux = NULL;   
                   }
                }
             }
          }
}     
     
     
     
     
     
/*Rotina principal
com algumas inserções, um caminhamento e uma busca no final
*/       
int main() {
    char dado[30];
    printf("\nInserir: ");
    gets(dado);
    inserir(dado);
    printf("\nInserir: ");
    gets(dado);
    inserir(dado);
    printf("\nInserir: ");
    gets(dado);
    inserir(dado);
    printf("\nInserir: ");
    gets(dado);
    inserir(dado);
    caminharEmOrdem(raiz);
    printf("\nInserir para buscar: ");
    gets(dado);
    printf("%p", buscar(dado));
  
    getchar();
}
