/*
 * Exibir o nome e calcular a média das notas.
 * Os dados estão nos arquivos  'nomes .txt'  e  'notas.txt' 
*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM_NOME 30
#define TRUE 1      //Verdadeiro
#define FALSE 0     //Falso

typedef struct CadastroAluno
{
    int ativo;
    char nome[TAM_NOME];
    int matricula;
    float media;
}aluno;

//Declarando funções 
void ArqNomeIn(int qnt);
void ArqNotaIn(int qnt);
 
int main(void)
{
    //Cria os arquivos de nota e nome
 	int qnt;
    
    system("clear");
 	printf("Informe o numero de alunos --> ");
 	scanf("%d", &qnt);
 	system("clear");
 	
 	//Escreve os arquivos
 	ArqNomeIn(qnt);
 	ArqNotaIn(qnt);
 	system("clear");
 	
 	/****************************************************/
    
 	//-->Lê os dados do arquivo
 	FILE *arqNome;
    FILE *arqNota;
 	int id_nome;
    int id_nota;
    float nota1 , nota2 , nota3;
 	char nome[TAM_NOME];
 	int cont = 0;
    
    aluno a[qnt+1]; //Cria a variavel do tipo struct 'aluno'
    
    for(int i = 0 ; i < qnt ; i++)
    {
        a[i].ativo = FALSE;
    }
    
 	arqNome = fopen("nomes.txt", "r"); //Abre o arquivo no modo leitura
 	if(arqNome == NULL)
 	{
		printf("Erro na leitura do arquivo 'nomes'.\n");
		return 0;
 	}
 	
 	while(fscanf(arqNome , "%d %s", &id_nome, nome) != EOF)//End of File
 	{
        strcpy(a[cont].nome , nome);
        a[cont].matricula = id_nome;
        
        arqNota = fopen("notas.txt" , "r");
        if(arqNota == NULL)
        {
            printf("Erro na leitura do arquivo 'notas'\n");
            return 0;
        }
        
        while(fscanf(arqNota, "%d %f %f %f" , &id_nota, &nota1, &nota2, &nota3) != EOF)
        {
            if(id_nota == a[cont].matricula)
            {
                a[cont].media = ((nota1 + nota2 + nota3) / 3);
                a[cont].ativo = TRUE;
                
                //Depois de encontrar o aluno o laço pode parar
                break; 
            }
        }
        
        fclose(arqNota);
        
        cont++;
	}
	
	fclose(arqNome);
	
    //Imprime os resultados
    printf("Resultados: \n");
    for(int i = 0 ; i < qnt ; i++)
    {
        if(a[i].ativo == TRUE)
        {
            //O '*' informa quantas casas vai reservar no console para a string
            //o '-' alinha a esquerda
            printf("%-*s -> %.2f\n", TAM_NOME, a[i].nome , a[i].media);
        }
    }
    
 	return 0;
} 
 
//Função que cria o arquivo de Nomes
void ArqNomeIn(int qnt)
{
	setbuf(stdin , NULL);
	printf("NOMES\n\nPress ENTER\n");
	while(getchar() != '\n');
	system("clear");
	
	FILE *ArqIn;
	int i = 0; //Indice para o 'for'
	int id;
	char nome[51];
	
	ArqIn = fopen("nomes.txt", "w");
	if(ArqIn == NULL)
	{
		printf("Erro na criação do arquivo\n");
		return;
	}	
	
	while(i < qnt)
	{
		printf("ID: ");scanf("%d", &id);
		setbuf(stdin , NULL);
		printf("NOME: ");fgets(nome , 50 , stdin);
		system("clear");
		
		fprintf(ArqIn, "%d %s", id, nome);
		
		i++;
	}
	
	fclose(ArqIn);
}

//Função que cria o arquivo de Notas
void ArqNotaIn(int qnt)
{
	setbuf(stdin , NULL);
	printf("NOTAS\n\nPress ENTER\n");
	while(getchar() != '\n');
	system("clear");
	
	FILE *ArqIn;
	int i = 0; //Indice para o 'for'
	int id;
	float nota1 , nota2 , nota3;
	
	ArqIn = fopen("notas.txt","w");
	if(ArqIn == NULL)
	{
		printf("Erro na criação do arquivo\n");
		return;
	}
	
	while(i < qnt)
	{
		printf("ID: ");scanf("%d", &id);
		printf("NOTA I:   ");scanf("%f", &nota1);
		printf("NOTA II:  ");scanf("%f", &nota2);
		printf("NOTA III: ");scanf("%f", &nota3);
		system("clear");
		
		fprintf(ArqIn, "%d %.1f %.1f %.1f\n", id,nota1,nota2,nota3);
		
		i++;
	}
	
	fclose(ArqIn);
}
