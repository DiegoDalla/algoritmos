/*
 *	PRINCIPAIS METODOS DE ACESSO AO ARQUIVO
 * 'r'  - Abre um arquivo texto para leitura
 * 'w'  - Cria/Recria um arquivo texto para gravação, escreve no inicio. Se o arquivo ja existir ele é recriado
 * 'a'  - Cria/Acrescenta um arquivo texto para gravação, escreve no fim do arquivo caso ele ja exista
 * 'rb' - Abre um arquivo binario para leitura
 * 'wb' - Criar/Recria um arquivo binario para escrita, semelhante ao 'w'
 * 'ab' - Criar/Acrescenta um arquivo binario para escrita, semelhante ao 'a'
 * 'r+' - Abre um arquivo texto para leitura e gravação. O arquivo deve existir e ser modificado
 * 'w+' - Cria um arquivo texto para leitura e gravação. Se ja existir é recriado, caso contrario é criado
 * 'a+' - Abre um arquivo para leitura e gravação. Se ja existir o texto é inserido no fim, caso contrario é criado
 * 'r+b'- Identico ao 'r+', só que binario
 * 'w+b'- Identico ao 'w+', só que binario
 * 'a+b'- Identico ao 'a+', só que binario
 *  
 * 
 * PRINCIPAIS FUNÇÕES PARA MANIPULAÇÃO DE UM ARQUIVO
 * 'fopen()'  - Abrir um arquivo
 * 'fclose()' - Fechar um arquivo
 * 'putc()'   - Escreve um caracter em um arquivo
 * 'getc()'   - Ler um caracter de um arquivo
 * 'fseek()'  - Posiciona o ponteiro de arquivo num byte especifico
 * 'fprintf()'- Insere info em um arquivo
 * 'fscanf()' - Recuperar informação de arquivo
 * 'feof()'   - Devolve TRUE se o fim do arquivo foi atingido
 * 'ferror()' - Devolve TRUE se ocorreu um erro
 * 'rewind()' - Posicionar o ptr de arquivo no inicio
 * 'remove()' - Apagar um arquivo
 * 'fflush()' - Descarregar um arquivo
 * 
*/


#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	FILE *arquivoIn;
	FILE *arquivoOut;
	int num = 0;
	int conteudo = 0;
	int i = 0;
	
	//Abre para entrada dos dados
	arquivoIn = fopen("arq1.txt" , "w");
	if(arquivoIn == NULL)
		printf("ERRO!\nNão foi possivel acessar o arquivo\n");
	
	printf("Informe quantos numeros você deseja cadastrar: ");
	scanf("%d", &num);
	
	while(i < num)
	{
		printf("Informe um número: ");
		scanf("%d", &conteudo);
		
		fprintf(arquivoIn, "%d  ", conteudo);
		
		i++;
	}
	
	//NUNCA ESQUECER DE FECHAR O ARQUIVO
	fclose(arquivoIn);

	
	//Abre para leitura dos dados
	arquivoOut = fopen("arq1.txt" , "r");
	
	
	printf("\n--\n\nDados dentro do arquivo:\n");
	while(fscanf(arquivoOut,"%d", &conteudo) != EOF)
	{
		printf(" %d ", conteudo);
	}
	
	fclose(arquivoOut);
	
	return 0;
}
